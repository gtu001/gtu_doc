create or replace PROCEDURE    Sp_Bansf_01(P_Payym       In Varchar2, --處理年月
										v_i_mmJobNO   in varChar2,
                                        v_i_bajobid   in varChar2,
                                        p_return_code OUT VARCHAR2, --回傳訊息OK:成功 or NO:失敗
                                        v_o_flag      out varChar2
										) Is
Begin
	-- 修改紀錄：
	-- 維護人員        日期       說明
	-- -----------   --------  ----------------------------------------------------
	-- rose          20120906   v1.0
	-- 供莉瑛執行時所需更動設定如下:
	-- BA. -->ba.
	-- CAUB-->caub
	-- bacipb-->ba.cipb
	-- ============================================================================
	--                          <<<<<<<<< 變數區 >>>>>>>>>>
	-------------------------------------------------------------------------------
	DECLARE
		R_NBAPPBASE_Rec        NBAPPBASE%Rowtype; --NBAPPBASE RECORD
		R_Badapr_Rec           Badapr_Ref%Rowtype; --badapr_ref RECORD
		R_Baappbase_Rec        Baappbase%Rowtype; --BAAPPBASE RECORD
		R_Baappexpand_Rec      Baappexpand%Rowtype; --BAAPPEXPAND RECORD
		R_CIPB_Rec             ba.cipb%Rowtype; --BAAPPEXPAND RECORD
		R_Source_Badapr_Rec    Badapr%Rowtype; --badapr record
		R_Source_Baappbase_Rec Baappbase%Rowtype; --BAAPPBASE RECORD
		R_Caub_Rec             CAUB%Rowtype; --STAT RECORDc
		-- ============================================================================
		sw_found        BOOLEAN := TRUE; --找到資料
		sw_found_badapr BOOLEAN := TRUE; --找到資料
		sw_found_CIPB   BOOLEAN := TRUE;
		-- ============================================================================
		-------------------------------------------------------------------------------
		--V_Bansf_Ref_In_Cnt  Number(10) := 0; --讀取bansf_ref筆數
		--V_Badapr_Ref_In_Cnt Number(10) := 0; --讀取badapr_ref筆數
		V_Out_temp_Cnt      Number(10) := 0; --輸出新增筆數
		V_Out_Cnt           Number(10) := 0; --輸出新增筆數
		v_del_cnt           NUMBER(10) := 0; --刪除筆數
		V_Key_Ubno          Bansf.Ubno%Type;
		V_Key_Baappbaseid   Number(20); --給付主檔資料編號
		V_KEY_APNO          BANSF.APNO%TYPE; --受理編號
		V_KEY_NBAPNO        BANSF.APNO%TYPE; --國保受理編號
		V_Key_Idn           Varchar2(11 Byte); --身份證號
		V_Key_Intyp         varchar(1 byte); --保險別
		v_key_name          Bansf.Evtname%type; --姓名
		v_key_brdate        Varchar2(8 Byte); --生日
		V_Exception_Cnt     Integer := 0; --EXCEPTION錯誤筆數
		--v_format_date       DATE; --DATE格式欄位
		V_Str               Varchar2(3 Byte); --狀態變數
		V_Str2              Varchar2(2 Byte); --狀態變數
		V_Str3              Varchar2(2 Byte); --狀態變數
		v_key_seqno         Varchar2(4 Byte); --序號
		V_BDATE             varchar2(6 byte);
		V_Edate             Varchar2(6 Byte);
		--v_injdp             BCA_D_INJD.INJDP%TYPE;
		V_Age               NUMBER(3);
		V_Payym             Varchar(6 Byte);
		v_iisuym            varchar(6 byte);
		V_Apno              Bansf.Apno%Type;
		V_Samt              Number(12, 2);
		V_Cat               Varchar(1);
		V_Evtdiedate        Baappbase.Evtdiedate%Type;
		v_notfound_cipb_cnt NUMBER(10) := 0; --找不到CIPB筆數
		V_TOOMANY_CIPB_CNT  NUMBER(10) := 0; --找到太多CIPB筆數
		v_other_cipb_cnt    NUMBER(10) := 0; --找到ERR CIPB筆數

		-- ============================================================================
		-- CURSOR C_BANSF_REF
		-------------------------------------------------------------------------------
		--處理年月=201208,則全量資料取入,否則,取回給付年月payym=處理年月P_Payym
		--因excel檔未變造,故先行變造Substr(Ubno,1,3)||Substr(Ubno,7,2)||Substr(Ubno,4,3)
		--Select To_Char(Issuym+191100) As Issuym,To_Char(Payym+191100) As Payym,Apno,Payno,Substr(Ubno,1,3)||Substr(Ubno,7,2)||Substr(Ubno,4,3) As Ubno,Evtbrdate,Evtidnno,Edate,Sex,Evtype,Adwkmk,Case When Firstpay Is Null Then '0' Else Firstpay End As Firstpay,Pamts,Otheramt As Deduct,Paycnt,Evcode,Injno,Injcl,Payday,Case When Suprecmk Is Null Then '1' Else Suprecmk End As Suprecmk,Nachgmk,'0' As Pwage,Null As Appdate,Null As Nitrmy,Null Nitrmm
		--SELECT TO_CHAR(ISSUYM+191100) AS ISSUYM,TO_CHAR(PAYYM+191100) AS PAYYM,APNO,PAYNO,UBNO AS UBNO,EVTBRDATE,EVTIDNNO,EDATE,SEX,EVTYPE,ADWKMK,CASE WHEN FIRSTPAY IS NULL THEN '0' ELSE FIRSTPAY END AS FIRSTPAY,PAMTS,OTHERAMT AS DEDUCT,PAYCNT,EVCODE,INJNO,INJCL,PAYDAY,CASE WHEN SUPRECMK IS NULL THEN '1' ELSE SUPRECMK END AS SUPRECMK,NACHGMK,'0' AS PWAGE,NULL AS APPDATE,NULL AS NITRMY,NULL NITRMM

		CURSOR C_BANSF_REF IS
			select *
			  from (SELECT TO_CHAR(ISSUYM + 191100) AS ISSUYM,
						   TO_CHAR(PAYYM + 191100) AS PAYYM,
						   NULL AS NBAPNO,
						   UPPER(APNO) AS APNO,
						   PAYNO,
						   UBNO AS UBNO,
						   EVTBRDATE,
						   EVTIDNNO,
						   EDATE,
						   SEX,
						   EVTYPE,
						   ADWKMK,
						   CASE WHEN FIRSTPAY IS NULL THEN'0'  ELSE	FIRSTPAY END AS FIRSTPAY, --首發註記
						   PAMTS,
						   OTHERAMT AS DEDUCT,
						   PAYCNT,
						   EVCODE,
						   INJNO,
						   INJCL,
						   PAYDAY,
						   CASE  WHEN SUPRECMK IS NULL THEN '1' ELSE SUPRECMK END AS SUPRECMK, --補發收回註記
						   NACHGMK,
						   '0' AS PWAGE,
						   NULL AS APPDATE,
						   NULL AS NITRMY,
						   NULL NITRMM
					  From Bansf_Ref                --BANSF_REF媒體檔匯入
					 Where P_Payym = '201208'
					   AND ISSUYM + 191100 < '201312'
					UNION ALL
					SELECT TO_CHAR(ISSUYM + 191100) AS ISSUYM,
						   TO_CHAR(PAYYM + 191100) AS PAYYM,
						   NULL AS NBAPNO,
						   UPPER(APNO) AS APNO,
						   PAYNO,
						   UBNO AS UBNO,
						   EVTBRDATE,
						   EVTIDNNO,
						   EDATE,
						   SEX,
						   EVTYPE,
						   ADWKMK,
						   CASE WHEN FIRSTPAY IS NULL THEN '0'ELSE FIRSTPAY END AS FIRSTPAY,
						   PAMTS,
						   OTHERAMT AS DEDUCT,
						   PAYCNT,
						   EVCODE,
						   INJNO,
						   INJCL,
						   PAYDAY,
						   CASE WHEN SUPRECMK IS NULL THEN '1' ELSE SUPRECMK END AS SUPRECMK,
						   NACHGMK,
						   '0' AS PWAGE,
						   NULL AS APPDATE,
						   NULL AS NITRMY,
						   NULL NITRMM
					  From Bansf_Ref
					 Where P_Payym <> '201208'
					   AND ISSUYM + 191100 = P_PAYYM
					UNION ALL
					Select To_Char(Issuym + 191100) As Issuym,
						   To_Char(Payym + 191100) As Payym,
						   NBAPNO AS NBAPNO,
						   UPPER(APNO) AS APNO,
						   Payno,
						   Null As Ubno,
						   Evtbrdate,
						   Evtidnno,
						   Null As Edate,
						   NULL As Sex,
						   '3' As Evtype,
						   '1' As Adwkmk,
						   To_Char(Firstpay) As Firstpay,
						   Pamts,
						   Null As Deduct,
						   Null As Paycnt,
						   Null As Evcode,
						   Null As Injno,
						   Null As Injcl,
						   0 As Payday,
						   CASE WHEN SUPRECMK IS NULL THEN '1'ELSE SUPRECMK
						   END AS SUPRECMK,
						   Null As Nachgmk,
						   Pwage,
						   Appdate,
						   To_Char(Year_Rang) As Nitrmy,
						   To_Char(Mon_Rang) As Nitrmm
					  From Bansf_Ref_36
					 Where P_Payym = '201208'
					   AND ISSUYM + 191100 < '201312'
					UNION ALL
					Select To_Char(Issuym + 191100) As Issuym,
						   To_Char(Payym + 191100) As Payym,
						   NBAPNO AS NBAPNO,
						   UPPER(APNO) AS APNO,
						   Payno,
						   Null As Ubno,
						   Evtbrdate,
						   Evtidnno,
						   Null As Edate,
						   NULL As Sex,
						   '3' As Evtype,
						   '1' As Adwkmk,
						   To_Char(Firstpay) As Firstpay,
						   Pamts,
						   Null As Deduct,
						   Null As Paycnt,
						   Null As Evcode,
						   Null As Injno,
						   Null As Injcl,
						   0 As Payday,
						   CASE WHEN SUPRECMK IS NULL THEN '1'ELSE SUPRECMK
						   END AS SUPRECMK,
						   Null As Nachgmk,
						   Pwage,
						   Appdate,
						   To_Char(Year_Rang) As Nitrmy,
						   To_Char(Mon_Rang) As Nitrmm
					  From Bansf_Ref_36
					 Where P_Payym <> '201208'
					   AND ISSUYM + 191100 = P_PAYYM) A
			 Order By (case
						  when payno = '37' then   --給付種類(paykind)
						   '1'
						  when payno = '36' then
						   '2'
						  when payno in ('55', '56', '58', '59') then
						   '3'
						  when payno in ('35', '38') then
						   '4'
						  else
						   '5'
					  end),
					  (Case
						  When (Suprecmk is Null or suprecmk = '1') then
						   '0'
						  when Suprecmk = 'C' Then
						   '1'
						  Else
						   '2'
					  End),
					  (case
						  when Nachgmk in ('A', 'B') then  --普職互改註記
						   '1'
						  else
						   '0'
					  end),
					  Apno,
					  issuym,
					  Payym;

		/*        SELECT TO_CHAR(ISSUYM+191100) AS ISSUYM,TO_CHAR(PAYYM+191100) AS PAYYM,NULL AS NBAPNO,UPPER(APNO) AS APNO,PAYNO,UBNO AS UBNO,EVTBRDATE,EVTIDNNO,EDATE,SEX,EVTYPE,ADWKMK,CASE WHEN FIRSTPAY IS NULL THEN '0' ELSE FIRSTPAY END AS FIRSTPAY,PAMTS,OTHERAMT AS DEDUCT,PAYCNT,EVCODE,INJNO,INJCL,PAYDAY,CASE WHEN SUPRECMK IS NULL THEN '1' ELSE SUPRECMK END AS SUPRECMK,NACHGMK,'0' AS PWAGE,NULL AS APPDATE,NULL AS NITRMY,NULL NITRMM
               From Bansf_Ref  Where (P_Payym='201208' Or Payym=Lpad(Substr(P_Payym,1,4)-1911,3,'0')||Substr(P_Payym,5,2)) --and apno='S00000000626' --AND payno like '3%' AND ROWNUM<20 -- and (apno='K00000000772' or apno='S00000003837') -- and payno='55' --and issuym='09805'and nachgmk is null and apno='S00000006652' --nachgmk<>'A' --and apno in ('S00000000185','S00000006652') --and payym in ('09807','09808')  -- and (apno='K00000000772' or apno='S00000003837') -- AND payym='10102'or  APNO='K00000000373' --and payno='35' AND APNO='K00000000677'; --and payno='55' -- And Apno='S00000000122' --'K00000000290' --S00000000011' --and ubno='01000273'-- -- AND  (Nachgmk='A' Or Suprecmk In ('C','D'))
               UNION ALL
               Select To_Char(Issuym+191100) As Issuym,To_Char(Payym+191100) As Payym,NBAPNO AS NBAPNO,UPPER(APNO) AS APNO,Payno,Null As Ubno,Evtbrdate,Evtidnno,Null As Edate,NULL As Sex,'3' As Evtype,'1' As Adwkmk,To_Char(Firstpay) As Firstpay,Pamts,Null As Deduct,Null As Paycnt,Null As Evcode,Null As Injno,Null As Injcl,0 As Payday,Null As Suprecmk,Null As Nachgmk,Pwage,Appdate,To_Char(Year_Rang) As Nitrmy,To_Char(Mon_Rang) As Nitrmm
               From Bansf_Ref_36  Where (P_Payym='201208' Or Payym=Lpad(Substr(P_Payym,1,4)-1911,3,'0')||Substr(P_Payym,5,2)) --AND APNO='K20000000001' --And Apno='S00000000046' --'K00000000290' --S00000000011' --and ubno='01000273' --  -- AND  (Nachgmk='A' Or Suprecmk In ('C','D'))
               Order By Apno,issuym,Payym,Suprecmk ;   --S00000001353
        */
		--依受理編號Apno、給付年月Payym及處理註記Mtestmk='F'等,讀取Badapr資料
		CURSOR C_BADAPR_SUPRECMK(S_KEY_APNO IN VARCHAR2,
								 S_PAYYM    IN VARCHAR2,
								 S_SUPRECMK IN VARCHAR2,
								 S_PAYNO    IN VARCHAR2) IS
			select *
			  from (SELECT *
					  FROM BADAPR
					 WHERE APNO = S_KEY_APNO
					   AND PAYYM = S_PAYYM
					   And Mtestmk = 'F'
					   And Aplpaymk = '3'
					   AND SEQNO = '0000'
					   and ((S_SUPRECMK is null and Suprecmk is null) or
						   Suprecmk =
						   decode(S_SUPRECMK, 'K', 'D', S_SUPRECMK))
					   and paykind = S_PAYNO
					 Order By (Case
								  When 'C' Is Not Null And Suprecmk = 'C' Then
								   '1'
								  Else
								   '2'
							  End),
							  Apno,
							  issuym desc,
							  Payym,
							  Seqno) A
			 where rownum < 2;

		--依受理編號Apno、給付年月Payym,baappbase
		Cursor C_baappbase(s_key_apno In Varchar2) Is
			SELECT *
			  From Baappbase
			 Where Apno = S_Key_Apno
			   AND SEQNO = '0000'
			 Order By Apno, Payym, Seqno;

		-- ============================================================================
		-- procedure
		-------------------------------------------------------------------------------
		-- 輸出結果
		PROCEDURE P_OUTPUT_MESSAGE IS
		BEGIN
			Dbms_Output.Put_Line('異常cipb資料=' ||
								 to_char(v_notfound_cipb_cnt +
										 v_toomany_cipb_cnt +
										 v_other_cipb_cnt));
			p_return_code := p_return_code || '異常cipb資料=' ||
							 to_char(v_notfound_cipb_cnt +
									 v_toomany_cipb_cnt + v_other_cipb_cnt) || ',';
			Dbms_Output.Put_Line('新增bansf筆數=' || V_Out_Cnt);
			p_return_code := p_return_code || '新增bansf筆數=' || V_Out_Cnt || ',';
		End;
		-------------------------------------------------------------------------------
		-- 刪除計費年月資料
		-------------------------------------------------------------------------------
		PROCEDURE p_delete_data IS
		Begin
			--刪除BANSF、BADAPR_REF、BC_CMST、BC_CDTL處理當月資料
			Delete From bansf
			 WHERE (P_Payym = '201208' or payym = P_Payym)
			   and substr(payno, 1, 1) <> '4';
			Delete From Badapr_Ref             ??????????????????????????????? 何時寫入??目前BB 無
			 WHERE (P_PAYYM = '201208' OR PAYYM = P_PAYYM)
			   AND SUBSTR(PAYNO, 1, 1) <> '4';
			commit;
			V_Del_Cnt := 0; --刪除筆數
			v_del_cnt := v_del_cnt + SQL%ROWCOUNT; --刪除筆數
		EXCEPTION
			WHEN OTHERS THEN
				v_exception_cnt := v_exception_cnt + 1;
				DBMS_OUTPUT.put_line('p_delete_data發生錯誤,錯誤代碼=' || sqlcode || ',' ||
									 '錯誤訊息=' || SQLERRM);
				p_return_code := p_return_code || 'p_delete_data發生錯誤,錯誤代碼=' ||
								 sqlcode || ',' || '錯誤訊息=' || SQLERRM || ',';

                --20190827 Add by Angela RecLog Start
                SP_BA_RecBatchJobDtl(BAJOBDTLID.NEXTVAL,
                                     v_i_bajobid,
                                     '1',
                                     '(DB)SP_BANSF_01：刪除勞保統計檔(BANSF、BADAPR_REF)(以處理年月為條件)發生錯誤***',
                                     replace(to_Char(SYSTIMESTAMP, 'yyyyMMddHH24missxff'),'.',''));
                --20190827 Add by Angela RecLog End;
        END;
		-------------------------------------------------------
		--f_typeno
		FUNCTION f_typeno(s_ubtype CA.CAUBV3.ubtype%TYPE)
			RETURN cia_d_ubty.typeno%TYPE IS
			RESULT cia_d_ubty.typeno%TYPE;
		BEGIN
			SELECT distinct no
			  INTO RESULT
			  From Cia_D_Ubty X
			 where typeno = s_ubtype
			   and rownum < 2;
			RETURN RESULT;
		EXCEPTION
			WHEN no_data_found THEN
				RETURN '09';
			WHEN OTHERS THEN
				RETURN '09';
		End;

		--依受理編號Apno、給付年月ISSUYM,Payym及處理註記Mtestmk='F'等,讀取Badapr資料
		FUNCTION C_BADAPR_SUPRECMK_PAYDATE(S_KEY_APNO IN VARCHAR2,
										   S_ISSUYM   IN VARCHAR2,
										   S_PAYYM    IN VARCHAR2,
										   S_SUPRECMK IN VARCHAR2,
										   S_PAYNO    IN VARCHAR2,
										   S_PAYDATE  in varchar2)
			RETURN BADAPR.aplpaydate%TYPE IS
			RESULT BADAPR.aplpaydate%TYPE;
		BEGIN
			select aplpaydate
			  INTO RESULT
			  from (SELECT aplpaydate
					  FROM BADAPR
					 WHERE APNO = S_KEY_APNO
					   AND PAYYM = S_PAYYM
					   AND ISSUYM = S_ISSUYM
					   And Mtestmk = 'F'
					   And Aplpaymk = '3'
					   AND SEQNO = '0000'
					   and ((S_SUPRECMK is null and Suprecmk is null) or
						   Suprecmk =
						   decode(S_SUPRECMK, 'K', 'D', S_SUPRECMK))
					   and paykind = S_PAYNO
					 Order By (Case
								  When 'C' Is Not Null And Suprecmk = 'C' Then
								   '1'
								  Else
								   '2'
							  End),
							  Apno,
							  issuym desc,
							  Payym,
							  Seqno) A
			 where rownum < 2;
			RETURN RESULT;
		EXCEPTION
			WHEN no_data_found THEN
				RETURN S_PAYDATE;
			WHEN OTHERS THEN
				RETURN S_PAYDATE;
		End;

		------------------------------------------------------
		--f_typeno
		FUNCTION f_bansfcount(s_apno     bansf.apno%TYPE,
							  s_payym    bansf.payym%TYPE,
							  s_suprecmk bansf.code%type) RETURN number IS
			RESULT number;
		BEGIN

			SELECT count(*)
			  INTO RESULT
			  From bansf X
			 where apno = s_apno
			   and payym = s_payym
			   and (s_suprecmk is null or code = s_suprecmk)
			   and rownum < 2;
			-- DBMS_OUTPUT.put_line('1:'||s_apno||';'||RESULT);

			RETURN RESULT;
		EXCEPTION
			WHEN no_data_found THEN
				RETURN '0';
			WHEN OTHERS THEN
				RETURN '0';
		End;
		-------------------------------------------------------
		--取回C_BADAPR_Suprecmk總數
		Function F_Count(S_Key_Apno In Varchar2, S_Payym In Varchar2)
			Return INT Is
			RESULT INT;
		Begin
			SELECT COUNT(*)
			  Into Result
			  From Badapr
			 Where Apno = S_Key_Apno
			   And Payym = S_Payym
			   and Mtestmk = 'F'    --D-日處理、M-月試核、F-月核定
			   AND Aplpaymk = '3';  --帳務註記,N-退件、1-確認、2-製票、3-核付 
			RETURN RESULT;
		EXCEPTION
			When No_Data_Found Then
				RETURN 0;
			When Others Then
				RETURN 0;
		End;
		------------------------------------------------------------
		--取回INJDP障礙(失能部位)----失能項目injdp1~injdp10
		function F_injdp(S_key_INJNO In Varchar2) Return BCA_D_INJD.INJDP%TYPE Is
			RESULT BCA_D_INJD.INJDP%TYPE;
		Begin
			/*條件:INSKD  保險別='1' and INJNO  障礙項目(分左右)代碼=INJNO
            payym給付年月介於EFDTE生效日及失效日之間*/
			SELECT INJDP
			  Into Result
			  From Bca_D_Injd
			 Where INSKD = '1'
			   and INJNO = S_key_INJNO
			   And P_Payym || '01' >= EFDTE
			   and P_Payym || '01' <= EXDTE
			   AND ROWNUM < 2;
			RETURN RESULT;
		EXCEPTION
			When No_Data_Found Then
				RETURN 0;
			When Others Then
				RETURN 0;
		End;
		------------------------------------------------------------
		--判斷同APNO及給付年月,無存在普職註記之資料
		function f_data(S_Key_Apno In Varchar2, S_Payym In Varchar2) Return INT Is
			RESULT INT;
		Begin
			SELECT COUNT(*)
			  Into Result
			  From bansf_ref
			 Where Apno = S_Key_Apno
			   And Payym + 191100 = S_Payym
			   and Suprecmk is null;
			--   Dbms_Output.Put_Line ('found:'||S_Key_Apno||';'||S_Payym||';'||RESULT);
			RETURN RESULT;
		EXCEPTION
			When No_Data_Found Then
				RETURN 0;
			When Others Then
				RETURN 0;
		End;
		-------------------------------------------------------
		--取回v_bdate開始請領日期
		Function F_bdate(S_Key_Apno In Varchar2,
						 s_seqno    in varchar2,
						 S_Payym    In Varchar2,
						 s_payno    in varchar2) Return BADAPR.PAYYM%type Is
			Result Badapr.Payym%Type;
		Begin
			If S_Payno = '36' Then
				Select substr(Min(C.Payym), 1, 6)
				  Into Result
				  From Bansf_Ref_36 C
				 Where C.Apno = S_Key_Apno
				   And Firstpay = '1'
				   And C.Payym <= Lpad(Substr(S_Payym, 1, 4) - 1911, 3, '0') ||
					   Substr(S_Payym, 5, 2);
				If Result Is Not Null Then
					Result := Substr(Result, 1, 3) + 1911 ||
							  Substr(Result, 4, 2);
				end if;
			ELSE
				Select substr(Min(C.Payym), 1, 6)
				  INTO RESULT
				  FROM BADAPR C
				 WHERE C.APNO = S_Key_Apno
				   AND C.PAYYM <= S_Payym
				   And C.Mtestmk = 'F'
				   And C.Aplpaymk = '3'
				   And Trim(C.Aplpaydate) Is Not Null
				   AND C.SEQNO = s_seqno;
			End If;
			--Dbms_Output.Put_Line(S_Key_Apno||';'||S_Payym||';'||s_payno||';'||Result);

			return Result;
		EXCEPTION
			When No_Data_Found Then
				RETURN null;
			When Others Then
				RETURN null;
		End;
		-------------------------------------------------------
		--取回v_edate結束日期
		Function F_edate(S_Key_Apno In Varchar2,/*
						 s_seqno    in varchar2,
						 S_Payym    In Varchar2,*/
						 s_payno    in varchar2) Return BADAPR.PAYYM%type Is
			Result Badapr.Payym%Type;
		Begin
			If S_Payno = '36' Then
				Select substr(max(C.Payym), 1, 6)
				  Into Result
				  From Bansf_Ref_36 C
				 Where C.Apno = S_Key_Apno;
				If Result Is Not Null Then
					Result := Substr(Result, 1, 3) + 1911 ||
							  Substr(Result, 4, 2);
				end if;
			ELSE
				Select substr(max(C.Payym), 1, 6)
				  INTO RESULT
				  FROM BADAPR C
				 WHERE C.APNO = S_Key_Apno
				   And C.Mtestmk = 'F'
				   And C.Aplpaymk = '3'
				   And Trim(C.Aplpaydate) Is Not Null
				   AND c.suprecmk is null
				/*AND C.seqno='0000'*/
				;
			End If;
			--Dbms_Output.Put_Line(S_Key_Apno||';'||S_Payym||';'||s_payno||';'||Result);

			return Result;
		EXCEPTION
			When No_Data_Found Then
				RETURN null;
			When Others Then
				RETURN null;
		End;
		-------------------------------------------------------
		--取回月份相減
		Function F_Year(S_Ym_B In Varchar2, S_Ym_E In Varchar2) Return Number Is
		Begin
			If S_Ym_B Is Not Null And S_Ym_E Is Not Null Then
				If Substr(S_Ym_E, 5, 2) > Substr(S_Ym_B, 5, 2) Then
					Return to_number(Substr(S_Ym_b, 1, 4) -
									 Substr(S_Ym_E, 1, 4) - 1);
				Else
					Return To_Number(Substr(S_Ym_B, 1, 4) -
									 Substr(S_Ym_E, 1, 4));
				end if;
			Else
				return 0;
			End If;
		EXCEPTION
			When No_Data_Found Then
				RETURN 0;
			When Others Then
				Return 0;
		End;
		-------------------------------------------------------------------------------
		--讀取CAUB
		PROCEDURE p_read_caub IS
		BEGIN
			Sw_Found := True;
			Select *
			  Into R_Caub_Rec
			  From CAUB
			 Where Ubno = V_Key_Ubno
			   And Rownum < 2;
			--保險證號
		Exception
			WHEN NO_DATA_FOUND THEN
				r_caub_rec := null;
				sw_found   := FALSE;
			WHEN OTHERS THEN
				Sw_Found := False;
				Dbms_Output.Put_Line('p_read_caub發生錯誤,UBNO=' || V_Key_Ubno ||
									 ',錯誤代碼=' || Sqlcode || ',' || '錯誤訊息=' ||
									 Sqlerrm || ',' ||
									 DBMS_UTILITY.format_error_backtrace);
				p_return_code := p_return_code || 'p_read_caub發生錯誤,UBNO=' ||
								 V_Key_Ubno || ',錯誤代碼=' || Sqlcode || ',' ||
								 '錯誤訊息=' || Sqlerrm || ',' ||
								 DBMS_UTILITY.format_error_backtrace || ',';

		        --20190827 Add by Angela RecLog Start
                SP_BA_RecBatchJobDtl(BAJOBDTLID.NEXTVAL,
                                     v_i_bajobid,
                                     '1',
                                     '(DB)SP_BANSF_01：讀取CAUB發生錯誤，UBNO='||V_Key_Ubno||'***',
                                     replace(to_Char(SYSTIMESTAMP, 'yyyyMMddHH24missxff'),'.',''));
                --20190827 Add by Angela RecLog End;
        End;
		-------------------------------------------------------------------------------
		-- 顯示LOG內容
		PROCEDURE log_msg(p_msg IN VARCHAR2) IS
		BEGIN
			IF v_exception_cnt > 100 THEN
				DBMS_OUTPUT.put_line('EXCEPTION錯誤超過100個！');
				p_return_code := p_return_code || 'EXCEPTION錯誤超過100個！' || ',';
				raise_application_error(-20001, 'EXCEPTION錯誤超過100個！');
			END IF;

			DBMS_OUTPUT.put_line(p_msg);
			p_return_code := p_return_code || p_msg || ',';
		End;
		-------------------------------------------------------------------------------
		-- 依身份證號Idno讀取CIPB資料
		/*   PROCEDURE p_read_cipb
          is
          Begin
             Select *
             Into R_Cipb_Rec
             From   dss.CIPB
             WHERE  intyp=v_key_intyp and idn like v_key_idn||'%' and brdte=v_key_brdate and name= v_key_name  and rownum<2;
          Exception
            When No_Data_Found
            Then
              R_Cipb_Rec:=Null;
              Sw_Found:=False;
            When Others Then
              R_Cipb_Rec:=Null;
              Sw_Found:=False;
              log_msg('p_read_cipb發生錯誤,idn='||v_key_idn||',錯誤代碼='||sqlcode||','||'錯誤訊息='||SQLERRM);
          End ;
        */

		PROCEDURE p_read_cipb is
		Begin
			SELECT *
			  INTO r_cipb_rec
			  FROM ba.cipb B
			 WHERE B.intyp = V_KEY_INTYP
			   AND B.IDN LIKE V_KEY_IDN || '%'
			   AND B.BRDTE = v_key_brdate;
		EXCEPTION
			WHEN NO_DATA_FOUND THEN
				V_NOTFOUND_CIPB_CNT := V_NOTFOUND_CIPB_CNT + 1;
				R_CIPB_REC          := NULL;
				SW_FOUND_CIPB       := FALSE;
			WHEN TOO_MANY_ROWS THEN
				--以 身分證,出生,姓名 讀CIPB取CIID
				BEGIN
					SELECT *
					  INTO R_CIPB_REC
					  FROM ba.cipb B
					 WHERE B.intyp = v_key_intyp
					   AND B.IDN like v_key_idn || '%'
					   AND B.BRDTE = v_key_brdate
					   AND B.NAME = v_key_name;
				EXCEPTION
					WHEN NO_DATA_FOUND THEN
						v_notfound_cipb_cnt := v_notfound_cipb_cnt + 1;
					WHEN TOO_MANY_ROWS THEN
						v_toomany_cipb_cnt := v_toomany_cipb_cnt + 1;
					WHEN OTHERS THEN
						v_other_cipb_cnt := v_other_cipb_cnt + 1;
				END;
			WHEN OTHERS THEN
				V_OTHER_CIPB_CNT := V_OTHER_CIPB_CNT + 1;
				R_Cipb_Rec       := Null;
				Sw_Found_CIPB    := False;
				LOG_MSG('p_read_cipb發生錯誤,idn=' || V_KEY_IDN || ',錯誤代碼=' ||
						SQLCODE || ',' || '錯誤訊息=' || SQLERRM);
				p_return_code := p_return_code || 'p_read_cipb發生錯誤,idn=' ||
								 V_KEY_IDN || ',錯誤代碼=' || SQLCODE || ',' ||
								 '錯誤訊息=' || SQLERRM || ',';

                --20190827 Add by Angela RecLog Start
                SP_BA_RecBatchJobDtl(BAJOBDTLID.NEXTVAL,
                                     v_i_bajobid,
                                     '1',
                                     '(DB)SP_BANSF_01：讀取BA.CIPB發生錯誤，IDN='||V_KEY_IDN||'***',
                                     replace(to_Char(SYSTIMESTAMP, 'yyyyMMddHH24missxff'),'.',''));
                --20190827 Add by Angela RecLog End;
        END;
		-------------------------------------------------------------------------------
		-- 依受理編號Apno及序號Seqno取得BAAPPBASE資料
		PROCEDURE p_read_Nbaappbase IS
		BEGIN
			sw_found := TRUE;

			SELECT DISTINCT *
			  INTO R_NBAPPBASE_REC
			  FROM NBAPPBASE A
			 WHERE APNO = V_KEY_NBAPNO
			   AND SEQNO = '0000'
			   AND PAYDT IS NOT NULL;
		EXCEPTION
			WHEN NO_DATA_FOUND THEN
				sw_found := FALSE;
			WHEN OTHERS THEN
				SW_FOUND := FALSE;
				log_msg('p_read_nbaappbase發生錯誤,APNO=' || v_key_apno ||
						',錯誤代碼=' || sqlcode || ',' || '錯誤訊息=' || SQLERRM);
				p_return_code := p_return_code ||
								 'p_read_nbaappbase發生錯誤,APNO=' ||
								 v_key_apno || ',錯誤代碼=' || sqlcode || ',' ||
								 '錯誤訊息=' || SQLERRM || ',';

                --20190827 Add by Angela RecLog Start
                SP_BA_RecBatchJobDtl(BAJOBDTLID.NEXTVAL,
                                     v_i_bajobid,
                                     '1',
                                     '(DB)SP_BANSF_01：讀取國保給付主檔(NBAPPBASE)發生錯誤，BAAPPBASE.APNO='||v_key_apno||'，NBAPPBASE.APNO='||V_KEY_NBAPNO||'***',
                                     replace(to_Char(SYSTIMESTAMP, 'yyyyMMddHH24missxff'),'.',''));
                --20190827 Add by Angela RecLog End;
        END;

		-------------------------------------------------------------------------------
		-- 依受理編號Apno及序號Seqno取得BAAPPBASE資料
		PROCEDURE p_read_baappbase IS
		BEGIN
			sw_found := TRUE;

			--   DBMS_OUTPUT.put_line('2_1:'||v_key_apno||';');
			SELECT distinct *
			  INTO r_baappbase_rec
			  FROM BAAPPBASE A
			 WHERE apno = v_key_apno
			   and seqno = v_key_seqno;
			--  DBMS_OUTPUT.put_line('2:'||v_key_apno||';');

		EXCEPTION
			WHEN NO_DATA_FOUND THEN
				sw_found := FALSE;
			WHEN OTHERS THEN
				sw_found := FALSE;
				--  log_msg('p_read_baappbase發生錯誤,APNO='||v_key_apno||',錯誤代碼='||sqlcode||','||'錯誤訊息='||SQLERRM);

            --20190827 Add by Angela RecLog Start
            SP_BA_RecBatchJobDtl(BAJOBDTLID.NEXTVAL,
                                 v_i_bajobid,
                                 '1',
                                 '(DB)SP_BANSF_01：讀取勞保給付主檔(BAAPPBASE)發生錯誤，APNO='||v_key_apno||'***',
                                 replace(to_Char(SYSTIMESTAMP, 'yyyyMMddHH24missxff'),'.',''));
            --20190827 Add by Angela RecLog End;
        End;

		-- 依給付主檔資料編號Baappbaseid取得BAAPPBASE資料
		PROCEDURE p_read_baappbase_D IS
		BEGIN
			sw_found := TRUE;

			SELECT distinct *
			  INTO r_baappbase_rec
			  FROM BAAPPBASE A
			 WHERE A.baappbaseid = v_key_baappbaseid;
			--apno = v_key_apno and seqno='0000';
		EXCEPTION
			WHEN NO_DATA_FOUND THEN
				sw_found := FALSE;
			WHEN OTHERS THEN
				sw_found        := FALSE;
				v_exception_cnt := v_exception_cnt + 1;
				log_msg('p_read_baappbase發生錯誤,APNO=' || v_key_apno ||
						',錯誤代碼=' || sqlcode || ',' || '錯誤訊息=' || SQLERRM);
				p_return_code := p_return_code ||
								 'p_read_baappbase發生錯誤,APNO=' || v_key_apno ||
								 ',錯誤代碼=' || sqlcode || ',' || '錯誤訊息=' ||
								 SQLERRM || ',';

		        --20190827 Add by Angela RecLog Start
                SP_BA_RecBatchJobDtl(BAJOBDTLID.NEXTVAL,
                                     v_i_bajobid,
                                     '1',
                                     '(DB)SP_BANSF_01：讀取勞保給付主檔(BAAPPBASE)發生錯誤，APNO='||v_key_apno||'***',
                                     replace(to_Char(SYSTIMESTAMP, 'yyyyMMddHH24missxff'),'.',''));
                --20190827 Add by Angela RecLog End;
        End;
		-------------------------------------------------------------------------------
		-- 依給付主檔資料編號Baappbaseid取得BAAPPEXPAND資料
		PROCEDURE p_read_baappexpand IS
		BEGIN
			sw_found := TRUE;

			SELECT distinct *
			  INTO r_baappexpand_rec
			  FROM baappexpand
			 WHERE BAAPPBASEID = v_key_baappbaseid; --給付主檔資料編號
		EXCEPTION
			WHEN NO_DATA_FOUND THEN
				sw_found := FALSE;
			WHEN OTHERS THEN
				sw_found        := FALSE;
				v_exception_cnt := v_exception_cnt + 1;
				log_msg('p_read_baappexpand發生錯誤,BAAPPBASEID=' ||
						v_key_baappbaseid || ',錯誤代碼=' || sqlcode || ',' ||
						'錯誤訊息=' || SQLERRM);
				p_return_code := p_return_code ||
								 'p_read_baappexpand發生錯誤,BAAPPBASEID=' ||
								 v_key_baappbaseid || ',錯誤代碼=' || sqlcode || ',' ||
								 '錯誤訊息=' || SQLERRM || ',';

		        --20190827 Add by Angela RecLog Start
                SP_BA_RecBatchJobDtl(BAJOBDTLID.NEXTVAL,
                                     v_i_bajobid,
                                     '1',
                                     '(DB)SP_BANSF_01：讀取勞保給付延伸主檔(BAAPPEXPAND)發生錯誤，BAAPPBASEID='||v_key_baappbaseid||'***',
                                     replace(to_Char(SYSTIMESTAMP, 'yyyyMMddHH24missxff'),'.',''));
                --20190827 Add by Angela RecLog End;
        End;
		-------------------------------------------------------------------------------
		--設定年齡組別
		Function F_Agetype(S_Age In Number) Return bansf.agetype%Type Is
			RESULT bansf.agetype%TYPE;
		Begin
			Case
				When S_Age < 15 Then
					Result := '01';
				When S_Age >= 15 And S_Age <= 19 Then
					Result := '02';
				When S_Age >= 20 And S_Age <= 24 Then
					Result := '03';
				When S_Age >= 25 And S_Age <= 29 Then
					Result := '04';
				When S_Age >= 30 And S_Age <= 34 Then
					Result := '05';
				When S_Age >= 35 And S_Age <= 39 Then
					Result := '06';
				When S_Age >= 40 And S_Age <= 44 Then
					Result := '07';
				When S_Age >= 45 And S_Age <= 49 Then
					Result := '08';
				When S_Age >= 50 And S_Age <= 54 Then
					Result := '09';
				When S_Age >= 55 And S_Age <= 59 Then
					Result := '10';
				When S_Age >= 60 And S_Age <= 64 Then
					Result := '11';
				When S_Age >= 65 And S_Age <= 69 Then
					Result := '12';
				When S_Age >= 70 And S_Age <= 74 Then
					Result := '13';
				When S_Age >= 75 And S_Age <= 79 Then
					Result := '14';
				When S_Age >= 80 And S_Age <= 84 Then
					Result := '15';
				When S_Age >= 85 And S_Age <= 89 Then
					Result := '16';
				Else
					Result := '17';
			end case;
			Return Result;
		End;
		-------------------------------------------------------------------------------
		PROCEDURE update_data IS
		Begin
			--取得主檔資料
			R_Badapr_Rec.Evtidnno  := R_Baappbase_Rec.Evtidnno; --'事故者身份證號';
			R_Badapr_Rec.Evtbrdate := R_Baappbase_Rec.Evtbrdate; --'事故者出生日期';
			R_Badapr_Rec.Evtname   := R_Baappbase_Rec.Evtname; --'事故者姓名';
			R_Badapr_Rec.Appdate   := R_Baappbase_Rec.Appdate; --'申請日期';
			R_Badapr_Rec.Edate     := R_Baappbase_Rec.Evtjobdate; --事故日期;
			/*BAAPPBASE.APITEM(申請項目)(payno='5X')
            4-遺屬年金加喪葬津貼=>'1'
            5-遺屬年金=>'1'
            7,8-領取失能年金期間死亡之遺屬年金=>'2'
            9-年資15年且符合老年一次給付之遺屬年金=>'1'*/

			Case
				When R_Baappbase_Rec.Apitem = '4' Then
					V_Str3 := '1';
				When R_Baappbase_Rec.Apitem = '5' Then
					V_Str3 := '1';
				When R_Baappbase_Rec.Apitem = '7' Then
					v_str3 := '2';
				When R_Baappbase_Rec.Apitem = '8' Then
					V_Str3 := '3';
				When R_Baappbase_Rec.Apitem = '9' Then
					V_Str3 := '4';
				Else
					V_Str3 := Null;
			end case;

			If R_Badapr_Rec.Paykind <> 'S' Then
				R_Badapr_Rec.Age := R_Baappbase_Rec.Evtage; --'申請年月-事故者出生年月=申請年齡';     20130320
				if (R_Badapr_Rec.Age is null or R_Badapr_Rec.Age = 0) then
					R_Badapr_Rec.Age := F_Year(substr(R_Baappbase_Rec.appdate,
													  1,
													  6),
											   substr(R_Baappbase_Rec.Evtbrdate,
													  1,
													  6));
				end if;
			end if;

			If R_Badapr_Rec.Paykind = 'S' Then
				--遺屬年金：計算至被保險人死亡年月，以死亡年月-出生年月,取年   20130320
				V_Age            := F_Year(substr(R_Baappbase_Rec.Evtdiedate,
												  1,
												  6),
										   substr(R_Baappbase_Rec.Evtbrdate,
												  1,
												  6)); --'核付年齡';
				R_Badapr_Rec.Age := V_Age;
			Else
				--失能及老年年金：計算至核付年月，以核付年月－出生年月,取年
				V_Age := F_Year(Substr(R_Badapr_Rec.Paydate, 1, 6),
								Substr(R_Baappbase_Rec.Evtbrdate, 1, 6)); --'核付年齡';
			End If;
			V_Str2       := F_Agetype(V_Age); --年齡組別
			v_Evtdiedate := R_Baappbase_Rec.Evtdiedate;

			V_Bdate := F_Bdate(R_Badapr_Rec.Apno,
							   R_Badapr_Rec.Seqno,
							   R_Badapr_Rec.Payym,
							   R_Badapr_Rec.Payno);

			--20131206精算遺屬需求
			IF R_Baappbase_Rec.Closedate IS NOT NULL THEN
				v_edate := SUBSTR(R_Baappbase_Rec.Closedate, 1, 6);
			ELSE
				--20150616 add casetype in ('3','6')
				If (R_Baappbase_Rec.Casetyp = '4') or
				   ((R_Baappbase_Rec.Casetyp = '3' or
				   R_Baappbase_Rec.Casetyp = '6') and
				   R_Baappbase_Rec.Closedate is not null) Then
					v_edate := F_edate(R_Badapr_Rec.Apno,/*
									   R_Badapr_Rec.Seqno,
									   R_Badapr_Rec.Payym,*/
									   R_Badapr_Rec.Payno); --2012/11/30 修改原R_Badapr_Rec.Payym;
				else
					V_Edate := '00000';
				End If;
			END IF;
			--'被保險人國籍別';
			If R_Baappbase_Rec.Evtnationtpe = '2' Then
				R_Badapr_Rec.Evtnationtpe := 'Y';
			Else
				R_Badapr_Rec.Evtnationtpe := 'C';
			End If;
			--'受益人國籍別';
			If R_Baappbase_Rec.BENNATIONTYP = '2' Then
				R_Badapr_Rec.BENNATIONTYP := 'Y';
			Else
				R_Badapr_Rec.BENNATIONTYP := 'C';
			End If;
			R_Badapr_Rec.Apitem     := R_Baappbase_Rec.Apitem; --'申請項目';
			R_Badapr_Rec.Wage       := nvl(R_Baappbase_Rec.Lsinsmamt, 0); --'投保薪資';
			R_Badapr_Rec.Closecause := R_Baappbase_Rec.Closecause; --'結案原因';
			R_Badapr_Rec.Benids     := R_Baappbase_Rec.Benids; --'受益人社福識別碼';
			If R_Baappbase_Rec.APPdate Is Null or
			   R_Baappbase_Rec.Benbrdate Is Null Then
				R_Badapr_Rec.Benage := 0;
			Else
				R_Badapr_Rec.Benage := f_year(substr(R_Baappbase_Rec.APPdate,
													 1,
													 6),
											  substr(R_Baappbase_Rec.BENBRDATE,
													 1,
													 6)); --'申請年月-遺屬出生年月=受益人單齡';
			END IF;
			R_Badapr_Rec.Bensex       := R_Baappbase_Rec.Bensex; --'受益人性別        ';
			R_Badapr_Rec.Bennationtyp := R_Baappbase_Rec.Bennationtyp; --'受益人國籍別      ';
			R_Badapr_Rec.Benevtrel    := R_Baappbase_Rec.Benevtrel; --'受益人與事故者關係';

			/*
            1.失能年金：給付主檔之申請單位保險證號
            2.老年年金：給付主檔之最後單位保險證號
            3.遺屬年金：
            (1)申請項目4、5：給付主檔之申請單位保險證號
            (2)申請項目7、8、9：給付主檔之最後單位保險證號
            */
			Case
				When R_Badapr_Rec.Paykind = 'S' Then
					If R_Badapr_Rec.Apitem In ('4', '5') Then
						R_Badapr_Rec.Ubno := R_Baappbase_Rec.APUBNO;
					Else
						R_BADAPR_REC.UBNO := R_BAAPPBASE_REC.LSUBNO;
					END IF;
				When R_Badapr_Rec.Paykind = 'L' Then
					R_Badapr_Rec.Ubno := R_Baappbase_Rec.Lsubno;
				Else
					R_Badapr_Rec.Ubno := R_Baappbase_Rec.Apubno;
			END CASE;
			IF R_BADAPR_REC.UBNO IS NULL THEN
				R_BADAPR_REC.UBNO := R_BAAPPBASE_REC.LSUBNO;
			END IF;
			V_Key_Ubno := R_Badapr_Rec.Ubno;

			--取得CAUB
			P_Read_Caub;
			R_Badapr_Rec.UBTYPE := nvl(R_Caub_Rec.UBTYPE, 'Z9'); --'單位類別';
			R_Badapr_Rec.Inds   := R_Caub_Rec.Inds; --'小業別';
			R_Badapr_Rec.HINCD  := SUBSTR(R_Caub_Rec.HINCD, 1, 2); --'職災代號';
			R_Badapr_Rec.IDSTA  := R_Caub_Rec.IDSTA; --'大業別';
			R_Badapr_Rec.AREA   := R_Caub_Rec.AREA; --'地區別';
			R_Badapr_Rec.CLSQTY := R_Caub_Rec.PRSNO_B; --'月末人數';

			--取得baappexpand
			P_Read_Baappexpand;
			/*
            --抓取狀態不一情形
            If R_Badapr_Rec.Evtype<>R_Baappexpand_Rec.Evtyp Then
               Log_Msg(R_Badapr_Rec.Apno||';'||R_Badapr_Rec.Evtype||';'||R_Baappexpand_Rec.Evtyp);
            End if;
            */
			if R_Badapr_Rec.Evtype is null then
				R_Badapr_Rec.Evtype := R_Baappexpand_Rec.Evtyp; --  2013/03/11
			end if;
			if R_Badapr_Rec.Evtype is null then
				R_Badapr_Rec.Evtype := '3';
			end if;

			R_Badapr_Rec.Evcode  := r_baappexpand_rec.Evcode; --'事故原因';  BAAPPEXPAND.EVCODE
			R_Badapr_Rec.Injname := R_Baappexpand_Rec.Criinjnme1; --'傷病名稱(國際疾病代碼)';
			R_Badapr_Rec.Injno   := R_Baappexpand_Rec.Criinjdp1; --'障礙(失能)項目';
			R_Badapr_Rec.INJdp   := F_injdp(R_Badapr_Rec.Injno); --'障礙(失能部位)';
			If R_Baappexpand_Rec.Criinissul IS NOT NULL Then
				R_Badapr_Rec.Injcl := R_Baappexpand_Rec.Criinissul; --'失能等級 (身心障礙等級)';  BAAPPEXPAND.CRIINISSUL
			ELSE
				R_Badapr_Rec.Injcl := R_Baappexpand_Rec.CRIINJCL1; --'失能等級 (身心障礙等級)';  BAAPPEXPAND.CRIINISSUL
			END IF;
			R_Badapr_Rec.Injpart   := TRIM(UPPER(r_baappexpand_rec.criinpart1)); --'受傷部位';
			R_Badapr_Rec.Medium    := R_Baappexpand_Rec.Crimedium; --'媒介物';
			R_Badapr_Rec.DedUCtday := R_Baappexpand_Rec.dedUCtday; --S '扣減日數';

			--If (R_Source_Badapr_Rec.Nachgmk Is Null And R_Bappexpand_Rec.Adwkmk='2') or ( R_Source_Badapr_Rec.Nachgmk In ('13','23')) Then
			--     R_Badapr_Rec.Adwkmk:='+';
			--Else    ---因年金與一次金不同故,先暫存為NULL,待SA確認
			--   R_Badapr_Rec.Adwkmk:=nvl(R_Baappexpand_Rec.adwkmk,'1');

			--END IF;
			--符合離職退保後職災殘廢給付職業病種類(Y/N)
			If R_Baappexpand_Rec.Ocaccidentmk = 'Y' Then
				R_Badapr_Rec.CHKKIND := 'Y';
			Else
				R_Badapr_Rec.CHKKIND := 'N';
			End If;
			--20130312
			/*             DBMS_OUTPUT.put_line ('1'||';'||R_Badapr_Rec.ISSUYM||';'||R_Badapr_Rec.payym||';'||R_Badapr_Rec.apno||';'||R_Badapr_Rec.Suprecmk||';'||R_BADAPR_REC.OLDEXTRARATE);

            IF SUBSTR(R_Badapr_Rec.APNO,1,1) IN ('K','S') THEN
                R_Badapr_Rec.oldrate     :=R_BADAPR_REC.OLDEXTRARATE;
            ELSE
                R_Badapr_Rec.oldrate     :=0;
            END IF;*/
			/*2014/02/18 L-老年=>OLDRATE一律給0%
            K-失能=>0人0%，1人25%，>=2人50%
            S-遺屬=>0或1人0%，2人25%，>=3人50%
               */
			if SUBSTR(R_Badapr_Rec.APNO, 1, 1) = 'S' then
				IF R_Badapr_Rec.qualcount = 0 OR
				   R_Badapr_Rec.qualcount is null or
				   R_Badapr_Rec.Qualcount = 1 THEN
					R_Badapr_Rec.oldrate := '0'; --加計比率
				Else
					If R_Badapr_Rec.Qualcount = 2 Then
						R_Badapr_Rec.oldrate := '25'; --加計比率
					ELSE
						R_Badapr_Rec.oldrate := '50'; --加計比率
					End If;
				End If;
			else
				IF R_Badapr_Rec.qualcount = 0 OR
				   R_Badapr_Rec.qualcount is null THEN
					R_Badapr_Rec.oldrate := '0'; --加計比率
				Else
					If R_Badapr_Rec.Qualcount = 1 Then
						R_Badapr_Rec.oldrate := '25'; --加計比率
					ELSE
						R_Badapr_Rec.oldrate := '50'; --加計比率
					End If;
				End If;
			end if; --2014/02/18

			V_Key_Brdate := R_Baappbase_Rec.Evtbrdate;
			V_Key_Name   := R_Baappbase_Rec.Evtname;

		EXCEPTION
			When No_Data_Found THEN
				sw_found := FALSE;
			WHEN OTHERS THEN
				sw_found := FALSE;
				Log_Msg('p_read_baappbase發生錯誤,APNO=' || V_Key_Apno ||
						',錯誤代碼=' || Sqlcode || ',' || '錯誤訊息=' || Sqlerrm);
				p_return_code := p_return_code ||
								 'p_read_baappbase發生錯誤,APNO=' || V_Key_Apno ||
								 ',錯誤代碼=' || Sqlcode || ',' || '錯誤訊息=' ||
								 Sqlerrm || ',';

                --20190827 Add by Angela RecLog Start
                SP_BA_RecBatchJobDtl(BAJOBDTLID.NEXTVAL,
                                     v_i_bajobid,
                                     '1',
                                     '(DB)SP_BANSF_01：讀取勞保給付主檔(BAAPPBASE)、給付核定檔(BADAPR)發生錯誤，APNO='||V_Key_Apno||'***',
                                     replace(to_Char(SYSTIMESTAMP, 'yyyyMMddHH24missxff'),'.',''));
                --20190827 Add by Angela RecLog End;
        End;
		---------------------------------------------------------------------------------
		-- 新資料轉入
		-------------------------------------------------------------------------------
		PROCEDURE p_badapr_proc Is
		Begin
			--EXECUTE IMMEDIATE 'truncate TABLE BANSF_TEMP';
			DELETE BANSF_TEMP;
			COMMIT;
			V_Payym      := Null;
			V_Iisuym     := Null;
			V_Samt       := 0;
			V_Str3       := Null;
			v_Evtdiedate := null;
			For r_bansf_rec_rec In C_BANSF_REF Loop
				v_cat                := null;
				R_Badapr_Rec         := Null;
				R_Badapr_Rec.Paydate := r_bansf_rec_rec.ISSUYM || '01'; --'核付日期';
				R_Badapr_Rec.ISSUYM  := r_bansf_rec_rec.ISSUYM; --'核定年月';
				R_Badapr_Rec.Payym   := R_Bansf_Rec_Rec.Payym; --'給付年月';
				R_Badapr_Rec.Apno    := R_Bansf_Rec_Rec.Apno; --'受理編號';
				R_Badapr_Rec.Payno   := R_Bansf_Rec_Rec.Payno; --'給付種類';           BAAPPBASE        PAYKIND
				R_Badapr_Rec.Paykind := Substr(R_Badapr_Rec.Apno, 1, 1); --'給付別';
				R_Badapr_Rec.Seqno   := '0000'; --'序號';
				R_Badapr_Rec.Edate   := Nvl(R_Bansf_Rec_Rec.Edate, Null);
				--    DBMS_OUTPUT.put_line(R_Badapr_Rec.Apno);
				if R_Badapr_Rec.Edate is null or nvl(R_Badapr_Rec.Edate,' ') = ' ' then
					R_Badapr_Rec.Edate := R_Badapr_Rec.Edate;
				else
					Begin
						R_Badapr_Rec.Edate := R_Badapr_Rec.Edate + 19110000;
					exception
						WHEN OTHERS THEN
							R_Badapr_Rec.Edate := null;
					End;
				End If;
				R_Badapr_Rec.Evtidnno  := R_Bansf_Rec_Rec.Evtidnno; --'事故者身份證號';
				V_Key_Idn              := R_Bansf_Rec_Rec.Evtidnno;
				R_BADAPR_REC.EVTBRDATE := NULL;
				IF R_BANSF_REC_REC.EVTBRDATE IS NOT NULL and
				   length(R_BANSF_REC_REC.EVTBRDATE) < 8 THEN
					Begin
						R_Badapr_Rec.Evtbrdate := R_Bansf_Rec_Rec.Evtbrdate +
												  19110000; --事故者出生日期
					EXCEPTION
						When Others Then
							INSERT INTO BADAPR_REF_ERRL
								SELECT R_BADAPR_REC.APNO,
									   R_BADAPR_REC.PAYYM,
									   V_STR,
									   R_BADAPR_REC.PAMTS,
									   'excel事故者出生日期資料錯誤'
								  FROM DUAL;
					End;
				END IF;

				V_Key_Brdate := R_Badapr_Rec.Evtbrdate;
				V_Key_Name   := R_Badapr_Rec.evtname;
				V_Key_Intyp  := 'L';
				v_key_seqno  := '0000';

				R_Badapr_Rec.Sex := nvl(R_Bansf_Rec_Rec.Sex, 'Z'); --'事故者性別';   base.EVTSEX

				R_Badapr_Rec.EVTYPE    := r_bansf_rec_rec.EVTYPE; --'傷病分類';  BAAPPEXPAND.EVAPPTYP
				R_Badapr_Rec.Evcode    := R_Bansf_Rec_Rec.Evcode; --'事故原因';  BAAPPEXPAND.EVCODE
				R_Badapr_Rec.Injno     := R_Bansf_Rec_Rec.Injno; --'障礙(失能)項目';      BAAPPEXPAND.CRIINJDP1
				R_Badapr_Rec.Injdp     := F_Injdp(R_Badapr_Rec.Injno); --'障礙(失能部位)';
				R_Badapr_Rec.Pamts     := R_Bansf_Rec_Rec.Pamts; --'核付金額';
				R_Badapr_Rec.Age       := 0; --'申請時事故者年齡';
				R_Badapr_Rec.Firstpay  := R_Bansf_Rec_Rec.Firstpay; --'首發註記';
				R_Badapr_Rec.Deduct    := R_Bansf_Rec_Rec.Deduct; --S '扣減金額';
				R_Badapr_Rec.deductday := 0; --S '扣減日數';
				R_Badapr_Rec.PAYDAY    := NVL(R_Bansf_Rec_Rec.PAYDAY, 0); --'給付日數';
				R_Badapr_Rec.Nachgmk   := R_Bansf_Rec_Rec.Nachgmk; --'普職互改註記';
				--'補發收回註記';
				If R_Bansf_Rec_Rec.Suprecmk = '1' Then
					R_Badapr_Rec.Suprecmk := Null;
				Else
					R_Badapr_Rec.Suprecmk := R_Bansf_Rec_Rec.Suprecmk;
				End If;
				/*1.給付種類<>37
                (1)補收註記為C或D不計件數。
                (2)補收註記不為C且不為D，同一核定年月同一受理編號，只計1件(同一受理編號只看同一核定年月，不看其他核定年月，不看給付種類37)
                2.給付種類=37
                (1)補收註記為C，加總給付種類=37，核定年月<本次核定年月之同一受理編號核付金額：
                A.加總金額＞0，不計件數。
                B.加總金額=0，計1件。
                舉例：
                  給付種類  核定年月  APNO              給付金額    補發收回註記  件數
                    37      09805     K00000000016      1,000,000                   1
                    37      09905     K00000000016     -1,000,000        D         -1
                    37      10105     K00000000016        200,000        C          1 不含本次加總金額=100萬 > 0，件數=0,否則,加總=0,件數為1 else 0件
                (2)補收註記為D，加總給付種類=37，核定年月≦本次核定年月之同一受理編號核付金額：
                A.加總金額＞0，不計件數。
                B.加總金額=0，計-1件。
                舉例：
                  給付種類  核定年月  APNO              給付金額    補發收回註記  件數
                    37      09805     K00000000016      1,000,000                   1
                    37      10105     K00000000016       -200,000        D          0  含本次加總金額=80萬 > 0，件數=0
                (3)補收註記不為C且不為D，核付金額>0，計1件。
                         */
				If R_Badapr_Rec.Payno = '37' And
				   R_Badapr_Rec.Suprecmk = 'D' THEN
					V_Samt := V_Samt + R_Badapr_Rec.Pamts;
				END IF;
				Case
					When R_Badapr_Rec.Payno = '37' And
						 R_Badapr_Rec.Suprecmk = 'K' Then
						R_Badapr_Rec.Paycnt := -1;
					When R_Badapr_Rec.Suprecmk = 'K' Then
						R_Badapr_Rec.Paycnt := 0;
					When R_Badapr_Rec.Payno = '37' And
						 R_Badapr_Rec.Suprecmk = 'C' AND V_Samt = 0 Then
						R_Badapr_Rec.Paycnt := 1;
					When R_Badapr_Rec.Payno = '37' And
						 R_Badapr_Rec.Suprecmk = 'C' And V_Samt <> 0 Then
						R_Badapr_Rec.Paycnt := 0;
					When R_Badapr_Rec.Payno = '37' And
						 R_Badapr_Rec.Suprecmk = 'D' AND V_Samt = 0 Then
						R_Badapr_Rec.Paycnt := -1;
					When R_Badapr_Rec.Payno = '37' And
						 R_Badapr_Rec.Suprecmk = 'D' And V_Samt <> 0 Then
						R_Badapr_Rec.Paycnt := 0;
					When R_Badapr_Rec.Payno = '37' And
						 R_Badapr_Rec.Pamts > 0 Then
						R_Badapr_Rec.Paycnt := 1;
					When R_Badapr_Rec.Payno = '37' And
						 R_Badapr_Rec.Pamts <= 0 Then
						R_Badapr_Rec.Paycnt := 0;
					When R_Badapr_Rec.Suprecmk = 'C' Or
						 R_Badapr_Rec.Suprecmk = 'D' Then
						R_Badapr_Rec.Paycnt := 0;
					When V_Apno = R_Badapr_Rec.Apno And
						 V_Iisuym = R_Badapr_Rec.Issuym Then
						R_Badapr_Rec.Paycnt := 0;
					When R_Badapr_Rec.Nachgmk IN ('A', 'B') THEN
						--2013/2/19 --(Nachgmk NOT IN (A,B) AND (Suprecmk IN (d,c) OR PAMTS<=0)) THEN PAYCNT=0
						R_Badapr_Rec.Paycnt := 0;
					When R_Badapr_Rec.Pamts > 0 THEN
						--2013/2/19 --(Nachgmk NOT IN (A,B) AND (Suprecmk IN (d,c) OR PAMTS<=0)) THEN PAYCNT=0
						R_Badapr_Rec.Paycnt := 1;
					Else
						R_Badapr_Rec.Paycnt := 0;
				End Case;
				If NOT (R_Badapr_Rec.Payno = '37' And
					R_Badapr_Rec.Suprecmk = 'D') THEN
					V_Samt := V_Samt + R_Badapr_Rec.Pamts;
				END IF;

				case
					when r_bansf_rec_rec.adwkmk = '+' then
						R_Badapr_Rec.Adwkmk := '2';
					when r_bansf_rec_rec.adwkmk is null then
						R_Badapr_Rec.Adwkmk := '1';
					else
						R_Badapr_Rec.Adwkmk := r_bansf_rec_rec.adwkmk;
				end case;

				If r_bansf_rec_rec.Adwkmk = '2' Then
					V_Key_Intyp := 'V';
				Else
					V_Key_Intyp := 'L';
				end if;

				V_Key_Apno := R_Badapr_Rec.Apno;

				--取得BADAPR or baappbase資料
				V_Str               := 'N';
				R_Source_Badapr_Rec := Null;
				--給付種類5開頭及35,37,存取核定檔,否則存取base
				sw_found_badapr := false;
				IF Substr(R_Badapr_Rec.Payno, 1, 1) = '5' Or
				   R_Badapr_Rec.Payno In ('35', '37', '38') Then
					--          DBMS_OUTPUT.put_line ('1'||';'||R_Badapr_Rec.ISSUYM||';'||R_Badapr_Rec.payym||';'||R_Badapr_Rec.apno||';'||R_Badapr_Rec.Suprecmk);
					For R_Source_Badapr_Rec In C_BAdapr_Suprecmk(R_Badapr_Rec.Apno,
																 R_Badapr_Rec.Payym,
																 R_Badapr_Rec.Suprecmk,
																 R_Badapr_Rec.Payno) Loop
						sw_found_badapr := true;
						V_Str           := 'N';
						If R_Source_Badapr_Rec.Aplpaydate Is Not Null Then
							R_Badapr_Rec.Paydate := C_BADAPR_SUPRECMK_PAYDATE(R_Badapr_Rec.Apno,
																			  R_Badapr_Rec.Issuym,
																			  R_Badapr_Rec.Payym,
																			  R_Badapr_Rec.Suprecmk,
																			  R_Badapr_Rec.Payno,
																			  R_Badapr_Rec.Paydate);
							--R_Badapr_Rec.Paydate       :=R_Source_Badapr_Rec.Aplpaydate;     --'核付日期';
						end if;
						R_Badapr_Rec.NITRMY  := R_Source_Badapr_Rec.NITRMY; --'勞保投保年資(年-年金制)';
						R_Badapr_Rec.Nitrmm  := R_Source_Badapr_Rec.Nitrmm; --'勞保投保年資(月-年金制)';
						R_Badapr_Rec.Pwage   := R_Source_Badapr_Rec.Insavgamt; --'平均薪資';
						R_Badapr_Rec.Mchktyp := R_Source_Badapr_Rec.Mchktyp;
						Case
							When r_bansf_rec_rec.Firstpay = '1' Then
								R_Badapr_Rec.Mchktyp := '1'; --'月核案件類別';
							When R_Source_Badapr_Rec.Mchktyp = '3' Then
								R_Badapr_Rec.Mchktyp := '3'; --'月核案件類別';
							When R_Badapr_Rec.Suprecmk = 'C' Then
								R_Badapr_Rec.Mchktyp := '5'; --'月核案件類別';
							Else
								R_Badapr_Rec.Mchktyp := '2'; --'月核案件類別';
						End Case;
						R_Badapr_Rec.Oldab        := R_Source_Badapr_Rec.Oldab; --'第一式/第二式';
						R_Badapr_Rec.Oldaamt      := R_Source_Badapr_Rec.Oldaamt; --'第一式金額(勞保給付金額)';
						R_Badapr_Rec.Oldbamt      := R_Source_Badapr_Rec.Oldbamt; --'第二式金額(勞保給付金額)';
						R_Badapr_Rec.Qualcount    := R_Source_Badapr_Rec.Qualcount; --'符合眷屬(遺屬)人數';
						R_Badapr_Rec.Annuamt      := Nvl(R_Source_Badapr_Rec.Annuamt,
														 0); --'累計已領年金金額';
						R_Badapr_Rec.CUTAMT       := nvl(R_Source_Badapr_Rec.REMAINAMT,
														 0); --'應扣失能金額';
						R_Badapr_Rec.Lecomamt     := nvl(R_Source_Badapr_Rec.Lecomamt,
														 0); --'己扣失能金額';
						R_Badapr_Rec.Oldextrarate := R_Source_Badapr_Rec.Oldextrarate; --(老年、遺屬)展延/減額比率
						V_Key_Baappbaseid         := R_Source_Badapr_Rec.Baappbaseid; --給付主檔資料編號

						If R_Source_Badapr_Rec.Seqno = '0000' Then
							V_Str           := 'Y';
							V_Out_Temp_Cnt  := 0;
							R_Baappbase_Rec := Null;
							V_Key_Seqno     := R_Source_Badapr_Rec.Seqno;
							P_Read_Baappbase;
							If Sw_Found = False Then
								P_Read_Baappbase_D;
							End If;
							R_Badapr_Rec.Seqno := R_Source_Badapr_Rec.Seqno; --'序號';
							Update_Data;
						Else
							-- 新增眷屬資料
							V_Out_temp_Cnt     := V_Out_temp_Cnt + 1;
							R_Badapr_Rec.Seqno := R_Source_Badapr_Rec.Seqno;
							R_Baappbase_Rec    := Null;
							V_Key_Seqno        := R_Badapr_Rec.Seqno;
							P_Read_Baappbase;
							If Sw_Found = False Then
								P_Read_Baappbase_D;
							End If;
							Update_Data;
							If V_Out_Temp_Cnt <> 1 Then
								R_Badapr_Rec.pamts := 0; --僅第一筆眷屬寫入全數金額
							end if;
						End If;
						--取得cipb
						P_Read_Cipb;
						R_Badapr_Rec.Hbedmk := R_Cipb_Rec.Hbedmk; --'年金施行前有無保險年資';
						--If V_Str='Y' And R_Source_Badapr_Rec.Aplpaymk = '3' Then   未來將加入判別
						-- DBMS_OUTPUT.put_line (V_Str||';'||R_Badapr_Rec.ISSUYM||';'||R_Badapr_Rec.payym||';'||R_Badapr_Rec.apno);
						If V_Str = 'Y' Then
							--有存在seqno=0000才寫入眷屬
							Case
								When R_Badapr_Rec.Evtype = '1' Then
									--變數設定EVTYPE
									V_Str := '3';
								When R_Badapr_Rec.Evtype = '2' Then
									V_Str := '4';
								When R_Badapr_Rec.Evtype = '3' Then
									V_Str := '1';
								Else
									V_Str := '2';
							End Case;
							/*不分給付種類(36除外) 皆用BAAPPBASE.APITEM申請項目判斷
                            項目=7,8  退休條件給"2"-領取失能年金及老年年金中途死亡者
                            項目=9    退休條件給"1"-符合退休條件者
                            其餘      退休條件給"0"-尚未符合退休條件者
                            但給付種類=36 給 " "-空白*/
							Case
								When R_Badapr_Rec.Payno = '36' Then
									V_Cat := Null;
								When R_Badapr_Rec.Apitem In ('7', '8') Then
									V_Cat := '2';
								When R_Badapr_Rec.Apitem = '9' Then
									V_Cat := '1';
								Else
									V_Cat := '0';
							END CASE;

							IF SW_FOUND = TRUE THEN
								IF V_Out_Temp_Cnt = 0 Then
									--僅seqno=0000才新增至年金統計檔
									V_Out_Cnt := V_Out_Cnt + 1;

									Insert Into bansf
										(Select R_Badapr_Rec.Paydate,
												R_Badapr_Rec.Appdate,
												R_Badapr_Rec.Issuym,
												R_Badapr_Rec.Payym,
												R_Badapr_Rec.Apno,
												'0000',
												R_Badapr_Rec.Edate,
												R_Badapr_Rec.Ubno,
												R_Baappbase_Rec.LSUbno,
												R_Badapr_Rec.Ubtype,
												R_Badapr_Rec.Inds,
												R_Badapr_Rec.Hincd,
												R_Badapr_Rec.Idsta,
												R_Badapr_Rec.Area,
												R_Badapr_Rec.Clsqty,
												R_Badapr_Rec.Sex,
												V_Age,
												R_Badapr_Rec.Age,
												V_Str2,
												R_Badapr_Rec.Evtnationtpe,
												R_Badapr_Rec.Payno,
												R_Badapr_Rec.Nitrmy,
												R_Badapr_Rec.Nitrmm,
												R_Badapr_Rec.Evtype,
												R_Badapr_Rec.Evcode,
												R_Badapr_Rec.Injname,
												R_Badapr_Rec.Injno,
												R_Badapr_Rec.Injdp,
												R_Badapr_Rec.Injpart,
												R_Badapr_Rec.Medium,
												R_Badapr_Rec.Injcl,
												R_Badapr_Rec.Apitem,
												R_Badapr_Rec.Chkkind,
												R_Badapr_Rec.Pwage,
												R_Badapr_Rec.Wage,
												R_Badapr_Rec.Paycnt,
												R_Badapr_Rec.Suprecmk,
												R_Badapr_Rec.Pamts,
												R_Badapr_Rec.Adwkmk,
												R_Badapr_Rec.Mchktyp,
												R_Badapr_Rec.Oldab,
												R_Badapr_Rec.Oldaamt,
												R_Badapr_Rec.Oldbamt,
												R_Badapr_Rec.Oldextrarate,
												R_Badapr_Rec.Qualcount,
												R_Badapr_Rec.Oldrate,
												R_Badapr_Rec.Closecause,
												R_Badapr_Rec.Annuamt,
												R_Badapr_Rec.Hbedmk,
												R_Badapr_Rec.Nachgmk,
												R_Badapr_Rec.Cutamt,
												R_Badapr_Rec.Lecomamt,
												R_Badapr_Rec.Paykind,
												DECODE(LENGTH(R_Badapr_Rec.Evtidnno),
													   11,
													   SUBSTR(R_Badapr_Rec.Evtidnno,
															  1,
															  10),
													   R_Badapr_Rec.Evtidnno),
												DECODE(LENGTH(R_Badapr_Rec.Evtidnno),
													   11,
													   SUBSTR(R_Badapr_Rec.Evtidnno,
															  10,
															  1),
													   NULL),
												R_Badapr_Rec.Evtbrdate,
												R_Badapr_Rec.Evtname,
												V_Edate,
												V_Bdate,
												R_Baappbase_Rec.Evtdiedate,
												R_Cipb_Rec.Adjym,
												DECODE(R_Cipb_Rec.Adjmk,
													   NULL,
													   'N',
													   R_Cipb_Rec.Adjmk),
												V_STR3,
												R_Badapr_Rec.firstpay,
												R_Cipb_Rec.CIID,
												0,
												V_Cat,
												0,
												0,
												null,
                                                ''
										   From Dual);
									IF R_Badapr_Rec.Nachgmk In ('A', 'B') Then
										--當存在普職互改註記時,則新增一筆負值資料,並變更EVTYPE
										V_Out_Cnt := V_Out_Cnt + 1;
										INSERT INTO bansf
											(SELECT R_BADAPR_REC.PAYDATE,
													R_BADAPR_REC.APPDATE,
													R_BADAPR_REC.ISSUYM,
													R_BADAPR_REC.PAYYM,
													R_BADAPR_REC.APNO,
													'0000',
													R_BADAPR_REC.EDATE,
													R_BADAPR_REC.UBNO,
													R_BAAPPBASE_REC.LSUBNO,
													R_BADAPR_REC.UBTYPE,
													R_BADAPR_REC.INDS,
													R_BADAPR_REC.HINCD,
													R_BADAPR_REC.IDSTA,
													R_BADAPR_REC.AREA,
													R_BADAPR_REC.CLSQTY,
													R_BADAPR_REC.SEX,
													V_AGE,
													R_BADAPR_REC.AGE,
													V_STR2,
													R_BADAPR_REC.EVTNATIONTPE,
													R_BADAPR_REC.PAYNO,
													R_BADAPR_REC.NITRMY,
													R_BADAPR_REC.NITRMM,
													V_STR,
													R_BADAPR_REC.EVCODE,
													R_BADAPR_REC.INJNAME,
													R_BADAPR_REC.INJNO,
													R_BADAPR_REC.INJDP,
													R_BADAPR_REC.INJPART,
													R_BADAPR_REC.MEDIUM,
													R_BADAPR_REC.INJCL,
													R_BADAPR_REC.APITEM,
													R_BADAPR_REC.CHKKIND,
													R_BADAPR_REC.PWAGE,
													R_BADAPR_REC.WAGE,
													R_BADAPR_REC.PAYCNT * (-1),
													R_BADAPR_REC.SUPRECMK,
													R_BADAPR_REC.PAMTS * (-1),
													R_BADAPR_REC.ADWKMK,
													R_BADAPR_REC.MCHKTYP,
													R_BADAPR_REC.OLDAB,
													R_BADAPR_REC.OLDAAMT,
													R_BADAPR_REC.OLDBAMT,
													R_BADAPR_REC.OLDEXTRARATE,
													R_BADAPR_REC.QUALCOUNT,
													R_BADAPR_REC.OLDRATE,
													R_BADAPR_REC.CLOSECAUSE,
													R_BADAPR_REC.ANNUAMT,
													R_BADAPR_REC.HBEDMK,
													R_BADAPR_REC.NACHGMK,
													R_BADAPR_REC.CUTAMT,
													R_BADAPR_REC.LECOMAMT,
													R_BADAPR_REC.PAYKIND,
													DECODE(LENGTH(R_BADAPR_REC.EVTIDNNO),
														   11,
														   SUBSTR(R_BADAPR_REC.EVTIDNNO,
																  1,
																  10),
														   R_BADAPR_REC.EVTIDNNO),
													DECODE(LENGTH(R_BADAPR_REC.EVTIDNNO),
														   11,
														   SUBSTR(R_BADAPR_REC.EVTIDNNO,
																  10,
																  1),
														   NULL),
													R_BADAPR_REC.EVTBRDATE,
													R_BADAPR_REC.EVTNAME,
													V_EDATE,
													V_BDATE,
													R_BAAPPBASE_REC.EVTDIEDATE,
													R_CIPB_REC.ADJYM,
													DECODE(R_CIPB_REC.ADJMK,
														   NULL,
														   'N',
														   R_CIPB_REC.ADJMK),
													V_STR3,
													R_BADAPR_REC.FIRSTPAY,
													R_CIPB_REC.CIID,
													0,
													V_CAT,
													0,
													0,
													null,
                                                    ''
											   FROM DUAL);
									END IF;
									--2014/04/28
									IF R_Source_Badapr_Rec.Seqno = '0000' AND
									   Substr(R_Badapr_Rec.Payno, 1, 1) = '3' AND
									   R_Baappbase_Rec.Evtdiedate IS NOT NULL THEN
										Insert Into bansf_TEMP
											(Select R_Badapr_Rec.Paydate,
													R_Badapr_Rec.Appdate,
													R_Badapr_Rec.Issuym,
													R_Badapr_Rec.Payym,
													R_Badapr_Rec.Apno,
													'0000',
													R_Badapr_Rec.Edate,
													R_Badapr_Rec.Ubno,
													R_Baappbase_Rec.LSUbno,
													R_Badapr_Rec.Ubtype,
													R_Badapr_Rec.Inds,
													R_Badapr_Rec.Hincd,
													R_Badapr_Rec.Idsta,
													R_Badapr_Rec.Area,
													R_Badapr_Rec.Clsqty,
													R_Badapr_Rec.Sex,
													V_Age,
													R_Badapr_Rec.Age,
													V_Str2,
													R_Badapr_Rec.Evtnationtpe,
													R_Badapr_Rec.Payno,
													R_Badapr_Rec.Nitrmy,
													R_Badapr_Rec.Nitrmm,
													R_Badapr_Rec.Evtype,
													R_Badapr_Rec.Evcode,
													R_Badapr_Rec.Injname,
													R_Badapr_Rec.Injno,
													R_Badapr_Rec.Injdp,
													R_Badapr_Rec.Injpart,
													R_Badapr_Rec.Medium,
													R_Badapr_Rec.Injcl,
													R_Badapr_Rec.Apitem,
													R_Badapr_Rec.Chkkind,
													R_Badapr_Rec.Pwage,
													R_Badapr_Rec.Wage,
													R_Badapr_Rec.Paycnt,
													R_Badapr_Rec.Suprecmk,
													R_Badapr_Rec.Pamts,
													R_Badapr_Rec.Adwkmk,
													R_Badapr_Rec.Mchktyp,
													R_Badapr_Rec.Oldab,
													R_Badapr_Rec.Oldaamt,
													R_Badapr_Rec.Oldbamt,
													R_Badapr_Rec.Oldextrarate,
													R_Badapr_Rec.Qualcount,
													R_Badapr_Rec.Oldrate,
													R_Badapr_Rec.Closecause,
													R_Badapr_Rec.Annuamt,
													R_Badapr_Rec.Hbedmk,
													R_Badapr_Rec.Nachgmk,
													R_Badapr_Rec.Cutamt,
													R_Badapr_Rec.Lecomamt,
													R_Badapr_Rec.Paykind,
													DECODE(LENGTH(R_Badapr_Rec.Evtidnno),
														   11,
														   SUBSTR(R_Badapr_Rec.Evtidnno,
																  1,
																  10),
														   R_Badapr_Rec.Evtidnno),
													DECODE(LENGTH(R_Badapr_Rec.Evtidnno),
														   11,
														   SUBSTR(R_Badapr_Rec.Evtidnno,
																  10,
																  1),
														   NULL),
													R_Badapr_Rec.Evtbrdate,
													R_Badapr_Rec.Evtname,
													V_Edate,
													V_Bdate,
													R_Baappbase_Rec.Evtdiedate,
													R_Cipb_Rec.Adjym,
													DECODE(R_Cipb_Rec.Adjmk,
														   NULL,
														   'N',
														   R_Cipb_Rec.Adjmk),
													V_STR3,
													R_Badapr_Rec.firstpay,
													R_Cipb_Rec.CIID,
													0,
													V_Cat,
													0,
													0,
													null
											   From Dual);
									END IF;
								END IF;
								--異常資料建入badapr_ref_errl
								If R_Badapr_Rec.Nachgmk In ('A', 'B') and
								   f_data(R_Badapr_Rec.Apno,
										  R_Badapr_Rec.Payym) > 0 Then
									--當存在普職互改註記時,
									--找尋同給付月份,且Nachgmk為NULL的資料,當資料不存在,則異常資料建入badapr_ref_errl
									INSERT INTO BADAPR_REF_ERRL
										SELECT R_BADAPR_REC.APNO,
											   R_BADAPR_REC.PAYYM,
											   V_STR,
											   R_BADAPR_REC.PAMTS,
											   '為普職註記,但找不到正常本月資料'
										  FROM DUAL;
								END IF;
								INSERT INTO BADAPR_REF VALUES R_BADAPR_REC;
								IF R_BADAPR_REC.NACHGMK IN ('A', 'B') THEN
									--當存在普職互改註記時,則新增一筆負值資料,並變更EVTYPE
									R_Badapr_Rec.PAYcnt := R_Badapr_Rec.PAYcnt * -1;
									R_BADAPR_REC.PAMTS  := R_BADAPR_REC.PAMTS * -1;
									R_BADAPR_REC.EVTYPE := V_STR;
									INSERT INTO BADAPR_REF
									VALUES R_BADAPR_REC;
								END IF;
							end if;
							V_Str := 'Y'; --中間有更動,回寫為正常值
						Else
							V_Str := 'N';
							/*  未來將加入判別
                            If V_Str='Y' Then
                                  --找尋不到原資料,寫入異常
                                Insert Into Badapr_Ref_Errl Select R_Badapr_Rec.Apno,R_Badapr_Rec.Payym,R_Badapr_Rec.Evtype,R_Badapr_Rec.Pamts,'在BADAPR帳務註記不為3資料' From Dual;
                             End If;  */
						End If;
					End Loop;
					If V_Str = 'N' Then
						--找尋不到原資料,寫入異常
						Insert Into Badapr_Ref_Errl
							Select R_Badapr_Rec.Apno,
								   R_Badapr_Rec.Payym,
								   R_Badapr_Rec.Evtype,
								   R_Badapr_Rec.Pamts,
								   '在BADAPR找不到資料'
							  From Dual;
					END IF;
				end if;
				if sw_found_badapr = false then
					--Dbms_Output.Put_Line(R_Badapr_Rec.Apno||','||R_Badapr_Rec.Payym);
					R_Baappbase_Rec := Null;
					--For R_Source_Baappbase_Rec In C_Baappbase(R_Badapr_Rec.Apno,R_Badapr_Rec.Payym)
					For R_Source_Baappbase_Rec In C_Baappbase(R_Badapr_Rec.Apno) Loop
						-- If R_Source_Baappbase_Rec.Paydate Is Not Null Then
						--     R_Badapr_Rec.Paydate       :=R_Source_Baappbase_Rec.Paydate;     --'核付日期';
						-- end if;
						R_Badapr_Rec.Pwage := R_Bansf_Rec_Rec.PWAGE; --'平均薪資';
						Case
							When r_bansf_rec_rec.Firstpay = '1' Then
								R_Badapr_Rec.Mchktyp := '1'; --'月核案件類別';
							When R_Source_Baappbase_Rec.CASETYP = '3' Then
								R_Badapr_Rec.Mchktyp := '3'; --'月核案件類別';
							When R_Source_Baappbase_Rec.CASETYP = '5' Then
								R_Badapr_Rec.Mchktyp := '5'; --'月核案件類別';
							Else
								R_Badapr_Rec.Mchktyp := '2'; --'月核案件類別';
						End Case;
						R_Badapr_Rec.Oldab        := NULL; --'第一式/第二式';
						R_Badapr_Rec.Oldaamt      := 0; --'第一式金額(勞保給付金額)';
						R_Badapr_Rec.Oldbamt      := 0; --'第二式金額(勞保給付金額)';
						R_Badapr_Rec.Qualcount    := 0; --'符合眷屬(遺屬)人數';
						R_Badapr_Rec.Annuamt      := nvl(R_Source_Baappbase_Rec.Annuamt,
														 0); --'累計已領年金金額';
						R_Badapr_Rec.Lecomamt     := 0; --'己扣失能金額';
						R_Badapr_Rec.Oldextrarate := 0; --(老年、遺屬)展延/減額比率
						V_Key_Baappbaseid         := R_Source_Baappbase_Rec.Baappbaseid; --給付主檔資料編號

						If R_Source_Baappbase_Rec.Seqno = '0000' Then
							V_Str              := 'Y';
							V_Out_Temp_Cnt     := 0;
							R_Badapr_Rec.Seqno := R_Source_Baappbase_Rec.Seqno;
							R_Baappbase_Rec    := R_Source_Baappbase_Rec; --供update_data使用
							Update_Data;
						Else
							-- 新增眷屬資料
							V_Out_Temp_Cnt     := V_Out_Temp_Cnt + 1;
							R_Badapr_Rec.Seqno := R_Source_Baappbase_Rec.Seqno;
							R_Baappbase_Rec    := R_Source_Baappbase_Rec; --供update_data使用
							Update_Data;
							If V_Out_Temp_Cnt <> 1 Then
								R_Badapr_Rec.pamts := 0; --僅第一筆眷屬寫入全數金額
							end if;
						End If;
						--取得cipb;
						V_Key_Brdate := R_Baappbase_Rec.Evtbrdate;
						v_key_name   := R_Baappbase_Rec.evtname;
						/*If  r_bansf_rec_rec.Adwkmk='2' Then
                            V_Key_Intyp:= 'V';
                        Else
                            V_Key_Intyp:= 'L';
                        END IF;   */

						P_READ_CIPB;
						R_BADAPR_REC.HBEDMK := R_Cipb_Rec.Hbedmk; --'年金施行前有無保險年資';
						R_BADAPR_REC.NITRMY := R_CIPB_REC.NITRMY; --'勞保投保年資(年-年金制)';
						R_BADAPR_REC.NITRMM := R_CIPB_REC.NITRMM; --'勞保投保年資(月-年金制)';

						-- Dbms_Output.Put_Line('2.');
						If V_Str = 'Y' Then
							--有存在seqno=0000才寫入眷屬
							Case
								When R_Badapr_Rec.Evtype = '1' Then
									--變數設定EVTYPE
									V_Str := '3';
								When R_Badapr_Rec.Evtype = '2' Then
									V_Str := '4';
								When R_Badapr_Rec.Evtype = '3' Then
									V_Str := '1';
								Else
									V_Str := '2';
							End Case;
							/*不分給付種類(36除外) 皆用BAAPPBASE.APITEM申請項目判斷
                            項目=7,8  退休條件給"2"-領取失能年金及老年年金中途死亡者
                            項目=9    退休條件給"1"-符合退休條件者
                            其餘      退休條件給"0"-尚未符合退休條件者
                            但給付種類=36 給 " "-空白*/
							Case
								When R_Badapr_Rec.Payno = '36' Then
									V_Cat := Null;
								ELSE
									V_Cat := '0';
							END CASE;

							If V_Out_Temp_Cnt = 0 Then
								--僅seqno=0000才新增至年金統計檔
								V_Out_Cnt := V_Out_Cnt + 1;
								Insert Into bansf
									(Select R_Badapr_Rec.Paydate,
											R_Badapr_Rec.Appdate,
											R_Badapr_Rec.Issuym,
											R_Badapr_Rec.Payym,
											R_Badapr_Rec.Apno,
											'0000',
											R_Badapr_Rec.Edate,
											R_Badapr_Rec.Ubno,
											R_Source_Baappbase_Rec.LSUbno,
											R_Badapr_Rec.Ubtype,
											R_Badapr_Rec.Inds,
											R_Badapr_Rec.Hincd,
											R_Badapr_Rec.Idsta,
											R_Badapr_Rec.Area,
											R_Badapr_Rec.Clsqty,
											R_Badapr_Rec.Sex,
											V_Age,
											R_Badapr_Rec.Age,
											V_Str2,
											R_Badapr_Rec.Evtnationtpe,
											R_Badapr_Rec.Payno,
											R_Badapr_Rec.Nitrmy,
											R_Badapr_Rec.Nitrmm,
											R_Badapr_Rec.Evtype,
											R_Badapr_Rec.Evcode,
											R_Badapr_Rec.Injname,
											R_Badapr_Rec.Injno,
											R_Badapr_Rec.Injdp,
											R_Badapr_Rec.Injpart,
											R_Badapr_Rec.Medium,
											R_Badapr_Rec.Injcl,
											R_Badapr_Rec.Apitem,
											R_Badapr_Rec.Chkkind,
											R_Badapr_Rec.Pwage,
											R_Badapr_Rec.Wage,
											R_Badapr_Rec.Paycnt,
											R_Badapr_Rec.Suprecmk,
											R_Badapr_Rec.Pamts,
											R_Badapr_Rec.Adwkmk,
											R_Badapr_Rec.Mchktyp,
											R_Badapr_Rec.Oldab,
											R_Badapr_Rec.Oldaamt,
											R_Badapr_Rec.Oldbamt,
											R_Badapr_Rec.Oldextrarate,
											R_Badapr_Rec.Qualcount,
											R_Badapr_Rec.Oldrate,
											R_Badapr_Rec.Closecause,
											R_Badapr_Rec.Annuamt,
											R_Badapr_Rec.Hbedmk,
											R_Badapr_Rec.Nachgmk,
											R_Badapr_Rec.Cutamt,
											R_Badapr_Rec.Lecomamt,
											R_Badapr_Rec.Paykind,
											DECODE(LENGTH(R_Badapr_Rec.Evtidnno),
												   11,
												   SUBSTR(R_Badapr_Rec.Evtidnno,
														  1,
														  10),
												   R_Badapr_Rec.Evtidnno),
											DECODE(LENGTH(R_Badapr_Rec.Evtidnno),
												   11,
												   SUBSTR(R_Badapr_Rec.Evtidnno,
														  10,
														  1),
												   NULL),
											R_Baappbase_Rec.Evtbrdate,
											R_Badapr_Rec.Evtname,
											V_Edate,
											V_Bdate,
											R_Source_Baappbase_Rec.Evtdiedate,
											R_Cipb_Rec.Adjym,
											R_Cipb_Rec.Adjmk,
											v_str3,
											R_Badapr_Rec.firstpay,
											R_Cipb_Rec.CIID,
											0,
											V_Cat,
											0,
											0,
											null,
                                            ''
									   From Dual);
								--2014/04/28 SEQNO=0000
								IF R_Source_Baappbase_Rec.Evtdiedate IS NOT NULL AND
								   Substr(R_Badapr_Rec.Payno, 1, 1) = '3' THEN
									Insert Into bansf_TEMP
										(Select R_Badapr_Rec.Paydate,
												R_Badapr_Rec.Appdate,
												R_Badapr_Rec.Issuym,
												R_Badapr_Rec.Payym,
												R_Badapr_Rec.Apno,
												'0000',
												R_Badapr_Rec.Edate,
												R_Badapr_Rec.Ubno,
												R_Source_Baappbase_Rec.LSUbno,
												R_Badapr_Rec.Ubtype,
												R_Badapr_Rec.Inds,
												R_Badapr_Rec.Hincd,
												R_Badapr_Rec.Idsta,
												R_Badapr_Rec.Area,
												R_Badapr_Rec.Clsqty,
												R_Badapr_Rec.Sex,
												V_Age,
												R_Badapr_Rec.Age,
												V_Str2,
												R_Badapr_Rec.Evtnationtpe,
												R_Badapr_Rec.Payno,
												R_Badapr_Rec.Nitrmy,
												R_Badapr_Rec.Nitrmm,
												R_Badapr_Rec.Evtype,
												R_Badapr_Rec.Evcode,
												R_Badapr_Rec.Injname,
												R_Badapr_Rec.Injno,
												R_Badapr_Rec.Injdp,
												R_Badapr_Rec.Injpart,
												R_Badapr_Rec.Medium,
												R_Badapr_Rec.Injcl,
												R_Badapr_Rec.Apitem,
												R_Badapr_Rec.Chkkind,
												R_Badapr_Rec.Pwage,
												R_Badapr_Rec.Wage,
												R_Badapr_Rec.Paycnt,
												R_Badapr_Rec.Suprecmk,
												R_Badapr_Rec.Pamts,
												R_Badapr_Rec.Adwkmk,
												R_Badapr_Rec.Mchktyp,
												R_Badapr_Rec.Oldab,
												R_Badapr_Rec.Oldaamt,
												R_Badapr_Rec.Oldbamt,
												R_Badapr_Rec.Oldextrarate,
												R_Badapr_Rec.Qualcount,
												R_Badapr_Rec.Oldrate,
												R_Badapr_Rec.Closecause,
												R_Badapr_Rec.Annuamt,
												R_Badapr_Rec.Hbedmk,
												R_Badapr_Rec.Nachgmk,
												R_Badapr_Rec.Cutamt,
												R_Badapr_Rec.Lecomamt,
												R_Badapr_Rec.Paykind,
												DECODE(LENGTH(R_Badapr_Rec.Evtidnno),
													   11,
													   SUBSTR(R_Badapr_Rec.Evtidnno,
															  1,
															  10),
													   R_Badapr_Rec.Evtidnno),
												DECODE(LENGTH(R_Badapr_Rec.Evtidnno),
													   11,
													   SUBSTR(R_Badapr_Rec.Evtidnno,
															  10,
															  1),
													   NULL),
												R_Baappbase_Rec.Evtbrdate,
												R_Badapr_Rec.Evtname,
												V_Edate,
												V_Bdate,
												R_Source_Baappbase_Rec.Evtdiedate,
												R_Cipb_Rec.Adjym,
												R_Cipb_Rec.Adjmk,
												v_str3,
												R_Badapr_Rec.firstpay,
												R_Cipb_Rec.CIID,
												0,
												V_Cat,
												0,
												0,
												null
										   From Dual);
								END IF;
								IF R_Badapr_Rec.Nachgmk In ('A', 'B') Then
									--當存在普職互改註記時,則新增一筆負值資料,並變更EVTYPE
									V_Out_Cnt := V_Out_Cnt + 1;
									Insert Into bansf
										(Select R_Badapr_Rec.Paydate,
												R_Badapr_Rec.Appdate,
												R_Badapr_Rec.Issuym,
												R_Badapr_Rec.Payym,
												R_Badapr_Rec.Apno,
												'0000',
												R_Badapr_Rec.Edate,
												R_Badapr_Rec.Ubno,
												R_Source_Baappbase_Rec.LSUBNO,
												R_Badapr_Rec.Ubtype,
												R_Badapr_Rec.Inds,
												R_Badapr_Rec.Hincd,
												R_Badapr_Rec.Idsta,
												R_Badapr_Rec.Area,
												R_Badapr_Rec.Clsqty,
												R_Badapr_Rec.Sex,
												V_AGE,
												R_Badapr_Rec.Age,
												V_Str2,
												R_Badapr_Rec.Evtnationtpe,
												R_Badapr_Rec.Payno,
												R_Badapr_Rec.Nitrmy,
												R_Badapr_Rec.Nitrmm,
												V_Str,
												R_Badapr_Rec.Evcode,
												R_Badapr_Rec.Injname,
												R_Badapr_Rec.Injno,
												R_Badapr_Rec.INJDP,
												R_Badapr_Rec.Injpart,
												R_Badapr_Rec.Medium,
												R_Badapr_Rec.Injcl,
												R_Badapr_Rec.Apitem,
												R_Badapr_Rec.Chkkind,
												R_Badapr_Rec.Pwage,
												R_Badapr_Rec.Wage,
												R_Badapr_Rec.Paycnt * (-1),
												R_Badapr_Rec.Suprecmk,
												R_Badapr_Rec.Pamts * (-1),
												R_Badapr_Rec.Adwkmk,
												R_Badapr_Rec.Mchktyp,
												R_Badapr_Rec.Oldab,
												R_Badapr_Rec.Oldaamt,
												R_Badapr_Rec.Oldbamt,
												R_Badapr_Rec.Oldextrarate,
												R_Badapr_Rec.Qualcount,
												R_Badapr_Rec.Oldrate,
												R_Badapr_Rec.Closecause,
												R_Badapr_Rec.Annuamt,
												R_Badapr_Rec.Hbedmk,
												R_Badapr_Rec.Nachgmk,
												R_Badapr_Rec.Cutamt,
												R_Badapr_Rec.Lecomamt,
												R_Badapr_Rec.Paykind,
												DECODE(LENGTH(R_Badapr_Rec.Evtidnno),
													   11,
													   SUBSTR(R_Badapr_Rec.Evtidnno,
															  1,
															  10),
													   R_Badapr_Rec.Evtidnno),
												DECODE(LENGTH(R_Badapr_Rec.Evtidnno),
													   11,
													   SUBSTR(R_Badapr_Rec.Evtidnno,
															  10,
															  1),
													   NULL),
												R_Baappbase_Rec.Evtbrdate,
												R_Badapr_Rec.Evtname,
												v_edate,
												v_bdate,
												R_Source_Baappbase_Rec.Evtdiedate,
												R_Cipb_Rec.Adjym,
												R_Cipb_Rec.Adjmk,
												v_str3,
												R_Badapr_Rec.firstpay,
												R_Cipb_Rec.CIID,
												0,
												V_Cat,
												0,
												0,
												null,
                                                ''
										   From Dual);
								END IF;
							End If;
							--異常資料建入badapr_ref_errl
							If R_Badapr_Rec.Nachgmk In ('A', 'B') And
							   F_Data(R_Badapr_Rec.Apno, R_Badapr_Rec.Payym) > 0 Then
								--當存在普職互改註記時,
								--找尋同給付月份,且Nachgmk為NULL的資料,當資料不存在,則異常資料建入badapr_ref_errl
								Insert Into Badapr_Ref_Errl
									Select R_Badapr_Rec.Apno,
										   R_Badapr_Rec.Payym,
										   V_Str,
										   R_Badapr_Rec.Pamts,
										   '為普職註記,但找不到正常本月資料'
									  From Dual;
							End If;
							Insert Into Badapr_Ref Values R_Badapr_Rec;
							If R_Badapr_Rec.Nachgmk In ('A', 'B') Then
								--當存在普職互改註記時,則新增一筆負值資料,並變更EVTYPE
								--   Dbms_Output.Put_Line('3.2'||';'||R_Badapr_Rec.Payym||';'||R_Badapr_Rec.Seqno);
								R_Badapr_Rec.Paycnt := R_Badapr_Rec.Paycnt * -1;
								R_Badapr_Rec.Pamts  := R_Badapr_Rec.Pamts * -1;
								R_Badapr_Rec.Evtype := V_Str;
								INSERT INTO BADAPR_REF VALUES R_BADAPR_REC;
							End If;
						END IF;
						V_STR := 'Y'; --中間有更動,回寫為正常值
					End Loop;
					If V_Str = 'N' Then
						--找尋不到原資料,寫入異常
						Insert Into Badapr_Ref_Errl
							Select R_Badapr_Rec.Apno,
								   R_Badapr_Rec.Payym,
								   R_Badapr_Rec.Evtype,
								   R_Badapr_Rec.Pamts,
								   '在BAAPPBASE找不到資料'
							  From Dual;
					End If;
				End If;
				IF V_STR = 'N' THEN
					--資料不存在badapr,baappbase,55,37,38,39重找baappbase
					R_Badapr_Rec.UBNO    := r_bansf_rec_rec.UBNO; --保險證號
					R_Badapr_Rec.Injcl   := R_Bansf_Rec_Rec.Injcl; --失能等級 (身心障礙等級)
					R_Badapr_Rec.Seqno   := '0000'; --序號
					R_Badapr_Rec.Age     := F_Year(Substr(R_Badapr_Rec.Appdate,
														  1,
														  6),
												   Substr(R_Badapr_Rec.Evtbrdate,
														  1,
														  6)); --'申請年月-事故者出生年月=年齡';
					R_Badapr_Rec.PWAGE   := nvl(r_bansf_rec_rec.PWAGE, 0); --平均薪資
					R_Badapr_Rec.APPDATE := r_bansf_rec_rec.APPDATE; --申請日期
					--原excel不存在的欄位如下:
					R_Badapr_Rec.Paydate := R_Bansf_Rec_Rec.Issuym || '01'; --核付日期
					If R_Badapr_Rec.Ubno Is Not Null Then
						V_Key_Ubno := R_Badapr_Rec.Ubno;
						P_Read_Caub;
						R_Badapr_Rec.Ubtype := R_Caub_Rec.Ubtype; --'單位類別';
						R_Badapr_Rec.Inds   := R_Caub_Rec.Inds; --'小業別';
						R_Badapr_Rec.Hincd  := Substr(R_Caub_Rec.Hincd,
													  1,
													  2); --'職災代號';
						R_Badapr_Rec.Idsta  := R_Caub_Rec.Idsta; --'大業別';
						R_Badapr_Rec.Area   := R_Caub_Rec.Area; --'地區別';
						R_Badapr_Rec.Clsqty := R_Caub_Rec.Prsno_B; --'月末人數';
					End If;
					R_Badapr_Rec.EVTNATIONTPE := 'C'; --被保險人國籍別
					R_Badapr_Rec.INJNAME      := 'Z999999'; --傷病名稱(國際疾病代碼)
					R_Badapr_Rec.INJDP        := 'Z99'; --障礙(失能部位)
					R_BADAPR_REC.INJPART      := 'Z99'; --受傷部位
					R_Badapr_Rec.MEDIUM       := 'Z99'; --媒介物
					R_BADAPR_REC.APITEM       := 'Z'; --申請項目
					R_Badapr_Rec.CHKKIND      := 'N'; --"符合離職退保後職災殘廢給付職業病種類(Y/N)"                                                 ;
					R_Badapr_Rec.Wage         := 0; --投保薪資
					R_Badapr_Rec.Adwkmk       := nvl(r_bansf_rec_rec.adwkmk,
													 '1'); --加職註記
					R_Badapr_Rec.Evtname      := Null; --事故者姓名
					--R_Badapr_Rec.MCHKTYP       :='Z'                           ;  --月核案件類別
					Case
						When R_Badapr_Rec.FIRSTPAY = '1' Then
							R_Badapr_Rec.Mchktyp := '1'; --'月核案件類別';
						When R_Badapr_Rec.FIRSTPAY = '0' Then
							---36的EXCEL下續發案給0
							R_Badapr_Rec.Mchktyp := '2'; --'月核案件類別';
						When R_Bansf_Rec_Rec.Suprecmk = 'C' Then
							R_Badapr_Rec.Mchktyp := '5'; --'月核案件類別';
						Else
							R_Badapr_Rec.Mchktyp := '2'; --'月核案件類別' 無抓到核定檔.月核案件類別3,故3無法判別;
					End Case;
					V_Str2 := Null; --年齡組別
					Case
						WHEN v_Evtdiedate Is Null And
							 R_Bansf_Rec_Rec.EDATE Is Not Null and
							 R_Badapr_Rec.Paykind = 'S' THEN
							Begin
								If Length(R_Bansf_Rec_Rec.EDATE) < 8 Then
									v_Evtdiedate := R_Bansf_Rec_Rec.EDATE +
													19110000; --事故者死亡日期
								Else
									v_Evtdiedate := R_Bansf_Rec_Rec.EDATE; --事故者死亡日期
								end if;
								--遺屬年金：計算至被保險人死亡年月，以死亡年月-事故者出生日期,取年
								V_Age            := F_Year(Substr(v_Evtdiedate,
																  1,
																  6),
														   Substr(R_Bansf_Rec_Rec.Evtbrdate,
																  1,
																  6)); --'核付年齡';
								R_Badapr_Rec.Age := V_Age;
							Exception
								When Others Then
									v_Evtdiedate := R_Bansf_Rec_Rec.EDATE; --事故者死亡日期
									Insert Into Badapr_Ref_Errl
										Select R_Badapr_Rec.Apno,
											   R_Badapr_Rec.Payym,
											   V_Str,
											   R_Badapr_Rec.Pamts,
											   '事故者死亡日期資料錯誤'
										  From Dual;
							End;
						WHEN R_Badapr_Rec.Evtbrdate Is Null And
							 R_Bansf_Rec_Rec.Evtbrdate Is Not Null and
							 R_Badapr_Rec.Paykind <> 'S' THEN
							Begin
								If Length(R_Bansf_Rec_Rec.Evtbrdate) < 8 Then
									R_Badapr_Rec.Evtbrdate := R_Bansf_Rec_Rec.Evtbrdate +
															  19110000; --事故者出生日期
								Else
									R_Badapr_Rec.Evtbrdate := R_Bansf_Rec_Rec.Evtbrdate; --事故者出生日期
								end if;
								--失能及老年年金：計算至核付年月，以核付年月－出生年月,取年
								V_Age := F_Year(Substr(R_Badapr_Rec.paydate,
													   1,
													   6),
												Substr(R_Badapr_Rec.Evtbrdate,
													   1,
													   6)); --'核付年齡';
							EXCEPTION
								When Others Then
									R_Badapr_Rec.Evtbrdate := R_Bansf_Rec_Rec.Evtbrdate; --事故者出生日期
									Insert Into Badapr_Ref_Errl
										Select R_Badapr_Rec.Apno,
											   R_Badapr_Rec.Payym,
											   V_Str,
											   R_Badapr_Rec.Pamts,
											   '事故者出生日期資料錯誤'
										  From Dual;
							End;
						else
							v_age := 0;
					END CASE;

					V_Str2     := F_Agetype(V_Age); --年齡組別
					R_CIPB_REC := NULL;
					IF R_BADAPR_REC.PAYNO = '36' THEN
						R_BADAPR_REC.NITRMY := r_bansf_rec_rec.NITRMY; --勞保投保年資(年-年金制)
						R_BADAPR_REC.NITRMM := R_BANSF_REC_REC.NITRMM; --勞保投保年資(月-年金制)
						V_KEY_NBAPNO        := R_BANSF_REC_REC.NBAPNO;
						R_BADAPR_REC.APITEM := '0'; --申請項目
						P_READ_NBAAPPBASE;
						IF sw_found = TRUE THEN
							R_BADAPR_REC.EDATE     := R_NBAPPBASE_REC.EVTDT; --事故日期;
							R_BADAPR_REc.EVTBRDATE := R_NBAPPBASE_REC.EVTEEBIRT; --生日;
							R_BADAPR_REC.EVTIDNNO  := R_NBAPPBASE_REC.EVTIDNNO; -- 身份證號;
							R_Badapr_Rec.Evtname   := R_NBAPPBASE_REC.Evteename; --'事故者姓名';
						ELSE
							R_BADAPR_REc.EVTBRDATE := r_bansf_rec_rec.EVTBRDATE; --生日;
							R_BADAPR_REC.EVTIDNNO  := r_bansf_rec_rec.EVTIDNNO; -- 身份證號;
							--     R_Badapr_Rec.Evtname       :=r_bansf_rec_rec.Evtname;     --'事故者姓名';
						END IF;
						--36  20130320
						V_Age := F_Year(Substr(R_Badapr_Rec.paydate, 1, 6),
										Substr(R_Badapr_Rec.Evtbrdate, 1, 6)); --'核付年齡';

						CASE
							WHEN SUBSTR(R_BADAPR_REC.EVTIDNNO, 2, 1) = '1' THEN
								R_BADAPR_REC.SEX := '1';
							WHEN SUBSTR(R_BADAPR_REC.EVTIDNNO, 2, 1) = '2' THEN
								R_BADAPR_REC.SEX := '2';
							ELSE
								R_BADAPR_REC.SEX := 'Z';
						END CASE;
						V_Key_Idn    := R_BADAPR_REC.EVTIDNNO;
						v_key_name   := R_Badapr_Rec.Evtname;
						V_Key_Intyp  := 'L';
						v_key_brdate := R_BADAPR_REc.EVTBRDATE;

						P_READ_CIPB;
						--36國併勞：計算申請日-生日       20130320
						R_Badapr_Rec.AGE    := F_YEAR(SUBSTR(R_BADAPR_REC.appdate,
															 1,
															 6),
													  SUBSTR(R_BADAPR_REc.EVTBRDATE,
															 1,
															 6)); --'年齡';
						R_BADAPR_REC.HBEDMK := R_CIPB_REC.HBEDMK; --'年金施行前有無保險年資';
						R_BADAPR_REC.NITRMY := R_CIPB_REC.NITRMY; --勞保投保年資(年-年金制)
						R_BADAPR_REC.NITRMM := R_CIPB_REC.NITRMM; --勞保投保年資(月-年金制)
					ELSE
						P_READ_CIPB;
						R_BADAPR_REC.HBEDMK := R_CIPB_REC.HBEDMK; --'年金施行前有無保險年資';
						R_BADAPR_REC.NITRMY := R_CIPB_REC.NITRMY; --勞保投保年資(年-年金制)
						R_BADAPR_REC.NITRMM := R_CIPB_REC.NITRMM; --勞保投保年資(月-年金制)
					END IF;
					--R_Badapr_Rec.Adjym        :=R_Cipb_Rec.Adjym;     --'投保薪資調整年月';
					--R_Badapr_Rec.Adjmk        :=R_Cipb_Rec.Adjmk;     --'逕調註記';
					--R_Badapr_Rec.Ciid        :=R_Cipb_Rec.CIID;     --'勞就保識別碼';
					R_Badapr_Rec.OLDAB         := NULL; --第一式/第二式
					R_Badapr_Rec.OLDAAMT       := 0; --第一式金額(勞保給付金額)
					R_Badapr_Rec.OLDBAMT       := 0; --第二式金額(勞保給付金額)
					R_Badapr_Rec.OLDEXTRARATE  := 0; --(老年、遺屬)展延/減額比率
					R_Badapr_Rec.QUALCOUNT     := 0; --符合眷屬(遺屬)人數
					R_Badapr_Rec.Oldrate       := 0; --加計比率
					R_Badapr_Rec.CLOSECAUSE    := 'Z9'; --結案原因
					R_BADAPR_REC.ANNUAMT       := 0; --累計已領年金金額
					R_Badapr_Rec.Cutamt        := 0; --應扣失能金額
					R_Badapr_Rec.LECOMAMT      := 0; --己扣失能金額
					R_Badapr_Rec.Benids        := Null; --受益人社福識別碼
					R_Badapr_Rec.BENAGE        := 0; --受益人單齡
					R_Badapr_Rec.BENSEX        := 'Z'; --受益人性別
					R_Badapr_Rec.Bennationtyp  := 'C'; --受益人國籍別
					R_Badapr_Rec.Bennationcode := null; --受益人國籍
					R_Badapr_Rec.Benevtrel     := Null; --受益人與事故者關係
					V_Bdate                    := F_Bdate(R_Badapr_Rec.Apno,
														  R_Badapr_Rec.Seqno,
														  R_Badapr_Rec.Payym,
														  R_Badapr_Rec.Payno);
					V_EDATE                    := '00000';

					V_OUT_CNT := V_OUT_CNT + 1;

					Insert Into bansf
						(Select R_Badapr_Rec.Paydate,
								R_Badapr_Rec.Appdate,
								R_Badapr_Rec.Issuym,
								R_Badapr_Rec.Payym,
								R_Badapr_Rec.Apno,
								'0000',
								R_Badapr_Rec.Edate,
								R_Badapr_Rec.Ubno,
								R_Bansf_Rec_Rec.Ubno,
								R_Badapr_Rec.Ubtype,
								R_Badapr_Rec.Inds,
								R_Badapr_Rec.Hincd,
								R_Badapr_Rec.Idsta,
								R_Badapr_Rec.Area,
								R_Badapr_Rec.Clsqty,
								R_Badapr_Rec.Sex,
								V_Age,
								R_Badapr_Rec.Age,
								V_Str2,
								R_Badapr_Rec.Evtnationtpe,
								R_Badapr_Rec.Payno,
								decode(R_Badapr_Rec.Nitrmy,
									   null,
									   R_BANSF_REC_REC.NITRMY),
								decode(R_Badapr_Rec.Nitrmm,
									   null,
									   R_BANSF_REC_REC.NITRMm),
								R_Badapr_Rec.Evtype,
								R_Badapr_Rec.Evcode,
								R_Badapr_Rec.Injname,
								R_Badapr_Rec.Injno,
								R_Badapr_Rec.Injdp,
								R_Badapr_Rec.Injpart,
								R_Badapr_Rec.Medium,
								R_Badapr_Rec.Injcl,
								R_Badapr_Rec.Apitem,
								R_Badapr_Rec.Chkkind,
								R_Badapr_Rec.Pwage,
								R_Badapr_Rec.Wage,
								R_Badapr_Rec.Paycnt,
								R_Badapr_Rec.Suprecmk,
								R_Badapr_Rec.Pamts,
								R_Badapr_Rec.Adwkmk,
								R_Badapr_Rec.Mchktyp,
								R_Badapr_Rec.Oldab,
								R_Badapr_Rec.Oldaamt,
								R_Badapr_Rec.Oldbamt,
								R_Badapr_Rec.Oldextrarate,
								R_Badapr_Rec.Qualcount,
								R_Badapr_Rec.Oldrate,
								R_Badapr_Rec.Closecause,
								R_Badapr_Rec.Annuamt,
								R_Badapr_Rec.Hbedmk,
								R_Badapr_Rec.Nachgmk,
								R_Badapr_Rec.Cutamt,
								R_Badapr_Rec.Lecomamt,
								R_Badapr_Rec.Paykind,
								Decode(Length(R_Badapr_Rec.Evtidnno),
									   11,
									   Substr(R_Badapr_Rec.Evtidnno, 1, 10),
									   R_Badapr_Rec.Evtidnno),
								Decode(Length(R_Badapr_Rec.Evtidnno),
									   11,
									   Substr(R_Badapr_Rec.Evtidnno, 10, 1),
									   Null),
								R_Badapr_Rec.Evtbrdate,
								R_Badapr_Rec.Evtname,
								V_Edate,
								V_Bdate,
								v_Evtdiedate,
								r_cipb_rec.ADJYM,
								r_cipb_rec.ADJMK,
								V_Str3,
								R_Badapr_Rec.Firstpay,
								null,
								0,
								V_Cat,
								0,
								0,
								null,
                                ''
						   From Dual);
					--2014/04/28  DEFAULT SEQNO=0000
					IF SUBSTR(R_Badapr_Rec.Payno, 1, 1) = '3' AND nvl(v_Evtdiedate,' ') <> ' ' THEN
						Insert Into bansf_TEMP
							(Select R_Badapr_Rec.Paydate,
									R_Badapr_Rec.Appdate,
									R_Badapr_Rec.Issuym,
									R_Badapr_Rec.Payym,
									R_Badapr_Rec.Apno,
									'0000',
									R_Badapr_Rec.Edate,
									R_Badapr_Rec.Ubno,
									R_Bansf_Rec_Rec.Ubno,
									R_Badapr_Rec.Ubtype,
									R_Badapr_Rec.Inds,
									R_Badapr_Rec.Hincd,
									R_Badapr_Rec.Idsta,
									R_Badapr_Rec.Area,
									R_Badapr_Rec.Clsqty,
									R_Badapr_Rec.Sex,
									V_Age,
									R_Badapr_Rec.Age,
									V_Str2,
									R_Badapr_Rec.Evtnationtpe,
									R_Badapr_Rec.Payno,
									decode(R_Badapr_Rec.Nitrmy,
										   null,
										   R_BANSF_REC_REC.NITRMY),
									decode(R_Badapr_Rec.Nitrmm,
										   null,
										   R_BANSF_REC_REC.NITRMm),
									R_Badapr_Rec.Evtype,
									R_Badapr_Rec.Evcode,
									R_Badapr_Rec.Injname,
									R_Badapr_Rec.Injno,
									R_Badapr_Rec.Injdp,
									R_Badapr_Rec.Injpart,
									R_Badapr_Rec.Medium,
									R_Badapr_Rec.Injcl,
									R_Badapr_Rec.Apitem,
									R_Badapr_Rec.Chkkind,
									R_Badapr_Rec.Pwage,
									R_Badapr_Rec.Wage,
									R_Badapr_Rec.Paycnt,
									R_Badapr_Rec.Suprecmk,
									R_Badapr_Rec.Pamts,
									R_Badapr_Rec.Adwkmk,
									R_Badapr_Rec.Mchktyp,
									R_Badapr_Rec.Oldab,
									R_Badapr_Rec.Oldaamt,
									R_Badapr_Rec.Oldbamt,
									R_Badapr_Rec.Oldextrarate,
									R_Badapr_Rec.Qualcount,
									R_Badapr_Rec.Oldrate,
									R_Badapr_Rec.Closecause,
									R_Badapr_Rec.Annuamt,
									R_Badapr_Rec.Hbedmk,
									R_Badapr_Rec.Nachgmk,
									R_Badapr_Rec.Cutamt,
									R_Badapr_Rec.Lecomamt,
									R_Badapr_Rec.Paykind,
									Decode(Length(R_Badapr_Rec.Evtidnno),
										   11,
										   Substr(R_Badapr_Rec.Evtidnno,
												  1,
												  10),
										   R_Badapr_Rec.Evtidnno),
									Decode(Length(R_Badapr_Rec.Evtidnno),
										   11,
										   Substr(R_Badapr_Rec.Evtidnno,
												  10,
												  1),
										   Null),
									R_Badapr_Rec.Evtbrdate,
									R_Badapr_Rec.Evtname,
									V_Edate,
									V_Bdate,
									v_Evtdiedate,
									r_cipb_rec.ADJYM,
									r_cipb_rec.ADJMK,
									V_Str3,
									R_Badapr_Rec.Firstpay,
									null,
									0,
									V_Cat,
									0,
									0,
									null
							   From Dual);
					END IF;
					Insert Into Badapr_Ref Values R_Badapr_Rec;

					IF (Substr(R_Badapr_Rec.Payno, 1, 1) = '5' Or
					   R_Badapr_Rec.Payno In ('35', '37', '38')) and
					   f_bansfcount(r_badapr_rec.Apno,
									r_badapr_rec.Payym,
									R_Badapr_Rec.Suprecmk) > 0 Then
						--PAYDATE=CASE WHEN R_SOURCE_BAAPPBASE_REC.PAYDATE IS NULL THEN R_SOURCE_BAAPPBASE_REC.PAYDATE ELSE PAYDATE END,
						p_read_baappbase;
						IF sw_found = true THEN
							R_Badapr_Rec.Seqno := '0000'; --'序號';
							Update_Data;

							UPDATE BANSF
							   SET Evtidnno     = R_Baappbase_Rec.Evtidnno, --'事故者身份證號';
								   EVTBRDATE    = R_Baappbase_Rec.EVTBRDATE, --'事故者出生日期';
								   Evtname      = R_Baappbase_Rec.Evtname, --'事故者姓名';
								   Appdate      = R_Baappbase_Rec.Appdate, --'申請日期';
								   EVDATE       = R_Baappbase_Rec.EVTDATE, --事故日期;
								   LSUBNO       = R_Baappbase_Rec.LSUBNO,
								   PAYAGE       = V_AGE,
								   AGE          = R_Badapr_Rec.AGE,
								   EVTNATIONTPE = R_Baappbase_Rec.EVTNATIONTPE, --'事故者國籍別';
								   EVCODE       = R_Badapr_Rec.EVCODE,
								   INJNAME      = R_Badapr_Rec.INJNAME,
								   INJNO        = R_Badapr_Rec.INJNO,
								   INJDP        = R_Badapr_Rec.INJDP,
								   INJPART      = R_Badapr_Rec.INJPART,
								   MEDIUM       = R_Badapr_Rec.MEDIUM,
								   INJCL        = R_Badapr_Rec.INJCL,
								   APITEM       = R_Baappbase_Rec.APITEM,
								   CHKKIND      = R_Badapr_Rec.CHKKIND,
								   WAGE         = nvl(R_Baappbase_Rec.Lsinsmamt,
													  0),
								   CLOSECAUSE   = R_Baappbase_Rec.CLOSECAUSE,
								   CUTAMT       = R_Baappbase_Rec.CUTAMT,
								   LECOMAMT     = R_Badapr_Rec.LECOMAMT,
								   EVTDIEDATE   = R_Baappbase_Rec.EVTDIEDATE,
								   adjym        = R_Cipb_Rec.ADJYM,
								   adjmk        = R_Cipb_Rec.ADJMK,
								   ciid         = R_Cipb_Rec.CIID
							 Where Apno = r_badapr_rec.Apno
							   And Payym = r_badapr_rec.Payym
							   and ((R_Badapr_Rec.Suprecmk is null and
								   code is null) or
								   code = R_Badapr_Rec.Suprecmk);

							--2014/04/28
							IF R_Baappbase_Rec.EVTDIEDATE is NOT NULL THEN
								UPDATE BANSF_TEMP
								   SET EVTDIEDATE = R_Baappbase_Rec.EVTDIEDATE
								 Where Apno = r_badapr_rec.Apno
								   And Payym = r_badapr_rec.Payym
								   and ((R_Badapr_Rec.Suprecmk is null and
									   code is null) or
									   code = R_Badapr_Rec.Suprecmk);
							END IF;
						end if;
					end if;
				END IF;

				V_Payym  := R_Badapr_Rec.Payym;
				V_Iisuym := R_Badapr_Rec.Issuym;
				V_APNO   := R_Badapr_Rec.APNO;
				If Mod(V_Out_Cnt, 50000) = 0 Then
					Commit;
				END IF;
			End Loop;
		EXCEPTION
			WHEN OTHERS Then
				DBMS_OUTPUT.put_line(v_key_APNO);
				p_return_code   := p_return_code || v_key_APNO || ',';
				V_Exception_Cnt := V_Exception_Cnt + 1;
				DBMS_OUTPUT.put_line('p_dwamf_old_proc發生錯誤,錯誤代碼=' ||
									 sqlcode || ',' || '錯誤訊息=' || SQLERRM);
				DBMS_OUTPUT.put_line('fn_execute:EXCEPTION==>');
				DBMS_OUTPUT.put_line('error' || SQLERRM);
				DBMS_OUTPUT.put_line('error==>' ||
									 DBMS_UTILITY.format_error_backtrace);
				p_return_code := p_return_code ||
								 'p_dwamf_old_proc發生錯誤,錯誤代碼=' || sqlcode || ',' ||
								 '錯誤訊息=' || SQLERRM || ',';

                --20190827 Add by Angela RecLog Start
                SP_BA_RecBatchJobDtl(BAJOBDTLID.NEXTVAL,
                                     v_i_bajobid,
                                     '1',
                                     '(DB)SP_BANSF_01：統計資料轉入發生錯誤，APNO='||v_key_APNO||'***',
                                     replace(to_Char(SYSTIMESTAMP, 'yyyyMMddHH24missxff'),'.',''));
                --20190827 Add by Angela RecLog End;
        END;
		-- ============================================================================
		--                      <<<<<<<<< MAIN procedure >>>>>>>>>>
		-------------------------------------------------------------------------------
	Begin
		DBMS_OUTPUT.put_line('勞保年金統計核定檔資料轉入');
		p_return_code := p_return_code || '勞保年金統計核定檔資料轉入' || ',';
		--   p_return_code := 'OK';  --回傳訊息
		--初期處理------------------------------------------------------
		BEGIN
			-- 檢查參數內容
			-- 處理年月
			Dbms_Output.Put_Line('處理年月=' || P_Payym);
			p_return_code := p_return_code || '處理年月=' || P_Payym || ',';
			--v_format_date := TO_DATE(P_Payym || '01', 'YYYYMMDD');
		EXCEPTION
			WHEN OTHERS THEN
				DBMS_OUTPUT.put_line('輸入參數資料錯誤EXCEPTION！');
				p_return_code := p_return_code || '輸入參數資料錯誤EXCEPTION！' || ',';
				--        p_return_code := 'NO';  --回傳訊息
				Dbms_Output.Put_Line('初期處理失敗：錯誤代碼=' || Sqlcode || ' ， ' ||
									 '錯誤訊息=' || Sqlerrm);
				p_return_code := p_return_code || '初期處理失敗：錯誤代碼=' || Sqlcode ||
								 ' ， ' || '錯誤訊息=' || Sqlerrm || ',';
				COMMIT;
				Return;
		END;
		--主程序處理=========================================================================

        --20190827 Add by Angela RecLog Start
        v_o_flag := '0';
        SP_BA_RecJobLog(p_job_no => v_i_mmJobNO,
                        p_job_id => 'PG_BANSF_01.SP_BANSF',
                        p_step   => '產生勞保年金統計檔資料作業(SP_BANSF_01)：勞保年金統計核定檔及勞保年金統計檔轉入(失能、遺屬)',
                        p_memo   => '開始時間：'||to_Char(SYSTIMESTAMP,'YYYY/MM/DD HH24:MI:SS')||CHR(10)||'('||v_i_mmJobNO||')');

        SP_BA_RecBatchJobDtl(BAJOBDTLID.NEXTVAL,
                             v_i_bajobid,
                             '0',
                             '(DB)SP_BANSF_01：勞保年金統計核定檔及勞保年金統計檔轉入(失能、遺屬)(開始)',
                             replace(to_Char(SYSTIMESTAMP, 'yyyyMMddHH24missxff'),'.',''));
        --20190827 Add by Angela RecLog End

        --1.刪除給付年月資料
		DBMS_OUTPUT.put_line('1.刪除給付年月資料');
		p_return_code := p_return_code || '1.刪除給付年月資料' || ',';
		If P_Payym = '201208' Then
			-- p_delete_data;
			COMMIT;
		end IF;

		--2.勞保年金統計核定檔BADAPR_REF及勞保年金統計檔BANSF轉入
		Dbms_Output.Put_Line('2.勞保年金統計核定檔及勞保年金統計檔轉入' ||
							 To_Char(Sysdate, 'YYYY/MM/DD HH24:MI:SS'));
		p_return_code := p_return_code || '2.勞保年金統計核定檔及勞保年金統計檔轉入' ||
						 To_Char(Sysdate, 'YYYY/MM/DD HH24:MI:SS') || ',';
		p_badapr_proc;

		If V_Exception_Cnt > 0 Then
			raise_application_error(-20001,'勞保年金統計核定檔及勞保年金統計檔處理失敗！');
		    v_o_flag := '1';
        ELSE
			COMMIT;
		END IF;

		--==========================================================================================

		--結束處理
		--DBMS_OUTPUT.put_line('EXCEPTION錯誤筆數＝'||v_exception_cnt);
		IF v_exception_cnt > 0 THEN
			Rollback;
			--      P_Return_Code := 'NO';  --回傳訊息
			DBMS_OUTPUT.put_line('產生勞保年金統計核定檔及勞保年金統計檔失敗！' ||
								 To_Char(Sysdate, 'YYYY/MM/DD HH24:MI:SS'));
			p_return_code := p_return_code || '產生勞保年金統計核定檔及勞保年金統計檔失敗！' ||
							 To_Char(Sysdate, 'YYYY/MM/DD HH24:MI:SS') || ',';
		    v_o_flag := '1';
        Else
			DBMS_OUTPUT.put_line('產生勞保年金統計核定檔及勞保年金統計檔成功！' ||
								 To_Char(Sysdate, 'YYYY/MM/DD HH24:MI:SS'));
			p_return_code := p_return_code || '產生勞保年金統計核定檔及勞保年金統計檔成功！' ||
							 To_Char(Sysdate, 'YYYY/MM/DD HH24:MI:SS') || ',';
		END IF;
	    COMMIT;

        --20190827 Add by Angela RecLog Start
        SP_BA_RecJobLog(p_job_no => v_i_mmJobNO,
                        p_job_id => 'PG_BANSF_01.SP_BANSF',
                        p_step   => '產生勞保年金統計檔資料作業(SP_BANSF_01)：勞保年金統計核定檔及勞保年金統計檔轉入(失能、遺屬)',
                        p_memo   => '結束時間：'||to_Char(SYSTIMESTAMP,'YYYY/MM/DD HH24:MI:SS')||CHR(10)||'('||v_i_mmJobNO||')'||CHR(10)||'執行結果:('||v_o_flag||')');

        SP_BA_RecBatchJobDtl(BAJOBDTLID.NEXTVAL,
                             v_i_bajobid,
                             v_o_flag,
                             '(DB)SP_BANSF_01：勞保年金統計核定檔及勞保年金統計檔轉入(失能、遺屬)(結束)',
                             replace(to_Char(SYSTIMESTAMP, 'yyyyMMddHH24missxff'),'.',''));

        if v_o_flag <> '0' then
            v_o_flag := 'N';
        else
            v_o_flag := 'E';
        end if;
        --20190827 Add by Angela RecLog End;

		p_output_message; --輸出結果
	EXCEPTION
		WHEN OTHERS THEN
			ROLLBACK;
			DBMS_OUTPUT.put_line('勞保年金統計核定檔失敗！' || SQLCODE || ' - ' ||
								 SQLERRM);
			p_return_code := p_return_code || '勞保年金統計核定檔失敗！' || SQLCODE ||
							 ' - ' || SQLERRM || ',';
			--      p_return_code := 'NO';  --回傳訊息
			p_output_message; --輸出結果
			COMMIT;

            --20190827 Add by Angela RecLog Start
            SP_BA_RecJobLog(p_job_no => v_i_mmJobNO,
                            p_job_id => 'PG_BANSF_01.SP_BANSF',
                            p_step   => '產生勞保年金統計檔資料作業(SP_BANSF_01)：勞保年金統計核定檔及勞保年金統計檔轉入(失能、遺屬)',
                            p_memo   => '結束時間：'||to_Char(SYSTIMESTAMP,'YYYY/MM/DD HH24:MI:SS')||CHR(10)||'('||v_i_mmJobNO||')'||CHR(10)||'執行結果:(1)');

            SP_BA_RecBatchJobDtl(BAJOBDTLID.NEXTVAL,
                                 v_i_bajobid,
                                 '1',
                                 '(DB)SP_BANSF_01：勞保年金統計核定檔及勞保年金統計檔轉入(失能、遺屬)(結束)',
                                 replace(to_Char(SYSTIMESTAMP, 'yyyyMMddHH24missxff'),'.',''));

            v_o_flag := 'N';
            --20190827 Add by Angela RecLog End;
	End;
End Sp_BAnsf_01;

