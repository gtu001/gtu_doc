create or replace Procedure    Sp_Bansf_02(P_Insuym      In Varchar2, --處理年月
										v_i_mmJobNO   in varChar2,
                                        v_i_bajobid   in varChar2,
                                        p_return_code OUT VARCHAR2, --回傳訊息OK:成功 or NO:失敗
                                        v_o_flag      out varChar2
										) Is
Begin
	-- 修改紀錄：
	-- 維護人員        日期       說明
	-- -----------   --------  ----------------------------------------------------
	-- rose          20120906   v1.0
	-- ============================================================================
	--                          <<<<<<<<< 變數區 >>>>>>>>>>
	-------------------------------------------------------------------------------
	Declare
		R_Bansf_Rec       Bansf%Rowtype; --badapr_ref RECORD
		R_Baappbase_Rec   Baappbase%Rowtype; --BAAPPBASE RECORD   --2013/06/04
		--R_Baappexpand_Rec Baappexpand%Rowtype; --BAAPPEXPAND RECORD
		R_CIPB_Rec        ba.cipb%Rowtype; --BAAPPEXPAND RECORD
		R_ciCIPB_Rec      ci.cipb%Rowtype; --BAAPPEXPAND RECORD  --    ci.cipb
		R_Caub_Rec        caub%Rowtype; --STAT RECORDc  --dss.caub
		-- ============================================================================
		sw_found BOOLEAN := TRUE; --找到資料
		-- ============================================================================
		-------------------------------------------------------------------------------
		V_Out_Cnt           Number(10) := 0; --輸出新增筆數
		v_del_cnt           NUMBER(10) := 0; --刪除筆數
		V_Key_Ubno          Bansf.Ubno%Type;
		V_Key_Baappbaseid   Number(20); --給付主檔資料編號
		V_Key_Apno          Bansf.Apno%Type; --受理編號
		V_Key_SEQNO         BADAPR.SEQNO%Type; --序號
		V_Key_Idn           Varchar2(11 Byte); --身份證號
		V_Key_Intyp         varchar(1 byte); --保險別
		V_Key_Name          Bansf.Evtname%Type; --姓名
		v_key_brdate        Varchar2(8 Byte); --生日
		V_Exception_Cnt     Integer := 0; --EXCEPTION錯誤筆數
		--V_Format_Date       Date; --DATE格式欄位
		v_iisuym            varchar(6 byte);
		v_notfound_cipb_cnt NUMBER(10) := 0; --找不到CIPB筆數
		V_TOOMANY_CIPB_CNT  NUMBER(10) := 0; --找到太多CIPB筆數
		V_OTHER_CIPB_CNT    NUMBER(10) := 0; --找到ERR CIPB筆數
		V_Edate             Varchar2(6 Byte);

		-- ============================================================================
		-- CURSOR C_BANSF_REF
		-------------------------------------------------------------------------------
		--處理年月=201208,則全量資料取入,否則,取回給付年月payym=處理年月P_Payym
		CURSOR C_BADAPR_REF IS
			select A.*,
				   B.APNO as APNO_BA,
				   B.Appdate,
				   B.Evtjobdate,
				   b.apubno,
				   b.LSUBNO,
				   b.EVTSEX,
				   b.Evtage,
				   b.Evtnationtpe,
				   b.Closecause,
				   case
					   when A.REMAINAMT is null then
						0
					   else
						A.REMAINAMT
				   end Cutamt,
				   B.Evtidnno,
				   B.Evtbrdate,
				   b.Evtname,
				   B.Evtdiedate,
				   b.Casetyp,
				   b.Apitem,
				   B.Lsinsmamt,
				   B.Paydate,
				   C.Evtyp,
				   C.Evcode,
				   C.Criinjnme1,
				   C.Criinjdp1,
				   C.criinpart1,
				   C.Crimedium,
				   C.Criinissul,
				   C.CRIINJCL1,
				   C.CRIINJCL2,
				   c.CRIINJCL3,
				   C.Ocaccidentmk,
				   case
					   when C.adwkmk is null then
						'1'
					   else
						c.adwkmk
				   end as adwkmk_ex
			  from (Select *
					  From Badapr
					 Where issuym < '201312'
					   and PAYKIND IN ('45', '48')
					   AND mtestmk = 'F'
					   AND Aplpaymk = '3'
					   and P_Insuym = '201208'
					   and Benevtrel <> 'F'
					   and Benevtrel <> 'N'
					   and Benevtrel <> 'Z'
					union all
					Select *
					  From Badapr
					 Where P_Insuym <> '201208'
					   and substr(Aplpaydate, 1, 6) = P_Insuym
					   and PAYKIND IN ('45', '48')
					   AND mtestmk = 'F'
					   AND Aplpaymk = '3'
					   and Benevtrel <> 'F'
					   and Benevtrel <> 'N'
					   and Benevtrel <> 'Z') A,
				   baappbase B,
				   baappexpand C
			 where A.BAAPPBASEID = B.Baappbaseid(+)
			   and A.BAAPPBASEID = C.Baappbaseid(+)
			   and A.BAAPPBASEID = C.Baappbaseid(+)
			 Order By (Case
						  When Suprecmk is Null then
						   '0'
						  when Suprecmk = 'C' Then
						   '1'
						  Else
						   '2'
					  End),
					  A.Apno,
					  substr(Aplpaydate, 1, 6),
					  A.Payym,
					  NVL(BEFISSUEAMT, 0) desc;

		Cursor C_Bansf Is
			Select *
			  From Bansf
			 Where (P_Insuym = '201208' Or Issuym = P_Insuym)
			   And (Bdate Is Null Or Edate Is Null or ciid is null);

		-- ============================================================================
		-- procedure
		-------------------------------------------------------------------------------
		-- 輸出結果
		PROCEDURE p_output_message IS
		BEGIN
			DBMS_OUTPUT.PUT_LINE('異常cipb資料=' ||
								 TO_CHAR(V_NOTFOUND_CIPB_CNT +
										 V_TOOMANY_CIPB_CNT +
										 V_OTHER_CIPB_CNT));
			p_return_code := p_return_code || '異常cipb資料=' ||
							 TO_CHAR(V_NOTFOUND_CIPB_CNT +
									 V_TOOMANY_CIPB_CNT + V_OTHER_CIPB_CNT) || ',';
			Dbms_Output.Put_Line('新增bansf筆數=' || V_Out_Cnt);
			p_return_code := p_return_code || '新增bansf筆數=' || V_Out_Cnt || ',';
		End;
		-------------------------------------------------------------------------------
		-- 刪除計費年月資料
		-------------------------------------------------------------------------------
		PROCEDURE p_delete_data IS
		Begin
			--刪除BANSF、BADAPR_REF處理當月資料
			Delete From Bansf
			 WHERE (P_Insuym = '201208' or payym = P_Insuym)
			   and substr(payno, 1, 1) = '4'; --and APNO in ('L10000000181','L20000000077','L20000000613');
			Delete From Badapr_Ref
			 WHERE (P_Insuym = '201208' or payym = P_Insuym)
			   and substr(payno, 1, 1) = '4'; --and APNO in ('L10000000181','L20000000077','L20000000613');
			V_Del_Cnt := 0; --刪除筆數
			v_del_cnt := v_del_cnt + SQL%ROWCOUNT; --刪除筆數
		EXCEPTION
			WHEN OTHERS THEN
				v_exception_cnt := v_exception_cnt + 1;
				DBMS_OUTPUT.put_line('p_delete_data發生錯誤,錯誤代碼=' || sqlcode || ',' ||
									 '錯誤訊息=' || SQLERRM);
				p_return_code := p_return_code || 'p_delete_data發生錯誤,錯誤代碼=' ||
								 sqlcode || ',' || '錯誤訊息=' || SQLERRM || ',';

                --20190827 Add by Angela RecLog Start
                SP_BA_RecBatchJobDtl(BAJOBDTLID.NEXTVAL,
                                     v_i_bajobid,
                                     '1',
                                     '(DB)SP_BANSF_02：刪除勞保統計檔(BANSF、BADAPR_REF)(以處理年月為條件)發生錯誤***',
                                     replace(to_Char(SYSTIMESTAMP, 'yyyyMMddHH24missxff'),'.',''));
                --20190827 Add by Angela RecLog End;
        END;
		------------------------------------------------------------
		--取回INJDP障礙(失能部位)
		function F_injdp(S_key_INJNO In Varchar2) Return BCA_D_INJD.INJDP%TYPE Is
			RESULT BCA_D_INJD.INJDP%TYPE;
		Begin
			/*條件:INSKD  保險別='1' and INJNO  障礙項目(分左右)代碼=INJNO
            payym給付年月介於EFDTE生效日及失效日之間*/
			SELECT INJDP
			  Into Result
			  From Bca_D_Injd
			 Where INSKD = '1'
			   and INJNO = S_key_INJNO
			   And P_Insuym || '01' >= EFDTE
			   and P_Insuym || '01' <= EXDTE
			   AND ROWNUM < 2;
			RETURN RESULT;
		EXCEPTION
			When No_Data_Found Then
				RETURN 0;
			When Others Then
				RETURN 0;
		End;
		-------------------------------------------------------
		--取回v_bdate開始請領日期
		Function F_bdate(S_Key_Apno In Varchar2,
						 s_seqno    in varchar2,
						 S_Payym    In Varchar2/*,
						 s_payno    in varchar2*/) Return BADAPR.PAYYM%type Is
			Result Badapr.Payym%Type;
		BEGIN
			Select Min(C.Payym)
			  INTO RESULT
			  FROM BADAPR C
			 WHERE C.APNO = S_Key_Apno
			   AND C.PAYYM <= S_Payym
			   And C.Mtestmk = 'F'
			   And C.Aplpaymk = '3'
			   And Trim(C.Aplpaydate) Is Not Null
			   AND C.SEQNO = s_seqno;
			return Result;
		EXCEPTION
			When No_Data_Found Then
				RETURN null;
			When Others Then
				RETURN null;
		End;
		----------------------------------------------------------------
		-- 取回被保險人pwage 60個月平均薪資
		----------------------------------------------------------------
		Function F_pwage(S_Key_Apno In Varchar2,
						 S_Payym    In Varchar2/*,
						 s_payno    in varchar2*/) Return BADAPR.PAYYM%type Is
			Result Badapr.Payym%Type;
		Begin
			Select nvl(Insavgamt, 0) as pwage
			  INTO RESULT
			  FROM BADAPR C
			 WHERE C.APNO = S_Key_Apno
			   And C.Mtestmk = 'F'
			   And C.Aplpaymk = '3'
			   And Trim(C.Aplpaydate) Is Not Null
			   AND c.suprecmk is null
			   AND C.SEQNO = '0000'
			   And C.payym = S_Payym;
			--取整案之最大給付年月
			--Dbms_Output.Put_Line(S_Key_Apno||';'||S_Payym||';'||s_payno||';'||Result);
			return Result;
		EXCEPTION
			When No_Data_Found Then
				RETURN null;
			When Others Then
				RETURN null;
		End;
		-------------------------------------------------------
		--取回v_edate結束日期
		-------------------------------------------------------
		Function F_edate(S_Key_Apno In Varchar2/*,
						 s_seqno    in varchar2,
						 S_Payym    In Varchar2,
						 s_payno    in varchar2*/) Return BADAPR.PAYYM%type Is
			Result Badapr.Payym%Type;
		Begin
			Select substr(max(C.Payym), 1, 6)
			  INTO RESULT
			  FROM BADAPR C
			 WHERE C.APNO = S_Key_Apno
			   And C.Mtestmk = 'F'
			   And C.Aplpaymk = '3'
			   And Trim(C.Aplpaydate) Is Not Null
			   AND c.suprecmk is null
			/*AND C.SEQNO='0000'*/
			;
			--取整案之最大給付年月
			--Dbms_Output.Put_Line(S_Key_Apno||';'||S_Payym||';'||s_payno||';'||Result);

			return Result;
		EXCEPTION
			When No_Data_Found Then
				RETURN null;
			When Others Then
				RETURN null;
		End;
		-------------------------------------------------------------------------
		--取回月份相減
		Function F_Year(S_Ym_B In Varchar2, S_Ym_E In Varchar2) Return Number Is
		Begin
			If S_Ym_B Is Not Null And S_Ym_E Is Not Null Then
				If Substr(S_Ym_E, 5, 2) > Substr(S_Ym_b, 5, 2) Then
					Return to_number(Substr(S_Ym_b, 1, 4) -
									 Substr(S_Ym_E, 1, 4) - 1);
				Else
					Return to_number(Substr(S_Ym_b, 1, 4) -
									 Substr(S_Ym_E, 1, 4));
				end if;
			Else
				return 0;
			End If;
		EXCEPTION
			When No_Data_Found Then
				RETURN 0;
			When Others Then
				Return 0;
		End;
		-------------------------------------------------------------------------------
		--讀取CAUB
		PROCEDURE p_read_caub IS
		BEGIN
			Sw_Found := True;
			Select *
			  Into R_Caub_Rec
			  From caub --2013/06/04 dss.caub
			 Where Ubno = V_Key_Ubno
			   And Rownum < 2;
			--保險證號
		Exception
			WHEN NO_DATA_FOUND THEN
				r_caub_rec := null;
				sw_found   := FALSE;
			WHEN OTHERS THEN
				Sw_Found := False;
				Dbms_Output.Put_Line('p_read_caub發生錯誤,UBNO=' || V_Key_Ubno ||
									 ',錯誤代碼=' || Sqlcode || ',' || '錯誤訊息=' ||
									 Sqlerrm || ',' ||
									 DBMS_UTILITY.format_error_backtrace);
				p_return_code := p_return_code || 'p_read_caub發生錯誤,UBNO=' ||
								 V_Key_Ubno || ',錯誤代碼=' || Sqlcode || ',' ||
								 '錯誤訊息=' || Sqlerrm || ',' ||
								 DBMS_UTILITY.format_error_backtrace || ',';

                --20190827 Add by Angela RecLog Start
                SP_BA_RecBatchJobDtl(BAJOBDTLID.NEXTVAL,
                                     v_i_bajobid,
                                     '1',
                                     '(DB)SP_BANSF_02：讀取CAUB發生錯誤，UBNO='||V_Key_Ubno||'***',
                                     replace(to_Char(SYSTIMESTAMP, 'yyyyMMddHH24missxff'),'.',''));
                --20190827 Add by Angela RecLog End;
        End;
		-------------------------------------------------------
		--取回v_bdate開始請領日期
		Function F_bdate_bansf(S_Key_Apno In Varchar2, S_Payym In Varchar2)
			Return BADAPR.PAYYM%type Is
			RESULT BADAPR.PAYYM%type;
		Begin
			--Select Min(C.Payym)
			SELECT CASE
					   WHEN MIN(C.BDATE) < MIN(C.PAYYM) THEN
						MIN(C.BDATE)
					   ELSE
						MIN(C.PAYYM)
				   END
			  Into Result
			  From Bansf C
			 Where C.Apno = S_Key_Apno
			   AND C.PAYYM <= S_Payym;
			return Result;
		EXCEPTION
			When No_Data_Found Then
				RETURN null;
			When Others Then
				Return Null;
		End;
		-------------------------------------------------------------------------------
		-- 顯示LOG內容
		PROCEDURE log_msg(p_msg IN VARCHAR2) IS
		BEGIN
			IF v_exception_cnt > 100 THEN
				DBMS_OUTPUT.put_line('EXCEPTION錯誤超過100個！');
				p_return_code := p_return_code || 'EXCEPTION錯誤超過100個！' || ',';
				raise_application_error(-20001, 'EXCEPTION錯誤超過100個！');
			END IF;

			DBMS_OUTPUT.put_line(p_msg);
			p_return_code := p_return_code || p_msg || ',';
		End;
		-------------------------------------------------------------------------------
		-- 依身份證號Idno讀取CIPB資料
		PROCEDURE p_read_cipb is
		Begin
			SELECT *
			  INTO r_cipb_rec
			  FROM ba.cipb B --2013/06/04 dss.CIPB
			 WHERE B.Intyp = V_KEY_INTYP
			   AND B.IDN LIKE V_KEY_IDN || '%'
			   AND B.BRDTE = v_key_brdate;
		EXCEPTION
			WHEN NO_DATA_FOUND THEN
				V_NOTFOUND_CIPB_CNT := V_NOTFOUND_CIPB_CNT + 1;
				R_CIPB_REC          := NULL;
				SW_FOUND            := FALSE;
			WHEN TOO_MANY_ROWS THEN
				--以 身分證,出生,姓名 讀CIPB取CIID
				BEGIN
					SELECT *
					  INTO R_CIPB_REC
					  FROM ba.cipb B
					 WHERE B.intyp = v_key_intyp
					   AND B.IDN like v_key_idn || '%'
					   AND B.BRDTE = v_key_brdate
					   AND B.NAME = v_key_name;
				EXCEPTION
					WHEN NO_DATA_FOUND THEN
						v_notfound_cipb_cnt := v_notfound_cipb_cnt + 1;
					WHEN TOO_MANY_ROWS THEN
						v_toomany_cipb_cnt := v_toomany_cipb_cnt + 1;
					WHEN OTHERS THEN
						v_other_cipb_cnt := v_other_cipb_cnt + 1;
				END;
			WHEN OTHERS THEN
				V_OTHER_CIPB_CNT := V_OTHER_CIPB_CNT + 1;
				R_Cipb_Rec       := Null;
				Sw_Found         := False;
				LOG_MSG('p_read_cipb發生錯誤,idn=' || V_KEY_IDN || ',錯誤代碼=' ||
						SQLCODE || ',' || '錯誤訊息=' || SQLERRM);
				p_return_code := p_return_code || 'p_read_cipb發生錯誤,idn=' ||
								 V_KEY_IDN || ',錯誤代碼=' || SQLCODE || ',' ||
								 '錯誤訊息=' || SQLERRM || ',';

                --20190827 Add by Angela RecLog Start
                SP_BA_RecBatchJobDtl(BAJOBDTLID.NEXTVAL,
                                     v_i_bajobid,
                                     '1',
                                     '(DB)SP_BANSF_02：讀取BA.CIPB發生錯誤，IDN='||V_KEY_IDN||'***',
                                     replace(to_Char(SYSTIMESTAMP, 'yyyyMMddHH24missxff'),'.',''));
                --20190827 Add by Angela RecLog End;
        END;
		-------------------------------------------------------------------------------
		-- 依身份證號Idno讀取CIPB資料
		PROCEDURE p_read_cicipb is
		Begin
			SELECT *
			  INTO r_cicipb_rec
			  FROM ci.cipb B --2013/06/04 ci.CIPB
			 WHERE B.ftyp = V_KEY_INTYP
			   AND B.IDN LIKE V_KEY_IDN || '%'
			   AND B.BRDTE = v_key_brdate;
		EXCEPTION
			WHEN NO_DATA_FOUND THEN
				V_NOTFOUND_CIPB_CNT := V_NOTFOUND_CIPB_CNT + 1;
				R_ciCIPB_REC        := NULL;
				SW_FOUND            := FALSE;
			WHEN TOO_MANY_ROWS THEN
				--以 身分證,出生,姓名 讀CIPB取CIID
				BEGIN
					SELECT *
					  INTO R_ciCIPB_REC
					  FROM ci.cipb B --2013/06/04 ci.cipb
					 WHERE B.ftyp = v_key_intyp
					   AND B.IDN like v_key_idn || '%'
					   AND B.BRDTE = v_key_brdate
					   AND B.NAME = v_key_name;
				EXCEPTION
					WHEN NO_DATA_FOUND THEN
						v_notfound_cipb_cnt := v_notfound_cipb_cnt + 1;
					WHEN TOO_MANY_ROWS THEN
						v_toomany_cipb_cnt := v_toomany_cipb_cnt + 1;
					WHEN OTHERS THEN
						v_other_cipb_cnt := v_other_cipb_cnt + 1;
				END;
			WHEN OTHERS THEN
				V_OTHER_CIPB_CNT := V_OTHER_CIPB_CNT + 1;
				R_ciCipb_Rec     := Null;
				Sw_Found         := False;
				LOG_MSG('p_read_cipb發生錯誤,idn=' || V_KEY_IDN || ',錯誤代碼=' ||
						SQLCODE || ',' || '錯誤訊息=' || SQLERRM);
				p_return_code := p_return_code || 'p_read_cipb發生錯誤,idn=' ||
								 V_KEY_IDN || ',錯誤代碼=' || SQLCODE || ',' ||
								 '錯誤訊息=' || SQLERRM || ',';

                --20190827 Add by Angela RecLog Start
                SP_BA_RecBatchJobDtl(BAJOBDTLID.NEXTVAL,
                                     v_i_bajobid,
                                     '1',
                                     '(DB)SP_BANSF_02：讀取CI.CIPB發生錯誤，IDN='||V_KEY_IDN||'***',
                                     replace(to_Char(SYSTIMESTAMP, 'yyyyMMddHH24missxff'),'.',''));
                --20190827 Add by Angela RecLog End;
        END;
		-------------------------------------------------------------------------------
		-- 依給付主檔資料編號Baappbaseid取得BAAPPBASE資料
		PROCEDURE p_read_baappbase_D IS
		BEGIN
			sw_found := TRUE;

			SELECT distinct *
			  INTO r_baappbase_rec
			  FROM BAAPPBASE A
			 WHERE A.baappbaseid = v_key_baappbaseid;
			--apno = v_key_apno and seqno='0000';
		EXCEPTION
			WHEN NO_DATA_FOUND THEN
				sw_found := FALSE;
			WHEN OTHERS THEN
				sw_found        := FALSE;
				v_exception_cnt := v_exception_cnt + 1;
				log_msg('p_read_baappbase發生錯誤,APNO=' || v_key_apno ||
						',錯誤代碼=' || sqlcode || ',' || '錯誤訊息=' || SQLERRM);
				p_return_code := p_return_code ||
								 'p_read_baappbase發生錯誤,APNO=' || v_key_apno ||
								 ',錯誤代碼=' || sqlcode || ',' || '錯誤訊息=' ||
								 SQLERRM || ',';

            --20190827 Add by Angela RecLog Start
            SP_BA_RecBatchJobDtl(BAJOBDTLID.NEXTVAL,
                                 v_i_bajobid,
                                 '1',
                                 '(DB)SP_BANSF_01：讀取勞保給付主檔一(BAAPPBASE)發生錯誤，APNO='||v_key_apno||'***',
                                 replace(to_Char(SYSTIMESTAMP, 'yyyyMMddHH24missxff'),'.',''));
            --20190827 Add by Angela RecLog End;
        End;
		------------------------------------------------------------------------------
		--設定年齡組別
		Function F_Agetype(S_Age In Number) Return bansf.agetype%Type Is
			RESULT bansf.agetype%TYPE;
		Begin
			Case
				When S_Age < 15 Then
					Result := '01';
				When S_Age >= 15 And S_Age <= 19 Then
					Result := '02';
				When S_Age >= 20 And S_Age <= 24 Then
					Result := '03';
				When S_Age >= 25 And S_Age <= 29 Then
					Result := '04';
				When S_Age >= 30 And S_Age <= 34 Then
					Result := '05';
				When S_Age >= 35 And S_Age <= 39 Then
					Result := '06';
				When S_Age >= 40 And S_Age <= 44 Then
					Result := '07';
				When S_Age >= 45 And S_Age <= 49 Then
					Result := '08';
				When S_Age >= 50 And S_Age <= 54 Then
					Result := '09';
				When S_Age >= 55 And S_Age <= 59 Then
					Result := '10';
				When S_Age >= 60 And S_Age <= 64 Then
					Result := '11';
				When S_Age >= 65 And S_Age <= 69 Then
					Result := '12';
				When S_Age >= 70 And S_Age <= 74 Then
					Result := '13';
				When S_Age >= 75 And S_Age <= 79 Then
					Result := '14';
				When S_Age >= 80 And S_Age <= 84 Then
					Result := '15';
				When S_Age >= 85 And S_Age <= 89 Then
					Result := '16';
				Else
					Result := '17';
			end case;
			Return Result;
		End;
		-------------------------------------------------------------------------------
		Procedure P_Result_Proc Is
		Begin
			For C_Bansf_Ref In C_Bansf Loop
				C_Bansf_Ref.Bdate := F_Bdate_Bansf(C_Bansf_Ref.Apno,
												   C_Bansf_Ref.Payym);
				--結束請領年月
				/*If C_Bansf_Ref.Edate='00000' Then
                  C_Bansf_Ref.EDATE:=C_Bansf_Ref.EDATE;
                Else
                  C_Bansf_Ref.Edate:= C_Bansf_Ref.Bdate;
                End If;*/
				if C_Bansf_Ref.ciid is null then
					r_cicipb_rec := null;
					If C_Bansf_Ref.Adwkmk = '2' Then
						V_Key_Intyp := 'V';
					Else
						V_Key_Intyp := 'L';
					end if;
					v_key_idn    := C_Bansf_Ref.Evtidnno;
					v_key_brdate := C_Bansf_Ref.Evtbrdate;
					v_key_name   := C_Bansf_Ref.Evtname;
					p_read_cicipb;
				end if;

				Update Bansf
				   Set Bdate = C_Bansf_Ref.Bdate /*,Edate=C_Bansf_Ref.Edate*/,
					   ciid  = decode(ciid, null, r_cicipb_rec.ciid, ciid)
				 Where Apno = C_Bansf_Ref.Apno
				   And Payym = C_Bansf_Ref.Payym
				   and ((C_bansf_ref.Code is null and
					   C_BANSF_REF.CODE is null) or
					   code = C_bansf_ref.Code);

                Commit;
				--Dbms_Output.Put_Line('成功');
			End Loop;
		End;
		-------------------------------------------------------------------------------
		PROCEDURE update_data IS
		Begin
			--取得主檔資料
			R_Bansf_Rec.Appdate := R_Baappbase_Rec.Appdate; --'申請日期';
			R_Bansf_Rec.Evdate  := R_Baappbase_Rec.Evtjobdate; --事故日期;
			R_Bansf_Rec.Ubno    := R_Baappbase_Rec.apubno;
			R_BANSF_REC.LSUBNO  := R_BAAPPBASE_REC.LSUBNO;
			IF R_BANSF_REC.UBNO IS NULL THEN
				R_BANSF_REC.Ubno := R_BAAPPBASE_REC.LSUBNO;
			END IF;
			R_Bansf_Rec.sex := R_Baappbase_Rec.EVTSEX; --'事故者性別';

			--20130320 失能及老年年金：計算至核付年月，以申請年月-出生,取年
			R_Bansf_rec.payage := F_Year(substr(R_Bansf_rec.paydate, 1, 6),
										 Substr(R_Baappbase_Rec.Evtbrdate,
												1,
												6)); --'核付年齡';

			--20130320 失能及老年年金：計算至核付年月，以申請年月-出生,取年
			R_Bansf_Rec.Age := R_Baappbase_Rec.Evtage; --'申請年月-事故者出生年月=申請年齡';
			IF (R_Bansf_Rec.Age IS NULL or R_Bansf_Rec.Age <= 0) AND
			   R_Baappbase_Rec.APPDATE IS NOT NULL AND
			   R_Baappbase_Rec.EVTBRDATE IS NOT NULL THEN
				R_Bansf_Rec.Age := F_Year(Substr(R_Baappbase_Rec.APPDATE,
												 1,
												 6),
										  Substr(R_Baappbase_Rec.EVTBRDATE,
												 1,
												 6)); --'申請年月-事故者出生年月=申請年齡';
			END IF;
			R_Bansf_rec.agetype := F_Agetype(R_Bansf_rec.payage); --年齡組別
			--'被保險人國籍別';
			If R_Baappbase_Rec.Evtnationtpe = '2' Then
				R_Bansf_Rec.Evtnationtpe := 'Y';
			Else
				R_Bansf_Rec.Evtnationtpe := 'C';
			End If;
			--R_Bansf_Rec.Payno         :=R_Baappbase_Rec.Paykind;     --'給付種類';
			R_Bansf_rec.Closecause := R_Baappbase_Rec.Closecause; --'結案原因';
			R_Bansf_Rec.Evtidnno   := R_Baappbase_Rec.Evtidnno; --'事故者身份證號';
			R_Bansf_rec.Evtbrdate  := R_Baappbase_Rec.Evtbrdate; --'事故者出生日期';
			R_Bansf_Rec.Evtname    := R_Baappbase_Rec.Evtname; --'事故者姓名';
			R_Bansf_Rec.Evtdiedate := R_Baappbase_Rec.Evtdiedate; --'死亡日期';
			R_Bansf_Rec.Bdate      := F_Bdate(R_Bansf_Rec.Apno,
											  '0000',
											  R_Bansf_Rec.Payym/*,
											  R_Bansf_Rec.Payno*/); --'開始請領日期';
			v_edate                := F_edate(R_Bansf_Rec.Apno/*,
											  '0000',
											  R_Bansf_Rec.Payym,
											  R_Bansf_Rec.Payno*/); --'結束日期';
			--'結束請領日期';
			--20150616 add casetype in ('3','6')
			If (R_Baappbase_Rec.Casetyp = '4') or
			   ((R_Baappbase_Rec.Casetyp = '3' or
			   R_Baappbase_Rec.Casetyp = '6') and
			   R_Baappbase_Rec.Closedate is not null) Then
				R_Bansf_Rec.edate := v_Edate;
			else
				R_Bansf_Rec.Edate := '00000';
			End If;

			R_Bansf_Rec.Apitem := R_Baappbase_Rec.Apitem; --'申請項目';
			R_Bansf_Rec.Wage   := Nvl(R_Baappbase_Rec.Lsinsmamt, 0); --'投保薪資';

			/*         Evtjobdate(事故日期) >= Appdate(申請日期)   請領類別='1'
            Evtjobdate(事故日期) < Appdate(申請日期)    請領類別='2'*/
			If R_Bansf_Rec.Evdate >= R_Bansf_Rec.Appdate Then
				R_Bansf_Rec.Gettype := '1';
			Else
				R_Bansf_Rec.Gettype := '2';
			end if;

			--'首發註記';  R_badapr_rec.Aplpaydate前六碼與主檔paydate前六碼一致即視為首發
			--If R_Bansf_Rec.Mchktyp ='1' Then
			if substr(R_Bansf_rec.Paydate, 1, 6) =
			   substr(R_Baappbase_Rec.Paydate, 1, 6) then
				R_Bansf_Rec.Firstpay := '1';
			Else
				R_Bansf_Rec.Firstpay := '0';
			End If;

			V_Key_Ubno := R_Bansf_rec.Ubno;

			--取得caub
			P_Read_Caub;
			R_Bansf_rec.UBTYPE := nvl(R_Caub_Rec.UBTYPE, 'Z9'); --'單位類別';
			R_Bansf_rec.Inds   := R_Caub_Rec.Inds; --'小業別';
			R_Bansf_rec.HINCD  := SUBSTR(R_Caub_Rec.HINCD, 1, 2); --'職災代號';
			R_Bansf_rec.IDSTA  := R_Caub_Rec.IDSTA; --'大業別';
			R_Bansf_rec.AREA   := R_Caub_Rec.AREA; --'地區別';
			R_Bansf_rec.CLSQTY := R_Caub_Rec.PRSNO_B; --'月末人數';

			V_Key_Idn    := R_Bansf_Rec.Evtidnno;
			V_Key_Brdate := R_Bansf_Rec.Evtbrdate;
			V_Key_Name   := R_Bansf_Rec.Evtname;
			If R_Bansf_Rec.Adwkmk = '2' Then
				V_Key_Intyp := 'V';
			Else
				V_Key_Intyp := 'L';
			end if;

			--取得cipb
			P_Read_Cipb;
			R_Bansf_rec.Hbedmk := R_Cipb_Rec.Hbedmk; --'年金施行前有無保險年資';
			R_Bansf_Rec.Adjym  := R_Cipb_Rec.Adjym; --'投保薪資調整年月';
			R_Bansf_Rec.Adjmk  := R_Cipb_Rec.Adjmk; --'逕調註記';
			R_Bansf_Rec.Ciid   := R_Cipb_Rec.CIID; --'勞就保識別碼';

			/*
                   老年年金 4X
            先判斷有無舊年資=N,無舊年資則現制一次失能金額=0,有舊年資則計算金額(且為勞保者)
            計算方式：
            依CIID讀取dss.CIPB
            計算年資基數(算至小數第2位)：
               CIPB.NOLDTY >=15 ,年資基數=15+((CIPB.NOLDTY-15)*2)+((CIPB.NOLDTM/12)*2)
               CIPB.NOLDTY  <15 ,年資基數=(CIPB.NOLDTY*1)+((CIP.NOLDTM/12)*1)
            現制一次老年金額=CIPB.AVGWG平均薪資*年資基數
                   */

			if substr(R_Bansf_Rec.Payno, 1, 1) = '4' then
				CASE
					WHEN R_Cipb_Rec.Hbedmk = 'Y' AND R_Cipb_Rec.INTYP = 'L' AND
						 R_Cipb_Rec.Noldty >= 15 THEN
						R_Bansf_Rec.LUMSUM := R_Cipb_Rec.AVGWG *
											  (15 +
											  ((R_Cipb_Rec.NOLDTY - 15) * 2) +
											  ((R_Cipb_Rec.NOLDTM / 12) * 2));
					WHEN R_Cipb_Rec.Hbedmk = 'Y' AND R_Cipb_Rec.INTYP = 'L' AND
						 R_Cipb_Rec.Noldty < 15 THEN
						R_Bansf_Rec.LUMSUM := R_Cipb_Rec.AVGWG *
											  ((R_Cipb_Rec.NOLDTY * 1) +
											  ((R_Cipb_Rec.NOLDTM / 12) * 1));
					ELSE
						R_Bansf_Rec.LUMSUM := 0;
				END CASE;
			else
				R_Bansf_Rec.LUMSUM := 0;
			end if;

		EXCEPTION
			WHEN NO_DATA_FOUND THEN
				sw_found := FALSE;
			WHEN OTHERS THEN
				sw_found := FALSE;
				Log_Msg('p_read_baappbase發生錯誤,APNO=' || V_Key_Apno ||
						',錯誤代碼=' || Sqlcode || ',' || '錯誤訊息=' || Sqlerrm);
				p_return_code := p_return_code ||
								 'p_read_baappbase發生錯誤,APNO=' || V_Key_Apno ||
								 ',錯誤代碼=' || Sqlcode || ',' || '錯誤訊息=' ||
								 Sqlerrm || ',';

                --20190827 Add by Angela RecLog Start
                SP_BA_RecBatchJobDtl(BAJOBDTLID.NEXTVAL,
                                     v_i_bajobid,
                                     '1',
                                     '(DB)SP_BANSF_01：讀取勞保給付主檔二(BAAPPBASE)發生錯誤，APNO='||V_Key_Apno||'***',
                                     replace(to_Char(SYSTIMESTAMP, 'yyyyMMddHH24missxff'),'.',''));
                --20190827 Add by Angela RecLog End;
        End;
		---------------------------------------------------------------------------------
		-- 新資料轉入
		-------------------------------------------------------------------------------
		PROCEDURE p_bansf_proc Is
		Begin
			V_Iisuym := Null;
			For r_badapr_rec In C_Badapr_REF Loop
				R_Bansf_rec := Null;
				-- if length(r_badapr_rec.APLPAYDATE)='7' then
				--    R_Bansf_rec.Paydate       :=r_badapr_rec.APLPAYDATE+'19110000';    --'核付日期';
				-- else
				R_Bansf_rec.Paydate := r_badapr_rec.APLPAYDATE; --'核付日期';
				-- end if;
				R_Bansf_rec.ISSUYM := r_badapr_rec.ISSUYM; --'核定年月';
				R_Bansf_Rec.Payym  := R_Badapr_Rec.Payym; --'給付年月';
				v_edate            := R_Bansf_Rec.Payym;

				R_BANSF_REC.APNO      := R_BADAPR_REC.APNO; --'受理編號';
				R_BANSF_REC.SEQNO     := R_BADAPR_REC.SEQNO; --'序號';
				R_Bansf_Rec.Paykind   := Substr(R_Bansf_Rec.Apno, 1, 1); --'給付別';
				R_Bansf_rec.NITRMY    := r_badapr_rec.NITRMY; --'勞保投保年資(年-年金制)';
				R_Bansf_Rec.Nitrmm    := R_Badapr_Rec.Nitrmm; --'勞保投保年資(月-年金制)';
				R_Bansf_Rec.Code      := R_Badapr_Rec.Suprecmk; --'補收註記';
				R_Bansf_Rec.Mchktyp   := R_Badapr_Rec.Mchktyp; --'月核案件類別';
				R_Bansf_Rec.Oldab     := R_Badapr_Rec.Oldab; --'第一式/第二式';
				R_Bansf_Rec.Oldaamt   := Nvl(R_Badapr_Rec.Oldaamt, 0); --'第一式金額(勞保給付金額)';
				R_Bansf_Rec.Oldbamt   := Nvl(R_Badapr_Rec.Oldbamt, 0); --'第二式金額(勞保給付金額)';
				R_Bansf_Rec.Qualcount := R_Badapr_Rec.Qualcount; --'符合眷屬(遺屬)人數';
				R_Bansf_Rec.Payno     := R_Badapr_Rec.Paykind; --'給付種類';
				R_Bansf_Rec.Cutamt    := Nvl(r_badapr_rec.Cutamt, 0); --'應扣失能金額';
				/*2014/02/18
                        L-老年=>OLDRATE一律給0%
                        K-失能=>0人0%，1人25%，>=2人50%
                        S-遺屬=>0或1人0%，2人25%，>=3人50%
                */
				if SUBSTR(R_Badapr_Rec.APNO, 1, 1) = 'S' then
					IF R_Badapr_Rec.qualcount = 0 OR
					   R_Badapr_Rec.qualcount is null or
					   R_Badapr_Rec.Qualcount = 1 THEN
						R_Bansf_rec.oldrate := 0; --加計比率
					Else
						If R_Badapr_Rec.Qualcount = 2 Then
							R_Bansf_rec.oldrate := 25; --加計比率
						ELSE
							R_Bansf_rec.oldrate := 50; --加計比率
						End If;
					End If;
				else
					IF R_Badapr_Rec.qualcount = 0 OR
					   R_Badapr_Rec.qualcount is null THEN
						R_Bansf_rec.oldrate := 0; --加計比率
					Else
						If R_Badapr_Rec.Qualcount = 1 Then
							R_Bansf_rec.oldrate := 25; --加計比率
						ELSE
							R_Bansf_rec.oldrate := 50; --加計比率
						End If;
					End If;
				end if; --2014/02/18
				if SUBSTR(R_Badapr_Rec.APNO, 1, 1) = 'L' then
					R_Bansf_rec.oldrate := 0; --加計比率
				end if;

				/*         IF r_badapr_rec.qualcount is null or r_badapr_rec.qualcount=0 THEN
                   R_Bansf_rec.oldrate     :=0 ; --加計比率
                Else
                   If R_Bansf_rec.Qualcount=1 Then
                      R_Bansf_rec.oldrate     :=25 ; --加計比率
                   ELSE
                      R_Bansf_rec.oldrate     :=50 ; --加計比率
                   End If;
                End If;*/

				R_Bansf_rec.Annuamt  := Nvl(r_badapr_rec.Annuamt, 0); --'累計已領年金金額';
				R_Bansf_rec.Nachgmk  := r_badapr_rec.Nachgmk; --'普職互改註記';
				R_Bansf_rec.Lecomamt := nvl(r_badapr_rec.Lecomamt, 0); --'己扣失能金額';
				V_Key_Baappbaseid    := R_Badapr_Rec.Baappbaseid; --給付主檔資料編號

				/*1.給付種類<>37
                (1)補收註記為C或D不計件數。
                (2)補收註記不為C且不為D，同一核定年月同一受理編號，只計1件(同一受理編號只看同一核定年月，不看其他核定年月，不看給付種類37)
                         */
				Case
					When R_Bansf_Rec.Code = 'C' Then
						R_Bansf_Rec.Paycnt := 0;
						R_Bansf_Rec.Pamts  := R_Badapr_Rec.Supamt;
					When R_Bansf_Rec.Code = 'D' Then
						R_Bansf_Rec.Paycnt := 0;
						R_Bansf_Rec.Pamts  := 0 - R_Badapr_Rec.Recamt;
					When V_Key_Apno = R_Bansf_rec.Apno And
						 V_Iisuym = substr(R_badapr_rec.Aplpaydate, 1, 6) Then
						R_Bansf_Rec.Paycnt := 0;
						R_Bansf_Rec.Pamts  := R_Badapr_Rec.BEFISSUEAMT;
					When R_Badapr_Rec.BEFISSUEAMT > 0 Then
						--20130219 UPDATDE
						R_Bansf_rec.Paycnt := 1;
						R_Bansf_Rec.Pamts  := R_Badapr_Rec.BEFISSUEAMT;
					Else
						R_Bansf_rec.Paycnt := 0;
						R_Bansf_Rec.Pamts  := R_Badapr_Rec.BEFISSUEAMT;
				End Case;
				--    DBMS_OUTPUT.PUT_LINE( V_Key_Apno||';'||R_BANSF_REC.APNO||';'||R_Bansf_Rec.Code||';'||V_Key_Apno||';'||V_Iisuym||';'||R_Bansf_rec.Issuym||';'||to_char(R_Badapr_Rec.BEFISSUEAMT)||';'||R_Bansf_rec.Paycnt);

				R_Bansf_rec.Evtype := R_Badapr_Rec.Evtyp;
				if R_Bansf_rec.Evtype is null then
					R_Bansf_rec.Evtype := '3';
				end if;
				R_Bansf_rec.Evcode  := R_Badapr_Rec.Evcode; --'事故原因';
				R_Bansf_rec.Injname := R_Badapr_Rec.Criinjnme1; --'傷病名稱(國際疾病代碼)';
				R_Bansf_rec.Injno   := R_Badapr_Rec.Criinjdp1; --'障礙(失能)項目';
				R_Bansf_rec.INJdp   := F_injdp(R_Bansf_rec.Injno); --'障礙(失能部位)';
				R_Bansf_rec.Injpart := TRIM(UPPER(R_Badapr_Rec.criinpart1)); --'受傷部位';
				R_Bansf_Rec.Medium  := R_Badapr_Rec.Crimedium; --'媒介物';
				--20130320
				CASE
					WHEN R_Badapr_Rec.Criinissul IS NOT NULL Then
						R_Bansf_rec.Injcl := R_Badapr_Rec.Criinissul; --'失能等級 (身心障礙等級)';  BAAPPEXPAND.CRIINISSUL
					WHEN R_Badapr_Rec.CRIINJCL1 IS NOT NULL Then
						R_Bansf_rec.Injcl := R_Badapr_Rec.CRIINJCL1; --'失能等級 (身心障礙等級)';  BAAPPEXPAND.CRIINISSUL
					WHEN R_Badapr_Rec.CRIINJCL2 IS NOT NULL Then
						R_Bansf_rec.Injcl := R_Badapr_Rec.CRIINJCL2; --'失能等級 (身心障礙等級)';  BAAPPEXPAND.CRIINISSUL
					WHEN R_Badapr_Rec.CRIINJCL3 IS NOT NULL Then
						R_Bansf_rec.Injcl := R_Badapr_Rec.CRIINJCL3; --'失能等級 (身心障礙等級)';  BAAPPEXPAND.CRIINISSUL
					ELSE
						R_Bansf_rec.Injcl := NULL;
				END CASE;
				--符合離職退保後職災殘廢給付職業病種類(Y/N)
				If R_Badapr_Rec.Ocaccidentmk = 'Y' Then
					R_Bansf_rec.CHKKIND := 'Y';
				Else
					R_Bansf_rec.CHKKIND := 'N';
				End If;

				R_Bansf_rec.Adwkmk := R_Badapr_Rec.adwkmk_ex;
				R_Bansf_Rec.Cat    := '1';

				V_KEY_APNO  := R_BANSF_REC.APNO;
				V_KEY_SEQNO := r_badapr_rec.SEQNO;
				V_Iisuym    := substr(R_badapr_rec.Aplpaydate, 1, 6);

				R_Baappbase_Rec := Null;
				If r_badapr_rec.apno_ba is null Then
					P_Read_Baappbase_D;
				else
					R_Baappbase_Rec.Baappbaseid  := r_badapr_rec.baappbaseid;
					R_Baappbase_Rec.apno         := r_badapr_rec.APNO_BA;
					R_Baappbase_Rec.Appdate      := r_badapr_rec.Appdate;
					R_Baappbase_Rec.Evtjobdate   := r_badapr_rec.Evtjobdate;
					R_Baappbase_Rec.LSUBNO       := r_badapr_rec.LSUBNO;
					R_Baappbase_Rec.EVTSEX       := r_badapr_rec.EVTSEX;
					R_Baappbase_Rec.Evtage       := r_badapr_rec.Evtage;
					R_Baappbase_Rec.Evtnationtpe := r_badapr_rec.Evtnationtpe;
					R_Baappbase_Rec.Closecause   := r_badapr_rec.Closecause;
					R_Baappbase_Rec.Evtidnno     := r_badapr_rec.Evtidnno;
					R_Baappbase_Rec.Evtbrdate    := r_badapr_rec.Evtbrdate;
					R_Baappbase_Rec.Evtname      := r_badapr_rec.Evtname;
					R_Baappbase_Rec.Evtdiedate   := r_badapr_rec.Evtdiedate;
					R_Baappbase_Rec.Casetyp      := r_badapr_rec.Casetyp;
					R_Baappbase_Rec.Apitem       := r_badapr_rec.Apitem;
					R_Baappbase_Rec.Lsinsmamt    := r_badapr_rec.Lsinsmamt;
					R_Baappbase_Rec.Paydate      := r_badapr_rec.Paydate;
				End If;
				--取得主檔、延伸檔、單位類別等資料
				Update_Data;
				--20131206 非被保險人則取被保險人之Insavgamt
				if r_badapr_rec.seqno <> '0000' and
				   r_badapr_rec.seqno is not null then
					R_Bansf_Rec.Pwage := F_pwage(R_Bansf_Rec.Apno,
												 v_edate/*,
												 R_Bansf_Rec.Payno*/); --'平均薪資';
				else
					R_Bansf_Rec.Pwage := R_Badapr_Rec.Insavgamt; --'平均薪資';
				end if;

				If R_Bansf_Rec.Payno in ('45', '48') Then
					R_Bansf_Rec.Oldextrarate := R_Badapr_Rec.Oldrate; --(老年、遺屬)展延/減額比率
				Else
					R_Bansf_Rec.Oldextrarate := R_Badapr_Rec.Oldextrarate; --(老年、遺屬)展延/減額比率
				End If;

				If R_Bansf_Rec.Payno <> '49' Then
					Insert Into Bansf
						(Select R_Bansf_Rec.Paydate,
								R_Bansf_Rec.Appdate,
								R_Bansf_Rec.Issuym,
								R_Bansf_Rec.Payym,
								R_Bansf_Rec.Apno,
								R_Bansf_Rec.SEQNO,
								R_Bansf_Rec.Evdate,
								R_Bansf_Rec.Ubno,
								R_Baappbase_Rec.Lsubno,
								R_Bansf_Rec.Ubtype,
								R_Bansf_Rec.Inds,
								R_Bansf_Rec.Hincd,
								R_Bansf_Rec.Idsta,
								R_Bansf_Rec.Area,
								R_Bansf_Rec.Clsqty,
								R_Bansf_Rec.Sex,
								R_Bansf_Rec.Payage,
								R_Bansf_Rec.Age,
								R_Bansf_Rec.Agetype,
								R_Bansf_Rec.Evtnationtpe,
								R_Bansf_Rec.Payno,
								R_Bansf_Rec.Nitrmy,
								R_Bansf_Rec.Nitrmm,
								R_Bansf_Rec.Evtype,
								R_Bansf_Rec.Evcode,
								R_Bansf_Rec.Injname,
								R_Bansf_Rec.Injno,
								R_Bansf_Rec.Injdp,
								R_Bansf_Rec.Injpart,
								R_Bansf_Rec.Medium,
								R_Bansf_Rec.Injcl,
								R_Bansf_Rec.Apitem,
								R_Bansf_Rec.Chkkind,
								R_Bansf_Rec.Pwage,
								R_Bansf_Rec.Wage,
								R_Bansf_Rec.Paycnt,
								R_Bansf_Rec.Code,
								R_Bansf_Rec.Pamts,
								R_Bansf_Rec.Adwkmk,
								R_Bansf_Rec.Mchktyp,
								R_Bansf_Rec.Oldab,
								R_Bansf_Rec.Oldaamt,
								R_Bansf_Rec.Oldbamt,
								R_Bansf_Rec.Oldextrarate,
								R_Bansf_Rec.Qualcount,
								R_Bansf_Rec.Oldrate,
								R_Bansf_Rec.Closecause,
								R_Bansf_Rec.Annuamt,
								R_Bansf_Rec.Hbedmk,
								R_Badapr_Rec.Nachgmk,
								R_Bansf_Rec.Cutamt,
								R_Bansf_Rec.Lecomamt,
								R_Bansf_Rec.Paykind,
								Decode(Length(R_Bansf_Rec.Evtidnno),
									   11,
									   Substr(R_Bansf_Rec.Evtidnno, 1, 10),
									   R_Bansf_Rec.Evtidnno),
								Decode(Length(R_Bansf_Rec.Evtidnno),
									   11,
									   Substr(R_Bansf_Rec.Evtidnno, 10, 1),
									   Null),
								R_Bansf_Rec.Evtbrdate,
								R_Bansf_Rec.Evtname,
								R_Bansf_Rec.edate,
								R_Bansf_Rec.bdate,
								R_Bansf_Rec.Evtdiedate,
								R_Bansf_Rec.Adjym,
								DECODE(R_Bansf_Rec.Adjmk,
									   NULL,
									   'N',
									   R_Bansf_Rec.Adjmk),
								R_Bansf_Rec.Gettype,
								R_Bansf_Rec.Firstpay,
								R_Bansf_Rec.Ciid,
								R_Bansf_Rec.Lumsum,
								R_Bansf_Rec.Cat,
								0,
								0,
								null,
                                ''
						   From Dual);
					--2014/04/28增加 DEFAULT PAYNO=3x,4x
					IF r_badapr_rec.seqno = '0000' AND
					   R_Bansf_Rec.Evtdiedate IS NOT NULL THEN
						Insert Into Bansf_TEMP
							(Select R_Bansf_Rec.Paydate,
									R_Bansf_Rec.Appdate,
									R_Bansf_Rec.Issuym,
									R_Bansf_Rec.Payym,
									R_Bansf_Rec.Apno,
									R_Bansf_Rec.SEQNO,
									R_Bansf_Rec.Evdate,
									R_Bansf_Rec.Ubno,
									R_Baappbase_Rec.Lsubno,
									R_Bansf_Rec.Ubtype,
									R_Bansf_Rec.Inds,
									R_Bansf_Rec.Hincd,
									R_Bansf_Rec.Idsta,
									R_Bansf_Rec.Area,
									R_Bansf_Rec.Clsqty,
									R_Bansf_Rec.Sex,
									R_Bansf_Rec.Payage,
									R_Bansf_Rec.Age,
									R_Bansf_Rec.Agetype,
									R_Bansf_Rec.Evtnationtpe,
									R_Bansf_Rec.Payno,
									R_Bansf_Rec.Nitrmy,
									R_Bansf_Rec.Nitrmm,
									R_Bansf_Rec.Evtype,
									R_Bansf_Rec.Evcode,
									R_Bansf_Rec.Injname,
									R_Bansf_Rec.Injno,
									R_Bansf_Rec.Injdp,
									R_Bansf_Rec.Injpart,
									R_Bansf_Rec.Medium,
									R_Bansf_Rec.Injcl,
									R_Bansf_Rec.Apitem,
									R_Bansf_Rec.Chkkind,
									R_Bansf_Rec.Pwage,
									R_Bansf_Rec.Wage,
									R_Bansf_Rec.Paycnt,
									R_Bansf_Rec.Code,
									R_Bansf_Rec.Pamts,
									R_Bansf_Rec.Adwkmk,
									R_Bansf_Rec.Mchktyp,
									R_Bansf_Rec.Oldab,
									R_Bansf_Rec.Oldaamt,
									R_Bansf_Rec.Oldbamt,
									R_Bansf_Rec.Oldextrarate,
									R_Bansf_Rec.Qualcount,
									R_Bansf_Rec.Oldrate,
									R_Bansf_Rec.Closecause,
									R_Bansf_Rec.Annuamt,
									R_Bansf_Rec.Hbedmk,
									R_Badapr_Rec.Nachgmk,
									R_Bansf_Rec.Cutamt,
									R_Bansf_Rec.Lecomamt,
									R_Bansf_Rec.Paykind,
									Decode(Length(R_Bansf_Rec.Evtidnno),
										   11,
										   Substr(R_Bansf_Rec.Evtidnno,
												  1,
												  10),
										   R_Bansf_Rec.Evtidnno),
									Decode(Length(R_Bansf_Rec.Evtidnno),
										   11,
										   Substr(R_Bansf_Rec.Evtidnno,
												  10,
												  1),
										   Null),
									R_Bansf_Rec.Evtbrdate,
									R_Bansf_Rec.Evtname,
									R_Bansf_Rec.edate,
									R_Bansf_Rec.bdate,
									R_Bansf_Rec.Evtdiedate,
									R_Bansf_Rec.Adjym,
									DECODE(R_Bansf_Rec.Adjmk,
										   NULL,
										   'N',
										   R_Bansf_Rec.Adjmk),
									R_Bansf_Rec.Gettype,
									R_Bansf_Rec.Firstpay,
									R_Bansf_Rec.Ciid,
									R_Bansf_Rec.Lumsum,
									R_Bansf_Rec.Cat,
									0,
									0,
									null
							   From Dual);
					END IF;
					V_Out_Cnt := V_Out_Cnt + 1;
				end if;

				--  V_Iisuym:=substr(R_badapr_rec.Aplpaydate,1,6);
				If Mod(V_Out_Cnt, 50000) = 0 Then
					Commit;
				END IF;
			END LOOP;
			--2014/04/28
			DELETE BANSF_TEMP WHERE Evtdiedate IS NULL OR nvl(Evtdiedate,' ') = ' ';
			COMMIT;

			UPDATE BANSF
			   SET Evtdiedate =
				   (SELECT DISTINCT Evtdiedate
					  FROM BANSF_TEMP
					 WHERE Evtdiedate IS NOT NULL
					   AND APNO = BANSF.APNO
					   AND ROWNUM < 2)
			 WHERE APNO IN (SELECT DISTINCT APNO
							  FROM BANSF_TEMP
							 WHERE Evtdiedate IS NOT NULL)
			   AND SEQNO = '0000'
			   AND SUBSTR(PAYNO, 1, 1) <> '5';
			commit;

			UPDATE BANSF
			   SET UBTYPE = CASE
								WHEN UBTYPE IS NULL OR TRIM(UBTYPE) = '' THEN
								 'Z9'
								ELSE
								 UBTYPE
							END,
				   INDS = CASE
							  WHEN INDS IS NULL OR TRIM(INDS) = '' THEN
							   'Z999'
							  ELSE
							   INDS
						  END,
				   AREA = CASE
							  WHEN AREA IS NULL OR TRIM(AREA) = '' THEN
							   'Z999'
							  ELSE
							   AREA
						  END,
				   CLSQTY = CASE
								WHEN CLSQTY IS NULL THEN
								 0
								ELSE
								 CLSQTY
							END,
				   Evtnationtpe = decode(Evtnationtpe,
										 null,
										 'C',
										 'N',
										 'C',
										 'F',
										 'Y',
										 'Y',
										 'Y',
										 '1',
										 '1',
										 '2',
										 '2',
										 'Z'), --國藉
				   NITRMY = CASE
								WHEN NITRMY IS NULL THEN
								 0
								ELSE
								 NITRMY
							END,
				   NITRMM = CASE
								WHEN NITRMM IS NULL THEN
								 0
								ELSE
								 NITRMM
							END,
				   EVCODE = CASE
								WHEN EVCODE IS NULL OR TRIM(EVCODE) = '' THEN
								 'Z9'
								ELSE
								 EVCODE
							END,
				   INJNAME = Case
								 When INJNAME Is Null Or Trim(INJNAME) = '' Then
								  'Z999999'
								 Else
								  EVCODE
							 End,
				   INJNO = CASE
							   WHEN INJNO IS NULL OR TRIM(INJNO) = '' THEN
								'Z9999999'
							   ELSE
								INJNO
						   END,
				   INJPART = CASE
								 WHEN INJPART IS NULL OR TRIM(INJPART) = '' THEN
								  'Z99'
								 ELSE
								  INJPART
							 END,
				   MEDIUM = CASE
								WHEN MEDIUM IS NULL OR TRIM(MEDIUM) = '' THEN
								 'Z99'
								ELSE
								 MEDIUM
							END,
				   INJCL = CASE
							   WHEN INJCL IS NULL OR TRIM(INJCL) = '' THEN
								'Z9'
							   WHEN LENGTH(INJCL) = 1 THEN
								'0' || INJCL
							   ELSE
								INJCL
						   END,
				   APITEM = CASE
								WHEN APITEM IS NULL OR
									 TRIM(APITEM) = '' AND
									 SUBSTR(PAYNO, 1, 1) = '3' THEN
								 '0'
								when APITEM IS NULL OR TRIM(APITEM) = '' then
								 'Z'
								Else
								 Apitem
							End,
				   pwage = Case
							   When pwage Is Null Then
								0
							   Else
								pwage
						   End,
				   WAGE = CASE
							  WHEN WAGE IS NULL THEN
							   0
							  ELSE
							   WAGE
						  END,
				   PAMTS = CASE
							   WHEN PAMTS IS NULL THEN
								0
							   ELSE
								PAMTS
						   END,
				   LUMSUM = CASE
								WHEN LUMSUM IS NULL THEN
								 0
								ELSE
								 LUMSUM
							END,
				   MCHKTYP = CASE
								 WHEN MCHKTYP IS NULL OR TRIM(MCHKTYP) = '' THEN
								  'Z'
								 ELSE
								  MCHKTYP
							 END,
				   OLDEXTRARATE = CASE
									  WHEN OLDEXTRARATE IS NULL THEN
									   0
									  ELSE
									   OLDEXTRARATE
								  END,
				   QUALCOUNT = CASE
								   WHEN QUALCOUNT IS NULL THEN
									0
								   ELSE
									QUALCOUNT
							   END,
				   OLDRATE = CASE
								 WHEN OLDRATE IS NULL THEN
								  0
								 ELSE
								  OLDRATE
							 END,
				   CLOSECAUSE = CASE
									WHEN CLOSECAUSE IS NULL OR
										 TRIM(CLOSECAUSE) = '' THEN
									 'Z9'
									ELSE
									 CLOSECAUSE
								END,
				   adwkmk = CASE
								WHEN adwkmk IS NULL OR TRIM(adwkmk) = '' THEN
								 '1'
								ELSE
								 adwkmk
							END,
				   SEX = CASE
							 WHEN SEX IS NULL OR TRIM(SEX) = '' OR SEX = 'C' THEN
							  'Z'
							 ELSE
							  SEX
						 END,
				   PAYAGE = CASE
								WHEN (PAYAGE IS NULL or payage <= 0) AND
									 substr(apno, 1, 1) = 'S' and
									 Substr(Evtdiedate, 5, 2) >
									 Substr(EVTBRDATE, 5, 2) THEN
								 to_number(Substr(Evtdiedate, 1, 4) -
										   Substr(EVTBRDATE, 1, 4) - 1)
								WHEN (PAYAGE IS NULL or payage <= 0) AND
									 substr(apno, 1, 1) = 'S' and
									 Substr(Evtdiedate, 5, 2) <=
									 Substr(EVTBRDATE, 5, 2) THEN
								 to_number(Substr(Evtdiedate, 1, 4) -
										   Substr(EVTBRDATE, 1, 4))
								WHEN (PAYAGE IS NULL or payage <= 0) AND
									 substr(apno, 1, 1) <> 'S' and
									 Substr(PAYYM, 5, 2) >
									 Substr(EVTBRDATE, 5, 2) THEN
								 to_number(Substr(PAYYM, 1, 4) -
										   Substr(EVTBRDATE, 1, 4) - 1)
								WHEN (PAYAGE IS NULL or payage <= 0) AND
									 substr(apno, 1, 1) <> 'S' and
									 Substr(PAYYM, 5, 2) <=
									 Substr(EVTBRDATE, 5, 2) THEN
								 to_number(Substr(PAYYM, 1, 4) -
										   Substr(EVTBRDATE, 1, 4))
								ELSE
								 to_number(PAYAGE)
							END,
				   AGE = CASE
							 WHEN PAYNO = '37' AND Substr(EVTBRDATE, 5, 2) >
								  Substr(Evdate, 5, 2) THEN
							  to_number(Substr(Evdate, 1, 4) -
										Substr(EVTBRDATE, 1, 4) - 1)
							 WHEN PAYNO = '37' AND Substr(EVTBRDATE, 5, 2) <=
								  Substr(Evdate, 5, 2) THEN
							  to_number(Substr(Evdate, 1, 4) -
										Substr(EVTBRDATE, 1, 4))
							 WHEN PAYAGE IS NULL THEN
							  0
							 ELSE
							  AGE
						 END,
				   EVTYPE = CASE
								WHEN EVTYPE IS NULL THEN
								 '3'
								ELSE
								 EVTYPE
							END,
				   FIRSTPAY = CASE
								  WHEN FIRSTPAY IS NULL THEN
								   '0'
								  ELSE
								   FIRSTPAY
							  END,
				   CHKKIND = CASE
								 WHEN CHKKIND IS NULL OR TRIM(CHKKIND) = '' THEN
								  'N'
								 ELSE
								  CHKKIND
							 END,
				   ADJMK = CASE
							   WHEN ADJMK IS NULL OR TRIM(ADJMK) = '' THEN
								'N'
							   ELSE
								ADJMK
						   END,
				   HBEDMK = CASE
								WHEN HBEDMK IS NULL OR TRIM(HBEDMK) = '' THEN
								 'Y'
								ELSE
								 HBEDMK
							END,
				   code = CASE
							  WHEN code = 'K' THEN
							   'D'
							  ELSE
							   code
						  END
			 WHERE (ISSUYM = P_INSUYM OR P_INSUYM = '201208');
			commit;

		EXCEPTION
			WHEN OTHERS Then
				DBMS_OUTPUT.put_line(v_key_APNO);
				p_return_code   := p_return_code || v_key_APNO || ',';
				V_Exception_Cnt := V_Exception_Cnt + 1;
				DBMS_OUTPUT.put_line('p_dwamf_old_proc發生錯誤,錯誤代碼=' ||
									 sqlcode || ',' || '錯誤訊息=' || SQLERRM);
				p_return_code := p_return_code ||
								 'p_dwamf_old_proc發生錯誤,錯誤代碼=' || sqlcode || ',' ||
								 '錯誤訊息=' || SQLERRM || ',';

                --20190827 Add by Angela RecLog Start
                SP_BA_RecBatchJobDtl(BAJOBDTLID.NEXTVAL,
                                     v_i_bajobid,
                                     '1',
                                     '(DB)SP_BANSF_01：統計資料轉入發生錯誤，APNO='||v_key_APNO||'***',
                                     replace(to_Char(SYSTIMESTAMP, 'yyyyMMddHH24missxff'),'.',''));
                --20190827 Add by Angela RecLog End;
        END;
		-- ============================================================================
		--                      <<<<<<<<< MAIN procedure >>>>>>>>>>
		-------------------------------------------------------------------------------
	Begin
		DBMS_OUTPUT.put_line('勞保年金統計檔資料轉入');
		p_return_code := p_return_code || '勞保年金統計檔資料轉入' || ',';
		--   p_return_code := 'OK';  --回傳訊息
		--初期處理------------------------------------------------------
		BEGIN
			-- 檢查參數內容
			-- 處理年月
			Dbms_Output.Put_Line('處理年月=' || P_Insuym);
			p_return_code := p_return_code || '處理年月=' || P_Insuym || ',';
			--v_format_date := TO_DATE(P_Insuym || '01', 'YYYYMMDD');
		EXCEPTION
			WHEN OTHERS THEN
				DBMS_OUTPUT.put_line('輸入參數資料錯誤EXCEPTION！');
				p_return_code := p_return_code || '輸入參數資料錯誤EXCEPTION！' || ',';
				--        p_return_code := 'NO';  --回傳訊息
				Dbms_Output.Put_Line('初期處理失敗：錯誤代碼=' || Sqlcode || ' ， ' ||
									 '錯誤訊息=' || Sqlerrm);
				p_return_code := p_return_code || '初期處理失敗：錯誤代碼=' || Sqlcode ||
								 ' ， ' || '錯誤訊息=' || Sqlerrm || ',';
				COMMIT;
				Return;
		END;
		--主程序處理=========================================================================

        --20190827 Add by Angela RecLog Start
        v_o_flag := '0';
        SP_BA_RecJobLog(p_job_no => v_i_mmJobNO,
                        p_job_id => 'PG_BANSF_01.SP_BANSF',
                        p_step   => '產生勞保年金統計檔資料作業(SP_BANSF_02)：勞保年金統計核定檔及勞保年金統計檔轉入(老年)',
                        p_memo   => '開始時間：'||to_Char(SYSTIMESTAMP,'YYYY/MM/DD HH24:MI:SS')||CHR(10)||'('||v_i_mmJobNO||')');

        SP_BA_RecBatchJobDtl(BAJOBDTLID.NEXTVAL,
                             v_i_bajobid,
                             '0',
                             '(DB)SP_BANSF_02：勞保年金統計核定檔及勞保年金統計檔轉入(老年)(開始)',
                             replace(to_Char(SYSTIMESTAMP, 'yyyyMMddHH24missxff'),'.',''));
        --20190827 Add by Angela RecLog End

        --1.刪除給付年月資料
		DBMS_OUTPUT.put_line('1.刪除給付年月資料');
		p_return_code := p_return_code || '1.刪除給付年月資料' || ',';
		If P_Insuym = '201208' Then
			p_delete_data;
			COMMIT;
		end IF;

		--2.勞保年金統計核定檔BADAPR_REF及勞保年金統計檔BANSF轉入
		Dbms_Output.Put_Line('2.勞保年金統計檔轉入' ||
							 To_Char(Sysdate, 'YYYY/MM/DD HH24:MI:SS'));
		p_return_code := p_return_code || '2.勞保年金統計檔轉入' ||
						 To_Char(Sysdate, 'YYYY/MM/DD HH24:MI:SS') || ',';
		P_Bansf_Proc;
		p_result_proc;

		If V_Exception_Cnt > 0 Then
			raise_application_error(-20001, '勞保年金統計檔處理失敗！');
            v_o_flag := '1';
		ELSE
			COMMIT;
		END IF;

		--==========================================================================================

		--結束處理
		--DBMS_OUTPUT.put_line('EXCEPTION錯誤筆數＝'||v_exception_cnt);
		IF v_exception_cnt > 0 THEN
			Rollback;
			--      P_Return_Code := 'NO';  --回傳訊息
			DBMS_OUTPUT.put_line('產生勞保年金統計檔失敗！' ||
								 To_Char(Sysdate, 'YYYY/MM/DD HH24:MI:SS'));
			p_return_code := p_return_code || '產生勞保年金統計檔失敗！' ||
							 To_Char(Sysdate, 'YYYY/MM/DD HH24:MI:SS') || ',';
		    v_o_flag := '1';
        Else
			DBMS_OUTPUT.put_line('產生勞保年金統計檔成功！' ||
								 To_Char(Sysdate, 'YYYY/MM/DD HH24:MI:SS'));
			p_return_code := p_return_code || '產生勞保年金統計檔成功！' ||
							 To_Char(Sysdate, 'YYYY/MM/DD HH24:MI:SS') || ',';
		END IF;

		p_output_message; --輸出結果
		COMMIT;

        --20190827 Add by Angela RecLog Start
        SP_BA_RecJobLog(p_job_no => v_i_mmJobNO,
                        p_job_id => 'PG_BANSF_01.SP_BANSF',
                        p_step   => '產生勞保年金統計檔資料作業(SP_BANSF_02)：勞保年金統計核定檔及勞保年金統計檔轉入(老年)',
                        p_memo   => '結束時間：'||to_Char(SYSTIMESTAMP,'YYYY/MM/DD HH24:MI:SS')||CHR(10)||'('||v_i_mmJobNO||')'||CHR(10)||'執行結果:('||v_o_flag||')');

        SP_BA_RecBatchJobDtl(BAJOBDTLID.NEXTVAL,
                             v_i_bajobid,
                             v_o_flag,
                             '(DB)SP_BANSF_02：勞保年金統計核定檔及勞保年金統計檔轉入(老年)(結束)',
                             replace(to_Char(SYSTIMESTAMP, 'yyyyMMddHH24missxff'),'.',''));

        if v_o_flag <> '0' then
            v_o_flag := 'N';
        else
            v_o_flag := 'E';
        end if;
        --20190827 Add by Angela RecLog End;
	EXCEPTION
		WHEN OTHERS THEN
			ROLLBACK;
			DBMS_OUTPUT.put_line('勞保年金統計檔失敗！' || SQLCODE || ' - ' || SQLERRM);
			p_return_code := p_return_code || '勞保年金統計檔失敗！' || SQLCODE || ' - ' || SQLERRM || ',';
			--      p_return_code := 'NO';  --回傳訊息
			p_output_message; --輸出結果
			COMMIT;

            --20190827 Add by Angela RecLog Start
            SP_BA_RecJobLog(p_job_no => v_i_mmJobNO,
                            p_job_id => 'PG_BANSF_01.SP_BANSF',
                            p_step   => '產生勞保年金統計檔資料作業(SP_BANSF_02)：勞保年金統計核定檔及勞保年金統計檔轉入(老年)',
                            p_memo   => '結束時間：'||to_Char(SYSTIMESTAMP,'YYYY/MM/DD HH24:MI:SS')||CHR(10)||'('||v_i_mmJobNO||')'||CHR(10)||'執行結果:(1)');

            SP_BA_RecBatchJobDtl(BAJOBDTLID.NEXTVAL,
                                 v_i_bajobid,
                                 '1',
                                 '(DB)SP_BANSF_02：勞保年金統計核定檔及勞保年金統計檔轉入(老年)(結束)',
                                 replace(to_Char(SYSTIMESTAMP, 'yyyyMMddHH24missxff'),'.',''));

            v_o_flag := 'N';
            --20190827 Add by Angela RecLog End;
	End;
End Sp_BAnsf_02;

