package gtu._work.ui;

import java.awt.Color;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JTable;
import javax.swing.RowFilter;
import javax.swing.RowSorter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.tuple.Pair;

import gtu.swing.util.JTableUtil;
import gtu.swing.util.JTableUtil.ColumnSearchFilter;

public class FastDBQueryUI_ColumnSearchFilterVer2 extends ColumnSearchFilter {
    private static final String QUERY_RESULT_COLUMN_NO = "No.";

    Map<Integer, List<Integer>> changeColorRowCellIdxMap = null;
    FindTextHandler finder = null;

    public FastDBQueryUI_ColumnSearchFilterVer2(JTable table, String delimit, Object[] alwaysMatchColumns) {
        super(table, delimit, alwaysMatchColumns);
    }

    class InnerMatch {
        Pattern ptn;

        InnerMatch(String singleText) {
            singleText = singleText.replaceAll(Pattern.quote("*"), ".*");
            ptn = Pattern.compile(singleText, Pattern.CASE_INSENSITIVE);
        }

        boolean find(String value) {
            Matcher mth = ptn.matcher(value);
            return mth.find();
        }
    }

    private Pair<String, List<Pattern>> filterPattern(String filterText) {
        Pattern ptn = Pattern.compile("\\/(.*?)\\/");
        Matcher mth = ptn.matcher(filterText);
        StringBuffer sb = new StringBuffer();
        List<Pattern> lst = new ArrayList<Pattern>();
        while (mth.find()) {
            String temp = mth.group(1);
            Pattern tmpPtn = null;
            if (StringUtils.isNotBlank(temp)) {
                try {
                    tmpPtn = Pattern.compile(temp, Pattern.CASE_INSENSITIVE);
                } catch (Exception ex) {
                }
            }
            if (tmpPtn != null) {
                lst.add(tmpPtn);
                mth.appendReplacement(sb, "");
            } else {
                mth.appendReplacement(sb, mth.group(0));
            }
        }
        mth.appendTail(sb);
        return Pair.of(sb.toString(), lst);
    }

    public void filterColumnText(String filterText) {
        super.filterText(filterText);
    }

    // -------------------------------------------------------------------------------
    // 以下是row filter
    // -------------------------------------------------------------------------------

    public static class FindTextHandler {
        String searchText;
        String delimit;

        boolean isAnd = false;
        boolean isAllMatch;
        String[] searchTextArry;

        FindTextHandler(String searchText, String delimit) {
            this.searchText = searchText;
            this.delimit = delimit;
            // --------------------------------------
            Pattern ptn = Pattern.compile("(and|\\&{2})\\s+(.*)", Pattern.CASE_INSENSITIVE);
            Matcher mth = ptn.matcher(searchText);
            if (mth.find()) {
                isAnd = true;
                this.searchText = mth.group(2);
            }

            // ---------------------------------------
            isAllMatch = StringUtils.isBlank(this.searchText);
            String[] arry = StringUtils.trimToEmpty(this.searchText).toLowerCase().split(Pattern.quote(delimit), -1);
            List<String> rtnLst = new ArrayList<String>();
            for (int ii = 0; ii < arry.length; ii++) {
                if (StringUtils.isNotBlank(arry[ii])) {
                    rtnLst.add(StringUtils.trimToEmpty(arry[ii]));
                }
            }
            searchTextArry = rtnLst.toArray(new String[0]);
        }

        boolean isAllMatch() {
            return isAllMatch;
        }

        String[] getArry() {
            return searchTextArry;
        }

        final NumberFormat bigDecimalFormatter = new DecimalFormat("##############################################.##############");

        String valueToString(Object value) {
            if (value == null) {
                return "";
            }
            if (value != null) {
                if (value.getClass() == BigDecimal.class) {
                    String strVal = bigDecimalFormatter.format(((BigDecimal) value));
                    return strVal;
                }
            }
            return String.valueOf(value).toLowerCase();
        }
    }

    private void addColorRowMatch(int rowIdx, List<String> cols, Map<Integer, List<Integer>> changeColorRowCellIdxMap) {
        List<Integer> lst = new ArrayList<Integer>();
        for (int ii = 0; ii < cols.size(); ii++) {
            lst.add(ii);
            ;
        }
        changeColorRowCellIdxMap.put(rowIdx, lst);
    }

    private void addColorCellMatch(int rowIdx, int cellIdx, Map<Integer, List<Integer>> changeColorRowCellIdxMap) {
        List<Integer> cellLst = new ArrayList<Integer>();
        if (changeColorRowCellIdxMap.containsKey(rowIdx)) {
            cellLst = changeColorRowCellIdxMap.get(rowIdx);
        }
        cellLst.add(cellIdx);
        changeColorRowCellIdxMap.put(rowIdx, cellLst);
    }

    public void filterRowText(String rowFilterText, boolean isIgnoreFirstColumn, boolean isKeepMatchOnly) {
        if (StringUtils.isBlank(rowFilterText)) {
            changeColorRowCellIdxMap = new HashMap<Integer, List<Integer>>();
            JTableUtil.newInstance(table).setCellBackgroundColor(Color.green.brighter(), changeColorRowCellIdxMap, null);
            table.setRowSorter(null);
            return;
        }

        if (isKeepMatchOnly) {
            hiddenRowNotMatch(rowFilterText);
        } else {
            table.setRowSorter(null);
        }

        this.__filterRowText(rowFilterText, isIgnoreFirstColumn, isKeepMatchOnly);

        JTableUtil.newInstance(table).debugShowCurrentTable();
    }

    private String __debugRowData(Object[] rows) {
        final int DATA_LENGTH = 30;
        List<Object> lst = new ArrayList<Object>();
        for (Object v : rows) {
            String strVal = null;
            if (v != null) {
                strVal = String.valueOf(v);
                if (StringUtils.length(strVal) > DATA_LENGTH) {
                    strVal = StringUtils.substring(strVal, 0, DATA_LENGTH) + "...";
                }
            }
            lst.add(strVal);
        }
        return lst.toString();
    }

    private Boolean isMatchColumnRowData(String text, int realCol, TreeMap<Integer, String> titleMap, TreeMap<Integer, Object> rowMap) {
        text = StringUtils.defaultString(text);
        String[] arry = text.split("\\=", -1);
        if (arry == null || arry.length != 2) {
            return null;
        }
        String column = StringUtils.trimToEmpty(arry[0]);
        String value = StringUtils.trimToEmpty(arry[1]).toLowerCase();
        if (StringUtils.isBlank(column) || StringUtils.isBlank(value)) {
            return null;
        }
        int findRealCol = -1;
        String column1 = titleMap.get(realCol);
        if (!StringUtils.equalsIgnoreCase(column, column1)) {
            return false;
        } else {
            findRealCol = realCol;
        }
        Object val = rowMap.get(findRealCol);
        if (val != null) {
            String strVal = String.valueOf(val);
            if (strVal.toLowerCase().contains(value)) {
                return true;
            }
        }
        return false;
    }

    private boolean isNoDotColumn(int col) {
        JTableUtil util = JTableUtil.newInstance(table);
        Object columnTitle = util.getColumnTitle(col);
        if (StringUtils.equals(QUERY_RESULT_COLUMN_NO, (String) columnTitle)) {
            return true;
        }
        return false;
    }

    private void __filterRowText(String rowFilterText, boolean isIgnoreFirstColumn, boolean isKeepMatchOnly) {
        List<Object[]> qList = new ArrayList<Object[]>();
        JTableUtil util = JTableUtil.newInstance(table);

        changeColorRowCellIdxMap = new HashMap<Integer, List<Integer>>();

        finder = new FindTextHandler(rowFilterText, "^");

        boolean allMatch = finder.isAllMatch();

        boolean hasNoColumn = isIgnoreFirstColumn;

        for (int rowIdx = 0; rowIdx < table.getRowCount(); rowIdx++) {

            int realRow = util.getRealRowPos(rowIdx, table);

            TreeMap<Integer, Object> rowMap = new TreeMap<Integer, Object>();
            TreeMap<Integer, String> titleMap = new TreeMap<Integer, String>();
            for (int col = 0; col < table.getColumnCount(); col++) {
                int realCol = util.getRealColumnPos(col, table);
                boolean visible = util.isColumnVisible(realCol, table);
                Object columnTitle = util.getColumnTitle(col);
                // System.out.println("show[kjfvhiahew]-------" + realCol + " /
                // " + columnTitle + " / " + visible);
                if (visible) {
                    Object value = util.getModel().getValueAt(realRow, realCol);
                    rowMap.put(realCol, value);
                    titleMap.put(realCol, (String) columnTitle);
                }
            }

            Object[] rows = rowMap.values().toArray();
            System.out.println("__filterRowText[3iandfo3]--------" + realRow + "\t" + __debugRowData(rows));
            if (allMatch) {
                qList.add(rows);
                // addColorRowMatch(rowIdx, cols,
                // changeColorRowCellIdxMap);
                continue;
            }

            Integer[] mappingColumns = rowMap.keySet().toArray(new Integer[0]);

            // is OR
            if (!finder.isAnd) {
                B: for (int ii = 0; ii < rows.length; ii++) {

                    String value = finder.valueToString(rows[ii]);

                    int realCol = mappingColumns[ii];

                    if (isNoDotColumn(realCol)) {
                        continue;
                    }

                    // is or
                    C: for (String text : finder.getArry()) {
                        // ========================================= 比對 AAA=bbb
                        Boolean columnAndValMatch = isMatchColumnRowData(text, realCol, titleMap, rowMap);
                        if (columnAndValMatch != null) {
                            if (columnAndValMatch) {
                                // 加入符合搜尋文字 TODO
                                if (!isKeepMatchOnly) {
                                    this._____addMatchRow_____(realCol, realRow);
                                } else {
                                    this._____addMatchRow_____(realCol, rowIdx);
                                }
                                break C;
                            }
                            // ========================================= 比對
                            // AAA=bbb
                        } else {
                            // 原來的
                            if (value.contains(text)) {
                                // 加入符合搜尋文字 TODO
                                if (!isKeepMatchOnly) {
                                    this._____addMatchRow_____(realCol, realRow);
                                } else {
                                    this._____addMatchRow_____(realCol, rowIdx);
                                }
                                break C;
                            }
                        }
                    }
                }
                // is AND
            } else {
                Set<Integer> matchRealColSet = new HashSet<Integer>();

                C: for (String text : finder.getArry()) {

                    B: for (int ii = 0; ii < rows.length; ii++) {

                        String value = finder.valueToString(rows[ii]);

                        int realCol = mappingColumns[ii];

                        if (isNoDotColumn(realCol)) {
                            continue;
                        }

                        // ========================================= 比對 AAA=bbb
                        Boolean columnAndValMatch = isMatchColumnRowData(text, realCol, titleMap, rowMap);
                        if (columnAndValMatch != null) {
                            if (columnAndValMatch) {
                                matchRealColSet.add(realCol);
                                break B;
                            }
                            // ========================================= 比對
                            // AAA=bbb
                        } else {
                            // 原來的
                            if (!value.contains(text)) {
                                matchRealColSet.add(realCol);
                                break B;
                            }
                        }
                    }
                }

                if (finder.getArry().length == matchRealColSet.size()) {
                    for (Integer realCol : matchRealColSet) {
                        // 加入符合搜尋文字 TODO
                        if (!isKeepMatchOnly) {
                            this._____addMatchRow_____(realCol, realRow);
                        } else {
                            this._____addMatchRow_____(realCol, rowIdx);
                        }
                    }
                }
            }
        }

        System.out.println("qList - " + qList.size());
        System.out.println("changeColorRowCellIdxMap - " + changeColorRowCellIdxMap);

        JTableUtil.newInstance(table).setCellBackgroundColor(Color.green.brighter(), changeColorRowCellIdxMap, null);
    }

    private void _____addMatchRow_____(int realCol, int rowIdx) {
        addColorCellMatch(rowIdx, realCol, changeColorRowCellIdxMap);
    }

    private void hiddenRowNotMatch(final String rowFilterText) {
        finder = new FindTextHandler(rowFilterText, "^");

        final JTableUtil util = JTableUtil.newInstance(table);
        List<RowSorter.SortKey> sortKeys = new ArrayList<RowSorter.SortKey>();
        // sortKeys.add(new RowSorter.SortKey(1, SortOrder.ASCENDING));
        // sortKeys.add(new RowSorter.SortKey(0, SortOrder.ASCENDING));
        // sorter.setSortKeys(sortKeys);
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<DefaultTableModel>((DefaultTableModel) table.getModel());
        sorter.setSortKeys(sortKeys);
        table.setRowSorter(sorter);
        sorter.setRowFilter(new RowFilter<DefaultTableModel, Integer>() {

            @Override
            public boolean include(Entry<? extends DefaultTableModel, ? extends Integer> entry) {
                if (StringUtils.isBlank(rowFilterText)) {
                    return true;
                }

                // is OR
                if (!finder.isAnd) {
                    for (int col = 0; col < table.getColumnCount(); col++) {
                        int realCol = util.getRealColumnPos(col, table);

                        // System.out.println("hiddenRowNotMatch [realCol]
                        // ------" + realCol);
                        if (isNoDotColumn(realCol)) {
                            continue;
                        }

                        int realRow = entry.getIdentifier();

                        TreeMap<Integer, Object> rowMap = new TreeMap<Integer, Object>();
                        TreeMap<Integer, String> titleMap = new TreeMap<Integer, String>();

                        Object columnTitle = util.getColumnTitle(col);

                        boolean visible = util.isColumnVisible(realCol, table);
                        if (!visible) {
                            return false;
                        } else {
                            Object value = util.getModel().getValueAt(realRow, realCol);
                            rowMap.put(realCol, value);
                            titleMap.put(realCol, (String) columnTitle);
                        }

                        Object val = util.getModel().getValueAt(entry.getIdentifier(), realCol);
                        String value = finder.valueToString(val);

                        // System.out.println("hiddenRowNotMatch [value] ------"
                        // + value);

                        C: for (String text : finder.getArry()) {
                            // ========================================= 比對
                            // AAA=bbb
                            Boolean columnAndValMatch = isMatchColumnRowData(text, realCol, titleMap, rowMap);
                            if (columnAndValMatch != null) {
                                if (columnAndValMatch) {
                                    return true;
                                }
                                // ========================================= 比對
                                // AAA=bbb
                            } else {
                                // 原來的
                                if (value.contains(text)) {
                                    // 加入符合搜尋文字 TODO
                                    System.out.println("hiddenRowNotMatch[match rowIdx(1)/value] ----- " + entry.getIdentifier() + " / " + value);
                                    return true;
                                }
                            }
                        }
                    }
                    // is AND
                } else {
                    Set<Integer> matchRealColSet = new HashSet<Integer>();

                    C: for (String text : finder.getArry()) {

                        B: for (int col = 0; col < table.getColumnCount(); col++) {
                            int realCol = util.getRealColumnPos(col, table);

                            // System.out.println("hiddenRowNotMatch [realCol]
                            // ------" + realCol);
                            if (isNoDotColumn(realCol)) {
                                continue;
                            }

                            int realRow = entry.getIdentifier();

                            TreeMap<Integer, Object> rowMap = new TreeMap<Integer, Object>();
                            TreeMap<Integer, String> titleMap = new TreeMap<Integer, String>();

                            Object columnTitle = util.getColumnTitle(col);

                            boolean visible = util.isColumnVisible(realCol, table);
                            if (!visible) {
                                return false;
                            } else {
                                Object value = util.getModel().getValueAt(realRow, realCol);
                                rowMap.put(realCol, value);
                                titleMap.put(realCol, (String) columnTitle);
                            }

                            Object val = util.getModel().getValueAt(entry.getIdentifier(), realCol);
                            String value = finder.valueToString(val);

                            // System.out.println("hiddenRowNotMatch [value]
                            // ------" + value);
                            // ----------------------------------------------------------------------------------------------------START
                            // ========================================= 比對
                            // AAA=bbb
                            Boolean columnAndValMatch = isMatchColumnRowData(text, realCol, titleMap, rowMap);
                            if (columnAndValMatch != null) {
                                if (columnAndValMatch) {
                                    matchRealColSet.add(realCol);
                                    break B;
                                }
                                // ========================================= 比對
                                // AAA=bbb
                            } else {
                                // 原來的
                                if (!value.contains(text)) {
                                    matchRealColSet.add(realCol);
                                    break B;
                                }
                            }
                            // ----------------------------------------------------------------------------------------------------END
                        }
                    }

                    if (finder.getArry().length == matchRealColSet.size()) {
                        // 加入符合搜尋文字 TODO
                        return true;
                    }
                }
                return false;
            }
        });

        System.out.println("changeColorRowCellIdxMap - " + changeColorRowCellIdxMap);
        JTableUtil.newInstance(table).setCellBackgroundColor(Color.green.brighter(), changeColorRowCellIdxMap, null);
    }

    public boolean isDoHiddenColumn() {
        return doHiddenColumn;
    }
}